"""
pdfa_logic.py
Konvertiert eine PDF-Datei nach PDF/A-2b (ISO 19005-2) fuer die
Langzeitarchivierung - z. B. GoBD-konforme Rechnungsablage im Buero.
Nutzt ausschliesslich das bereits vorhandene Ghostscript (siehe
compress_logic.py) inklusive der von Ghostscript selbst mitgelieferten
PDFA_def.ps-Vorlage und ihres ICC-Farbprofils - keine neue Abhaengigkeit
und kein mitgeliefertes Drittanbieter-Profil noetig.
"""

import glob
import os
import shutil
import subprocess
import tempfile
from logger_setup import log_exception


def is_ghostscript_available() -> bool:
    return shutil.which("gs") is not None


def _find_pdfa_template() -> str | None:
    matches = sorted(glob.glob("/usr/share/ghostscript/*/lib/PDFA_def.ps"))
    return matches[-1] if matches else None


def _find_icc_profile() -> str | None:
    candidates = ["/usr/share/color/icc/ghostscript/srgb.icc"]
    candidates += sorted(glob.glob("/usr/share/ghostscript/*/iccprofiles/srgb.icc"))
    return next((path for path in candidates if os.path.isfile(path)), None)


def is_pdfa_supported() -> bool:
    """Prueft, ob alle fuer die Konvertierung noetigen Ghostscript-
    Bestandteile auf diesem System vorhanden sind."""
    return is_ghostscript_available() and _find_pdfa_template() is not None and _find_icc_profile() is not None


def convert_to_pdfa(input_path: str, output_path: str) -> bool:
    """Konvertiert nach PDF/A-2b. Gibt False zurueck, wenn Ghostscript
    oder die benoetigten Zusatzdateien fehlen oder die Konvertierung
    fehlschlaegt."""
    template = _find_pdfa_template()
    icc_profile = _find_icc_profile()
    if not is_ghostscript_available() or not template or not icc_profile:
        log_exception("PDF/A-Konvertierung nicht möglich", Exception("Ghostscript, PDFA_def.ps oder ICC-Profil nicht gefunden"))
        return False

    document_title = os.path.splitext(os.path.basename(input_path))[0]
    document_title = document_title.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
    with tempfile.TemporaryDirectory() as tmp_dir:
        with open(template, "r", encoding="utf-8") as source:
            content = source.read().replace("(srgb.icc)", f"({icc_profile})")
            content = content.replace("/Title (Title)", f"/Title ({document_title})")
        custom_template = os.path.join(tmp_dir, "PDFA_def_custom.ps")
        with open(custom_template, "w", encoding="utf-8") as target:
            target.write(content)

        command = [
            "gs", "-dPDFA=2", "-dBATCH", "-dNOPAUSE", "-dQUIET", "-dNOOUTERSAVE",
            "-dCompatibilityLevel=1.7", "-sColorConversionStrategy=RGB",
            "-sProcessColorModel=DeviceRGB", "-dPDFACompatibilityPolicy=1",
            "-sDEVICE=pdfwrite", f"--permit-file-read={icc_profile}",
            f"-sOutputFile={output_path}", custom_template, input_path,
        ]
        try:
            result = subprocess.run(command, capture_output=True, timeout=120, check=False)
            if result.returncode != 0:
                log_exception("Ghostscript PDF/A-Fehlercode", Exception(result.stderr.decode(errors="ignore")))
                return False
            return os.path.isfile(output_path)
        except Exception as exc:  # noqa: BLE001
            log_exception("Fehler bei der PDF/A-Konvertierung", exc)
            return False

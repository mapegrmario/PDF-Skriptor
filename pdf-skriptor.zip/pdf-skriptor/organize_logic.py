"""
organize_logic.py
Backend-Funktionen fuer das Organisieren-Modul: Seiten zusammenfuegen,
trennen, drehen und loeschen. Nutzt pypdf fuer robuste Seitenoperationen.
"""

import os
from pypdf import PdfReader, PdfWriter
from logger_setup import log_exception


def merge_pdfs(paths: list[str], output_path: str) -> bool:
    """Fuegt mehrere PDF-Dateien in der gegebenen Reihenfolge zusammen."""
    writer = PdfWriter()
    try:
        for path in paths:
            reader = PdfReader(path)
            for page in reader.pages:
                writer.add_page(page)
        with open(output_path, "wb") as file:
            writer.write(file)
        return True
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Zusammenfuegen der PDFs", exc)
        return False


def split_pdf(path: str, output_dir: str) -> list[str]:
    """Trennt jede Seite einer PDF-Datei in eine eigene Datei auf."""
    created_files = []
    try:
        os.makedirs(output_dir, exist_ok=True)
        reader = PdfReader(path)
        base_name = os.path.splitext(os.path.basename(path))[0]
        for index, page in enumerate(reader.pages, start=1):
            writer = PdfWriter()
            writer.add_page(page)
            out_path = os.path.join(output_dir, f"{base_name}_Seite_{index}.pdf")
            with open(out_path, "wb") as file:
                writer.write(file)
            created_files.append(out_path)
        return created_files
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Trennen der PDF", exc)
        return created_files


def rotate_pages(path: str, output_path: str, degrees: int, page_indices: list[int] | None = None) -> bool:
    """Dreht ausgewaehlte Seiten (oder alle) um die angegebene Gradzahl."""
    try:
        reader = PdfReader(path)
        writer = PdfWriter()
        for index, page in enumerate(reader.pages):
            if page_indices is None or index in page_indices:
                page.rotate(degrees)
            writer.add_page(page)
        with open(output_path, "wb") as file:
            writer.write(file)
        return True
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Drehen der Seiten", exc)
        return False


def delete_pages(path: str, output_path: str, page_indices: list[int]) -> bool:
    """Entfernt die angegebenen Seiten (0-basiert) aus der PDF-Datei."""
    try:
        reader = PdfReader(path)
        writer = PdfWriter()
        for index, page in enumerate(reader.pages):
            if index not in page_indices:
                writer.add_page(page)
        with open(output_path, "wb") as file:
            writer.write(file)
        return True
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Loeschen von Seiten", exc)
        return False


def get_page_count(path: str) -> int:
    """Ermittelt die Seitenanzahl einer PDF-Datei, 0 bei Fehler."""
    try:
        reader = PdfReader(path)
        return len(reader.pages)
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Ermitteln der Seitenzahl", exc)
        return 0

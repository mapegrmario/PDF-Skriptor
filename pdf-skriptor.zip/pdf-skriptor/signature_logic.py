"""
signature_logic.py
Erzeugt aus handgezeichneten Freihand-Strichen ein Unterschrift-Bild
(transparentes PNG) und fuegt es als wiederverwendbaren Stempel in eine
PDF-Seite ein. Die Unterschrift wird einmalig im Konfigurationsordner
gespeichert (wie die uebrigen Einstellungen, siehe settings.py) und
kann danach beliebig oft platziert werden, ohne sie erneut zu zeichnen.
"""

import os
import pymupdf as fitz  # "fitz" ist der veraltete Alias, siehe PyMuPDF-Deprecation-Hinweis
from PIL import Image, ImageDraw
from logger_setup import log_exception

CANVAS_SIZE = (500, 180)
_SIGNATURE_FILENAME = "signatur.png"


def _get_signature_path() -> str:
    config_dir = os.path.join(os.path.expanduser("~"), ".config", "pdf-skriptor")
    os.makedirs(config_dir, exist_ok=True)
    return os.path.join(config_dir, _SIGNATURE_FILENAME)


def render_signature_image(strokes: list[list[tuple[float, float]]]) -> Image.Image:
    """Zeichnet eine Liste von Strichen (je eine Liste von Punkten) auf
    eine transparente Flaeche in CANVAS_SIZE und liefert das Ergebnis als
    PIL-Bild - unabhaengig von tkinter, damit es sich isoliert testen laesst."""
    image = Image.new("RGBA", CANVAS_SIZE, (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    for stroke in strokes:
        if len(stroke) >= 2:
            draw.line(stroke, fill=(20, 20, 20, 255), width=4, joint="curve")
        elif len(stroke) == 1:
            x, y = stroke[0]
            draw.ellipse([x - 2, y - 2, x + 2, y + 2], fill=(20, 20, 20, 255))
    return image


def save_signature(image: Image.Image) -> bool:
    try:
        image.save(_get_signature_path())
        return True
    except OSError as exc:
        log_exception("Unterschrift konnte nicht gespeichert werden", exc)
        return False


def load_signature_path() -> str | None:
    path = _get_signature_path()
    return path if os.path.exists(path) else None


def insert_signature(document: fitz.Document, page_index: int, position: tuple[float, float], width_pt: float = 130.0) -> bool:
    """Platziert die gespeicherte Unterschrift an der angegebenen Position
    (Seitenkoordinaten). Die Hoehe wird proportional zur Zeichenflaeche
    berechnet, damit die Unterschrift nicht verzerrt wird."""
    path = load_signature_path()
    if not path:
        return False
    try:
        page = document[page_index]
        canvas_w, canvas_h = CANVAS_SIZE
        height_pt = width_pt * (canvas_h / canvas_w)
        rect = fitz.Rect(position[0], position[1], position[0] + width_pt, position[1] + height_pt)
        page.insert_image(rect, filename=path)
        return True
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Einfügen der Unterschrift", exc)
        return False

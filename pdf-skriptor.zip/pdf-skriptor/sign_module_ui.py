"""
sign_module_ui.py
Container-Ansicht fuer das Digitale-Signatur-Modul. Schaltet zwischen
den Unter-Werkzeugen Zertifikat, Signieren und Pruefen um - gleiches
Muster wie organize_ui.py fuer das Organisieren-Modul.
"""

import customtkinter as ctk
from language import t
import theme
from sign_cert_ui import SignCertTool
from sign_document_ui import SignDocumentTool
from sign_verify_ui import SignVerifyTool

_SUB_TOOLS = {
    "cert": ("sign_tab_cert", SignCertTool),
    "sign": ("sign_tab_sign", SignDocumentTool),
    "verify": ("sign_tab_verify", SignVerifyTool),
}


class SignModuleView(ctk.CTkFrame):
    """Oberste Ansicht des Digitale-Signatur-Moduls mit Unter-Werkzeug-Auswahl."""

    def __init__(self, master, file_manager) -> None:
        super().__init__(master, fg_color=theme.COLOR_BG)
        self._file_manager = file_manager
        self._tool_container: ctk.CTkFrame | None = None
        self._active_tool: ctk.CTkFrame | None = None
        self._label_by_display: dict[str, str] = {}
        self._build_ui()
        self._show_tool("cert")

    def _build_ui(self) -> None:
        title = ctk.CTkLabel(self, text=t("nav_sign"), font=theme.font_title(), text_color=theme.COLOR_TEXT)
        title.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(theme.PADDING_LARGE, theme.PADDING_SMALL))

        disclaimer = ctk.CTkLabel(
            self, text=t("sign_module_disclaimer"), font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED,
            wraplength=300, justify="left",
        )
        disclaimer.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        values = []
        for key, (label_key, _cls) in _SUB_TOOLS.items():
            label = t(label_key)
            values.append(label)
            self._label_by_display[label] = key

        self._selector = ctk.CTkSegmentedButton(self, values=values, command=self._handle_tool_selected)
        self._selector.set(values[0])
        self._selector.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        self._tool_container = ctk.CTkFrame(self, fg_color="transparent")
        self._tool_container.pack(fill="both", expand=True, padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_LARGE))

    def _handle_tool_selected(self, value: str) -> None:
        key = self._label_by_display.get(value)
        if key:
            self._show_tool(key)

    def _show_tool(self, key: str) -> None:
        if self._active_tool is not None:
            self._active_tool.destroy()
        _label_key, tool_cls = _SUB_TOOLS[key]
        self._active_tool = tool_cls(self._tool_container, self._file_manager)
        self._active_tool.pack(fill="both", expand=True)

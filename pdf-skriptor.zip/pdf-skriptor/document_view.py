"""
document_view.py
Zentrale, permanente Dokumentenansicht - der Kern des neuen
Bedienkonzepts nach Vorbild eines Schreibprogramms: Das Dokument
bleibt immer sichtbar, egal welches Werkzeug in der Seitenleiste
gerade gewaehlt ist. Es gibt keine separate "Vorschau" mehr - diese
Ansicht UEBERNIMMT die Vorschau-Rolle vollstaendig und dauerhaft.

Die Seite wird in einer echten scrollbaren Canvas dargestellt (mit
Scrollbalken und Mausrad-Unterstuetzung), da Seiten - insbesondere bei
kleineren Fenstern oder groesserem Zoom - hoeher/breiter sein koennen
als der sichtbare Bereich.

Interaktive Werkzeuge (Anmerkungen, Redaction manuell) zeichnen direkt
auf dieser gemeinsamen Ansicht statt eine eigene, doppelte Seiten-
darstellung mitzubringen: sie werden ueber on_shown()/on_hidden() vom
Hauptfenster an- und abgemeldet und lesen/schreiben ueber
get_document()/refresh() dasselbe PyMuPDF-Dokument, das gerade
angezeigt wird. Da die Canvas jetzt scrollbar ist, muessen sie
Klick-Koordinaten ueber canvas_x()/canvas_y() in Canvas-Koordinaten
umrechnen, statt event.x/event.y direkt zu verwenden.
"""

import os
import time
import tkinter as tk
import customtkinter as ctk
from PIL import Image, ImageTk
import pymupdf as fitz  # "fitz" ist der veraltete Alias, siehe PyMuPDF-Deprecation-Hinweis
from language import t
import settings as settings_store
import theme
from logger_setup import log_exception
from page_preview_strip import PagePreviewStrip

_RENDER_ZOOM = 1.3
_MIN_ZOOM_LEVEL = 0.4
_MAX_ZOOM_LEVEL = 4.0
_ZOOM_STEP = 1.15
_SCROLL_PIXELS_PER_NOTCH = 130
_SCROLL_EASE_FACTOR = 0.32
_SCROLL_TICK_MS = 16
_SCROLL_MIN_STEP = 0.6


class DocumentView(ctk.CTkFrame):
    """Zeigt permanent die aktuelle Seite der aktiven Datei an - scrollbar."""

    def __init__(self, master, file_manager) -> None:
        super().__init__(master, fg_color=theme.COLOR_BG_SECONDARY, corner_radius=0)
        self._file_manager = file_manager
        self._document: fitz.Document | None = None
        self._page_index = 0
        self._zoom_level = 1.0
        self._current_photo = None
        self._image_item = None
        self._page_pixel_width = 0
        self._page_pixel_height = 0
        # QA-Fix (Runde 6): siehe _update_page_centering() / canvas_x() /
        # canvas_y() / page_offset() weiter unten.
        self._offset_x = 0
        self._offset_y = 0
        self._overlay_callback = None
        self._load_error = False
        self._preview_strip_visible = False
        self._build_ui()

        def _on_active_change(path: str | None) -> None:
            self._load_document(path)

        self._file_manager.register_active_listener(_on_active_change)
        self.bind("<Destroy>", lambda event: self._file_manager.unregister_active_listener(_on_active_change))
        self._load_document(self._file_manager.get_active_file())

    def _build_ui(self) -> None:
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=(theme.PADDING_MEDIUM, theme.PADDING_SMALL))

        self._filename_label = ctk.CTkLabel(
            header, text=t("preview_no_file"), font=theme.font_heading(), text_color=theme.COLOR_TEXT,
        )
        self._filename_label.pack(side="left")

        # Per Maus verschiebbarer Trenner zwischen Vorschaustreifen und der
        # grossen Seitenansicht (tk.PanedWindow) - Hoehe des Streifens wird
        # in settings.json gemerkt (siehe _on_inner_sash_release). Der
        # Vorschaustreifen selbst wird hier NICHT hinzugefuegt (kein
        # Dokument beim Start) - das uebernimmt _load_document() per
        # add()/forget(), analog zum frueheren pack()/pack_forget().
        self._inner_paned = tk.PanedWindow(
            self, orient="vertical", bg=theme.COLOR_BG_SECONDARY, bd=0,
            sashwidth=8, sashpad=0, sashrelief="flat", opaqueresize=True,
        )
        self._inner_paned.pack(
            fill="both", expand=True, padx=theme.PADDING_MEDIUM, pady=(0, theme.PADDING_SMALL),
        )
        self._inner_paned.bind("<ButtonRelease-1>", self._on_inner_sash_release)

        # Zwischen Werkbank (eine Ebene hoeher, workbench_view.py) und der
        # grossen Einzelseiten-Ansicht unten: ein Klick auf eine Miniatur
        # springt per set_page_index() zur jeweiligen Seite.
        self._preview_strip = PagePreviewStrip(self._inner_paned, on_page_click=self.set_page_index)

        self._canvas_frame = ctk.CTkFrame(
            self._inner_paned, fg_color=theme.COLOR_BORDER, corner_radius=theme.CORNER_RADIUS,
        )
        self._inner_paned.add(self._canvas_frame, minsize=200, stretch="always")
        self._canvas_frame.grid_rowconfigure(0, weight=1)
        self._canvas_frame.grid_columnconfigure(0, weight=1)

        # Echte scrollbare Canvas: die Widget-Groesse richtet sich nach dem
        # verfuegbaren Platz (Grid + Frame), waehrend die 'scrollregion'
        # unabhaengig davon auf die tatsaechliche Seitengroesse gesetzt wird -
        # dadurch entsteht bei Bedarf ein Scrollbalken statt eines
        # abgeschnittenen/verzerrten Bildes.
        self._canvas = tk.Canvas(self._canvas_frame, bg=theme.COLOR_BG_SECONDARY, highlightthickness=0)
        self._canvas.grid(row=0, column=0, sticky="nsew", padx=(1, 0), pady=(1, 0))
        # QA-Fix: haelt die Seite bei jeder Groessenaenderung der Canvas
        # (Fenster-Resize, Trennerverschiebung) zentriert, nicht nur direkt
        # nach dem Rendern - siehe _update_page_centering().
        self._canvas.bind("<Configure>", lambda event: self._update_page_centering())

        self._v_scrollbar = tk.Scrollbar(self._canvas_frame, orient="vertical", command=self._canvas.yview)
        self._v_scrollbar.grid(row=0, column=1, sticky="ns", pady=(1, 0))
        self._h_scrollbar = tk.Scrollbar(self._canvas_frame, orient="horizontal", command=self._canvas.xview)
        self._h_scrollbar.grid(row=1, column=0, sticky="ew", padx=(1, 0))

        self._canvas.configure(yscrollcommand=self._v_scrollbar.set, xscrollcommand=self._h_scrollbar.set)
        self._register_mousewheel_scroll()

        self._empty_label = ctk.CTkLabel(
            self._canvas_frame, text=f"{t('preview_no_file')}\n{t('preview_no_file_hint')}",
            font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED, justify="center",
        )

        nav_row = ctk.CTkFrame(self, fg_color="transparent")
        nav_row.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=(0, theme.PADDING_MEDIUM))

        page_nav = ctk.CTkFrame(nav_row, fg_color="transparent")
        page_nav.pack(side="left", expand=True)

        self._prev_button = ctk.CTkButton(page_nav, text="◀", width=40, command=self.show_prev_page)
        self._prev_button.pack(side="left")

        self._page_label = ctk.CTkLabel(page_nav, text="–", font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED)
        self._page_label.pack(side="left", padx=theme.PADDING_MEDIUM)

        self._next_button = ctk.CTkButton(page_nav, text="▶", width=40, command=self.show_next_page)
        self._next_button.pack(side="left")

        zoom_controls = ctk.CTkFrame(nav_row, fg_color="transparent")
        zoom_controls.pack(side="right")

        self._zoom_out_button = ctk.CTkButton(zoom_controls, text="−", width=32, command=self.zoom_out)
        self._zoom_out_button.pack(side="left")

        self._zoom_label = ctk.CTkLabel(
            zoom_controls, text="100%", font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED,
            width=48, cursor="hand2",
        )
        self._zoom_label.pack(side="left", padx=theme.PADDING_SMALL)
        # Ein <Button-1>-Bind direkt auf ein CTkLabel feuert in CustomTkinter
        # nicht zuverlaessig (siehe home_view.py) - nur die intern genutzten
        # rohen tkinter-Widgets empfangen den Klick tatsaechlich.
        self._zoom_label.bind("<Button-1>", lambda event: self.reset_zoom())
        self._zoom_label._label.bind("<Button-1>", lambda event: self.reset_zoom())
        self._zoom_label._canvas.bind("<Button-1>", lambda event: self.reset_zoom())

        self._zoom_in_button = ctk.CTkButton(zoom_controls, text="+", width=32, command=self.zoom_in)
        self._zoom_in_button.pack(side="left")

    def _register_mousewheel_scroll(self) -> None:
        """Mausrad scrollt vertikal (mit Umschalt-Taste horizontal, mit
        Strg-Taste zoomt es stattdessen), solange sich die Maus ueber der
        Dokumentenansicht befindet. Scrollen laeuft sanft aus (mehrere
        kleine, abklingende Teilschritte) statt in einem harten Sprung pro
        Mausrad-Kerbe - siehe scroll_helpers.py fuer dieselbe Technik an
        anderer Stelle der Anwendung. Zoomen bleibt bewusst unverzoegert
        (ein Schritt pro Kerbe), da eine ausklingende Zoom-Animation eher
        verwirren als helfen wuerde. Der Abklingfaktor wird auf die
        tatsaechlich vergangene Zeit skaliert statt auf eine feste
        Tick-Anzahl zu vertrauen, damit ein durch Systemlast verspaeteter
        Tick nicht als Ruckeln sichtbar wird. Ausserdem wird an einem
        Scroll-Rand kein weiteres Momentum in dieselbe Richtung mehr
        aufgebaut, damit ein Richtungswechsel nicht erst ungenutzte
        "Scroll-Schuld" abbauen muss, bevor er wirkt."""
        self._canvas.configure(yscrollincrement=1, xscrollincrement=1)
        pending = {"y": 0.0, "x": 0.0, "job": None, "last_tick": 0.0}

        def _cancel() -> None:
            if pending["job"] is not None:
                self._canvas.after_cancel(pending["job"])
                pending["job"] = None
            pending["y"] = 0.0
            pending["x"] = 0.0
            pending["last_tick"] = 0.0

        def _decay_factor(elapsed_ms: float) -> float:
            # Entspricht bei genau _SCROLL_TICK_MS exakt _SCROLL_EASE_FACTOR,
            # gleicht einen verspaeteten Tick aber korrekt aus (kontinuier-
            # liches Aequivalent mehrerer regulaerer Ticks), statt sichtbar
            # hinterherzuhinken.
            return 1 - (1 - _SCROLL_EASE_FACTOR) ** (elapsed_ms / _SCROLL_TICK_MS)

        def _tick() -> None:
            now = time.perf_counter()
            elapsed_ms = (now - pending["last_tick"]) * 1000 if pending["last_tick"] else _SCROLL_TICK_MS
            pending["last_tick"] = now
            factor = _decay_factor(elapsed_ms)
            step_y = pending["y"] * factor
            step_x = pending["x"] * factor
            done = True
            if abs(step_y) >= _SCROLL_MIN_STEP:
                self._canvas.yview_scroll(int(round(step_y)), "units")
                pending["y"] -= step_y
                done = False
            elif abs(pending["y"]) >= 1:
                self._canvas.yview_scroll(int(round(pending["y"])), "units")
                pending["y"] = 0.0
            if abs(step_x) >= _SCROLL_MIN_STEP:
                self._canvas.xview_scroll(int(round(step_x)), "units")
                pending["x"] -= step_x
                done = False
            elif abs(pending["x"]) >= 1:
                self._canvas.xview_scroll(int(round(pending["x"])), "units")
                pending["x"] = 0.0
            pending["job"] = None if done else self._canvas.after(_SCROLL_TICK_MS, _tick)

        def _at_edge(view_fn, forward: bool) -> bool:
            start, end = view_fn()
            return end >= 1.0 if forward else start <= 0.0

        def _on_mousewheel(event) -> None:
            delta = -1 if getattr(event, "num", None) == 5 or getattr(event, "delta", 0) < 0 else 1
            state = getattr(event, "state", 0)
            if state & 0x0004:  # Strg-Taste gedrueckt -> zoomen statt scrollen
                self.zoom_in() if delta > 0 else self.zoom_out()
                return
            horizontal = bool(state & 0x0001)  # Umschalt-Taste gedrueckt
            view_fn = self._canvas.xview if horizontal else self._canvas.yview
            key = "x" if horizontal else "y"
            # Kein weiteres Scroll-Momentum aufbauen, wenn bereits am Rand in
            # genau dieser Richtung - sonst braucht ein Richtungswechsel erst
            # den Abbau der ungenutzten "Scroll-Schuld", bevor er sichtbar
            # wird (fuehlt sich an, als wuerde die Maus kurz nicht mehr
            # reagieren).
            if delta < 0 and _at_edge(view_fn, forward=True):
                pending[key] = min(pending[key], 0.0)
                return
            if delta > 0 and _at_edge(view_fn, forward=False):
                pending[key] = max(pending[key], 0.0)
                return
            pending[key] += -delta * _SCROLL_PIXELS_PER_NOTCH
            if pending["job"] is None:
                pending["last_tick"] = time.perf_counter()
                pending["job"] = self._canvas.after(_SCROLL_TICK_MS, _tick)

        def _on_enter(_event) -> None:
            self._canvas.bind_all("<MouseWheel>", _on_mousewheel)
            self._canvas.bind_all("<Button-4>", _on_mousewheel)
            self._canvas.bind_all("<Button-5>", _on_mousewheel)

        def _on_leave(_event) -> None:
            self._canvas.unbind_all("<MouseWheel>")
            self._canvas.unbind_all("<Button-4>")
            self._canvas.unbind_all("<Button-5>")
            _cancel()

        self._canvas.bind("<Enter>", _on_enter)
        self._canvas.bind("<Leave>", _on_leave)

    # --- Fuer Werkzeuge, die direkt auf dieser Ansicht zeichnen/interagieren ---

    def get_document(self) -> fitz.Document | None:
        """Gibt das aktuell geoeffnete PyMuPDF-Dokument zum Lesen/Bearbeiten zurueck."""
        return self._document

    def get_page_index(self) -> int:
        return self._page_index

    def get_zoom(self) -> float:
        return _RENDER_ZOOM * self._zoom_level

    def zoom_in(self) -> None:
        self._set_zoom(self._zoom_level * _ZOOM_STEP)

    def zoom_out(self) -> None:
        self._set_zoom(self._zoom_level / _ZOOM_STEP)

    def reset_zoom(self) -> None:
        self._set_zoom(1.0)

    def _set_zoom(self, new_level: float) -> None:
        clamped = max(_MIN_ZOOM_LEVEL, min(new_level, _MAX_ZOOM_LEVEL))
        if abs(clamped - self._zoom_level) < 0.001:
            return
        # Scroll-Position als Anteil (0..1) merken, damit der Blickpunkt beim
        # Zoomen ungefaehr erhalten bleibt, statt zurueck an den Seitenanfang
        # zu springen.
        try:
            top_fraction = self._canvas.yview()[0]
        except tk.TclError:
            top_fraction = 0.0
        self._zoom_level = clamped
        self._zoom_label.configure(text=f"{round(self._zoom_level * 100)}%")
        self._render_current_page(reset_scroll=False)
        self._canvas.yview_moveto(top_fraction)

    def get_canvas(self) -> tk.Canvas:
        return self._canvas

    def canvas_x(self, event_x: int) -> float:
        """Wandelt eine Bildschirm-x-Koordinate (event.x) unter
        Beruecksichtigung von Scrollposition UND Zentrierungs-Versatz
        (siehe _update_page_centering()) in eine seitenrelative
        Canvas-Koordinate um - 0 ist also immer die linke Kante der Seite,
        nicht die linke Kante der Canvas. Werkzeuge, die Klick-/Zeichen-
        Positionen in PDF-Koordinaten umrechnen (durch zusaetzliches Teilen
        durch den Zoomfaktor), MUESSEN dies statt des rohen event.x
        verwenden.
        QA-Fix (Runde 6, gemeldet als "springt nach rechts"): Vor diesem Fix
        lieferte diese Methode die reine Canvas-Koordinate OHNE den
        Zentrierungs-Versatz abzuziehen. Solange die Seite (z. B. bei 100%
        Zoom) schmaler als die sichtbare Flaeche ist und deshalb zentriert
        dargestellt wird, war jede daraus abgeleitete Anmerkungs-Position um
        genau diesen Versatz nach rechts/unten verschoben - sichtbar u. a.
        beim Zeichnen, Platzieren von Text/Stempel/Unterschrift und beim
        Radieren. Waehrend des Ziehens (Vorschau-Zeichnung direkt auf der
        Canvas) fiel es nicht auf, weil dort roh mit derselben (falschen)
        Canvas-Koordinate gezeichnet wurde - der sichtbare Sprung passierte
        erst beim Refresh nach dem Loslassen, wenn die tatsaechlich (falsch)
        gespeicherte PDF-Koordinate neu gerendert wurde. Werkzeuge, die
        WAEHREND einer Aktion direkt auf die Canvas zeichnen (Vorschau-
        Linien/-Rechtecke), muessen dafuer weiterhin die echte
        Bildschirmposition verwenden - dafuer liefert page_offset() den hier
        abgezogenen Versatz, damit er beim Zeichnen wieder addiert werden
        kann."""
        return self._canvas.canvasx(event_x) - self._offset_x

    def canvas_y(self, event_y: int) -> float:
        return self._canvas.canvasy(event_y) - self._offset_y

    def page_offset(self) -> tuple[float, float]:
        """Aktueller Zentrierungs-Versatz in Canvas-Pixeln (siehe Docstring
        von canvas_x()). Fuer Werkzeuge, die eine Vorschau waehrend des
        Ziehens direkt auf die Canvas zeichnen (echte Bildschirmposition
        noetig, nicht die seitenrelative aus canvas_x()/canvas_y())."""
        return self._offset_x, self._offset_y

    def refresh(self) -> None:
        """Rendert die aktuelle Seite neu - z. B. nachdem ein Werkzeug eine
        Anmerkung oder Schwaerzung direkt in das Dokument eingefuegt hat."""
        self._render_current_page(reset_scroll=False)

    def _on_inner_sash_release(self, _event) -> None:
        """Merkt sich die per Maus eingestellte Hoehe des Vorschaustreifens
        dauerhaft - nur relevant, wenn der Streifen gerade sichtbar ist."""
        if not self._preview_strip_visible:
            return
        height = self._preview_strip.winfo_height()
        if height > 10:
            settings_store.update_setting("preview_pane_height", height)

    def bind_canvas(self, on_down=None, on_drag=None, on_up=None) -> None:
        """Bindet Maus-Ereignisse eines interaktiven Werkzeugs an die Canvas."""
        if on_down is not None:
            self._canvas.bind("<ButtonPress-1>", on_down)
        if on_drag is not None:
            self._canvas.bind("<B1-Motion>", on_drag)
        if on_up is not None:
            self._canvas.bind("<ButtonRelease-1>", on_up)

    def unbind_canvas(self) -> None:
        """Entfernt die Maus-Bindungen eines interaktiven Werkzeugs wieder."""
        self._canvas.unbind("<ButtonPress-1>")
        self._canvas.unbind("<B1-Motion>")
        self._canvas.unbind("<ButtonRelease-1>")

    def set_overlay_callback(self, callback) -> None:
        """Registriert eine Funktion, die nach jedem Rendern zusaetzlich auf
        die Canvas zeichnen darf (z. B. vorgemerkte Redaction-Bereiche)."""
        self._overlay_callback = callback

    def clear_overlay_callback(self) -> None:
        self._overlay_callback = None

    # --- Interne Darstellung ---

    def _update_page_centering(self) -> None:
        """Positioniert die aktuelle Seite mittig in der Canvas, wenn sie
        (bei aktuellem Zoom) kleiner als der sichtbare Bereich ist, und
        setzt die scrollregion passend dazu. Ist die Seite in einer
        Richtung groesser als der sichtbare Bereich, bleibt es dort beim
        bisherigen Verhalten (an den Rand gesetzt, per Scrollbalken
        erreichbar) - nur die zu kleine Richtung wird zentriert."""
        if self._image_item is None:
            return
        canvas_width = self._canvas.winfo_width()
        canvas_height = self._canvas.winfo_height()
        offset_x = max(0, (canvas_width - self._page_pixel_width) // 2)
        offset_y = max(0, (canvas_height - self._page_pixel_height) // 2)
        self._offset_x = offset_x
        self._offset_y = offset_y
        self._canvas.coords(self._image_item, offset_x, offset_y)
        region_width = max(canvas_width, self._page_pixel_width + offset_x)
        region_height = max(canvas_height, self._page_pixel_height + offset_y)
        self._canvas.configure(scrollregion=(0, 0, region_width, region_height))

    def _load_document(self, path: str | None) -> None:
        if self._document is not None:
            try:
                self._document.close()
            except Exception:  # noqa: BLE001
                pass
            self._document = None
        self._page_index = 0
        self._zoom_level = 1.0
        self._zoom_label.configure(text="100%")
        self._load_error = False

        if path and os.path.isfile(path):
            try:
                self._document = fitz.open(path)
                self._filename_label.configure(text=os.path.basename(path))
            except Exception as exc:  # noqa: BLE001
                log_exception("Fehler beim Öffnen der Datei für die Dokumentenansicht", exc)
                self._document = None
                self._load_error = True
                # Absichtlich weiterhin den Dateinamen zeigen (statt auf
                # "Keine Datei ausgewaehlt" zurueckzufallen) - sonst sieht es
                # so aus, als waere gar keine Datei gewaehlt, obwohl der
                # Nutzer gerade aktiv eine ausgewaehlt hat, die nur nicht
                # gelesen werden konnte.
                self._filename_label.configure(text=os.path.basename(path))
        else:
            self._filename_label.configure(text=t("preview_no_file"))

        # before=self._canvas_frame verankert den Streifen an seiner festen
        # Position zwischen Werkbank und Anzeigeflaeche, unabhaengig davon,
        # wie oft er zwischenzeitlich per forget() ausgeblendet war - ein
        # einfaches erneutes add() ohne "before" wuerde ihn sonst ans Ende
        # der Reihenfolge (unterhalb der Anzeigeflaeche) setzen.
        has_pages = self._preview_strip.load(path if self._document else None)
        if has_pages and not self._preview_strip_visible:
            self._inner_paned.add(
                self._preview_strip, minsize=90,
                height=settings_store.load_settings().get("preview_pane_height", 140),
                before=self._canvas_frame, stretch="never",
            )
            self._preview_strip_visible = True
        elif not has_pages and self._preview_strip_visible:
            self._inner_paned.forget(self._preview_strip)
            self._preview_strip_visible = False

        self._render_current_page(reset_scroll=True)

    def _render_current_page(self, reset_scroll: bool = True) -> None:
        self._canvas.delete("all")

        if not self._document or self._document.page_count == 0:
            self._canvas.grid_remove()
            self._v_scrollbar.grid_remove()
            self._h_scrollbar.grid_remove()
            if self._load_error:
                self._empty_label.configure(text=f"⚠ {t('preview_load_error')}")
            else:
                self._empty_label.configure(text=f"{t('preview_no_file')}\n{t('preview_no_file_hint')}")
            self._empty_label.grid(row=0, column=0, sticky="nsew")
            self._page_label.configure(text="–")
            self._prev_button.configure(state="disabled")
            self._next_button.configure(state="disabled")
            self._zoom_in_button.configure(state="disabled")
            self._zoom_out_button.configure(state="disabled")
            return

        self._empty_label.grid_remove()
        self._canvas.grid(row=0, column=0, sticky="nsew", padx=(1, 0), pady=(1, 0))
        self._v_scrollbar.grid(row=0, column=1, sticky="ns", pady=(1, 0))
        self._h_scrollbar.grid(row=1, column=0, sticky="ew", padx=(1, 0))

        page = self._document[self._page_index]
        pixmap = page.get_pixmap(matrix=fitz.Matrix(self.get_zoom(), self.get_zoom()))
        image = Image.frombytes("RGB", (pixmap.width, pixmap.height), pixmap.samples)

        self._current_photo = ImageTk.PhotoImage(image)
        self._page_pixel_width = pixmap.width
        self._page_pixel_height = pixmap.height
        self._image_item = self._canvas.create_image(0, 0, anchor="nw", image=self._current_photo)
        # QA-Fix: Seite wird jetzt zentriert dargestellt (vorher immer oben
        # links fixiert, mit toter Flaeche rechts/unten, wenn die Seite
        # kleiner als der sichtbare Bereich war - u. a. bei niedrigem Zoom
        # oder Querformat-Seiten deutlich sichtbar). _update_page_centering()
        # setzt scrollregion + Bildposition passend zur aktuellen
        # Canvas-Groesse; ist zusaetzlich an <Configure> gebunden (siehe
        # __init__), damit die Zentrierung auch beim Zoomen (das die Seite
        # neu rendert) und bei Fenster-Groessenaenderungen erhalten bleibt.
        self._update_page_centering()

        if reset_scroll:
            self._canvas.xview_moveto(0)
            self._canvas.yview_moveto(0)

        if self._overlay_callback is not None:
            try:
                self._overlay_callback()
            except Exception as exc:  # noqa: BLE001
                log_exception("Fehler im Overlay-Callback der Dokumentenansicht", exc)

        self._page_label.configure(text=f"{t('preview_page')} {self._page_index + 1}/{self._document.page_count}")
        self._prev_button.configure(state="normal" if self._page_index > 0 else "disabled")
        self._next_button.configure(state="normal" if self._page_index < self._document.page_count - 1 else "disabled")
        self._zoom_in_button.configure(state="normal")
        self._zoom_out_button.configure(state="normal")
        self._preview_strip.set_current_page(self._page_index)

    def show_prev_page(self) -> None:
        if self._document and self._page_index > 0:
            self._page_index -= 1
            self._render_current_page(reset_scroll=True)

    def show_next_page(self) -> None:
        if self._document and self._page_index < self._document.page_count - 1:
            self._page_index += 1
            self._render_current_page(reset_scroll=True)

    def set_page_index(self, index: int) -> None:
        """Springt direkt zu einer Seite (0-basiert) - genutzt z. B. vom
        Lesezeichen-Modul, um beim Klick auf einen Eintrag zur
        passenden Seite zu navigieren."""
        if not self._document:
            return
        clamped = max(0, min(index, self._document.page_count - 1))
        self._page_index = clamped
        self._render_current_page(reset_scroll=True)

    def retranslate(self) -> None:
        """Aktualisiert statische Texte nach einem Sprachwechsel."""
        self._empty_label.configure(text=f"{t('preview_no_file')}\n{t('preview_no_file_hint')}")
        if not self._document:
            self._filename_label.configure(text=t("preview_no_file"))
        self._render_current_page(reset_scroll=False)

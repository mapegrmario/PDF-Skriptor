"""
file_list_sync.py
Behebt das Problem, dass frisch geladene Dateien in bereits geoeffneten
Modul-Ansichten nicht erscheinen: registriert einen Listener bei der
gemeinsamen Werkbank (file_manager), der die Werte eines CTkOptionMenu
automatisch aktualisiert, sobald Dateien hinzugefuegt oder entfernt
werden - unabhaengig davon, wann die Ansicht urspruenglich erstellt wurde.
"""

import os
from language import t


def sync_file_selector(widget, file_manager, on_change) -> None:
    """Haelt die Werte eines CTkOptionMenu mit der aktuellen Dateiliste synchron.

    widget: das CTkOptionMenu, dessen 'values' aktualisiert werden sollen.
    file_manager: die gemeinsame FileManager-Instanz.
    on_change: wird mit dem Dateinamen aufgerufen, sobald sich die aktuell
        ausgewaehlte Datei aendert (z. B. weil sie neu geladen wurde oder
        die bisherige Auswahl entfernt wurde) - so bleibt z. B. die
        Metadaten- oder Seitenanzeige konsistent mit der Auswahl.
    """
    def _update(files: list[str]) -> None:
        try:
            names = [os.path.basename(path) for path in files] or [t("no_files_loaded")]
            widget.configure(values=names)
            current = widget.get()
            if current not in names:
                widget.set(names[0])
                on_change(names[0])
        except Exception:  # noqa: BLE001
            pass  # Widget wurde zwischenzeitlich zerstoert

    file_manager.register_listener(_update)
    widget.bind("<Destroy>", lambda event: file_manager.unregister_listener(_update))


def sync_refresh_callback(widget, file_manager, refresh_callback) -> None:
    """Registriert eine beliebige Aktualisierungsfunktion (z. B. fuer eine
    komplette Dateiliste statt eines Dropdowns) bei der Werkbank und
    meldet sie automatisch ab, sobald das uebergebene Widget zerstoert wird.
    """
    def _update(files: list[str]) -> None:
        try:
            refresh_callback(files)
        except Exception:  # noqa: BLE001
            pass

    file_manager.register_listener(_update)
    widget.bind("<Destroy>", lambda event: file_manager.unregister_listener(_update))


def sync_active_file(widget, file_manager, on_active_change) -> None:
    """Haelt eine Modul-Ansicht mit der gemeinsamen aktiven Datei synchron.

    on_active_change wird sofort mit der aktuellen aktiven Datei aufgerufen
    (damit die Ansicht beim Erstellen sofort den richtigen Stand zeigt) und
    danach jedes Mal, wenn die aktive Datei sich aendert (z. B. weil in der
    Werkbank eine andere Datei angeklickt wurde). Meldet sich automatisch
    ab, sobald 'widget' zerstoert wird.
    """
    def _update(path: str | None) -> None:
        try:
            on_active_change(path)
        except Exception:  # noqa: BLE001
            pass

    file_manager.register_active_listener(_update)
    widget.bind("<Destroy>", lambda event: file_manager.unregister_active_listener(_update))
    _update(file_manager.get_active_file())


def load_result_file(file_manager, output_path: str) -> None:
    """Laedt eine frisch erzeugte Ergebnisdatei automatisch in die Werkbank
    und macht sie zur aktiven Datei (Echtzeit-Anzeige-Fix: vorher musste
    jede Bearbeitung - Drehen, Loeschen, Zusammenfuegen, Wasserzeichen usw. -
    erst gespeichert und die entstandene Datei danach manuell ueber
    "Dateien auswaehlen" erneut geladen werden, um das Ergebnis in der
    Dokumentenansicht zu sehen. document_view.py oeffnet die aktive Datei
    bei jedem Wechsel frisch von der Festplatte (siehe _load_document),
    daher reicht es, sie hier bekanntzumachen.).
    Fuer Werkzeuge mit mehreren Ergebnisdateien (z. B. Trennen) stattdessen
    load_result_files() verwenden."""
    file_manager.add_files([output_path])
    file_manager.set_active_file(output_path)


def load_result_files(file_manager, output_paths: list[str]) -> None:
    """Wie load_result_file(), aber fuer Werkzeuge mit mehreren
    Ergebnisdateien (z. B. Trennen in Einzelseiten): alle werden der
    Werkbank hinzugefuegt, die erste wird aktiv."""
    if not output_paths:
        return
    file_manager.add_files(output_paths)
    file_manager.set_active_file(output_paths[0])

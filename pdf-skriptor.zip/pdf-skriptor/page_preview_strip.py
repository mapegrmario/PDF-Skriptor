"""
page_preview_strip.py
Horizontaler Streifen mit einem kleinen Vorschaubild pro Seite der
aktiven Datei - platziert in document_view.py zwischen der Werkbank
(workbench_view.py, eine Ebene hoeher in app_window.py) und der
grossen Einzelseiten-Ansicht. Rein zur Navigation gedacht: ein Klick
auf ein Vorschaubild springt zu dieser Seite in der grossen Ansicht.
Im Unterschied zum Modul "Seiten neu ordnen" (reorder_ui.py, das
dieselbe render_thumbnails()-Funktion aus reorder_logic.py nutzt) ist
dieser Streifen bewusst NICHT per Drag & Drop umsortierbar - dafuer
gibt es bereits das dedizierte Werkzeug.
"""

import customtkinter as ctk
import theme
from reorder_logic import render_thumbnails
from scroll_helpers import bind_mousewheel_scroll

_THUMBNAIL_WIDTH = 48
_STRIP_HEIGHT = 130


class PagePreviewStrip(ctk.CTkFrame):
    """Zeigt eine horizontal scrollbare Reihe von Seiten-Miniaturen der
    aktiven Datei; hebt die aktuell angezeigte Seite hervor."""

    def __init__(self, master, on_page_click) -> None:
        super().__init__(master, fg_color="transparent")
        self._on_page_click = on_page_click
        self._cards: list[ctk.CTkFrame] = []
        self._images: list[ctk.CTkImage] = []
        self._current_index = 0

        self._scroll_area = ctk.CTkScrollableFrame(
            self, fg_color=theme.COLOR_BG_SECONDARY, corner_radius=theme.CORNER_RADIUS,
            orientation="horizontal", height=_STRIP_HEIGHT,
        )
        self._scroll_area.pack(fill="x", expand=True)
        bind_mousewheel_scroll(self._scroll_area, orientation="horizontal")

    def load(self, path: str | None) -> bool:
        """Baut den Streifen fuer eine neue aktive Datei komplett neu auf
        und gibt zurueck, ob er (mind. eine Miniatur) etwas anzuzeigen hat.
        Das Ein-/Ausblenden selbst obliegt bewusst dem aufrufenden
        document_view.py, da nur dieses die richtige Position in seinem
        Layout kennt (siehe dortiger Kommentar zu pack(before=...))."""
        self._clear()
        if not path:
            return False
        for index, pil_image in enumerate(render_thumbnails(path, width=_THUMBNAIL_WIDTH)):
            ctk_image = ctk.CTkImage(light_image=pil_image, dark_image=pil_image, size=pil_image.size)
            self._images.append(ctk_image)
            card = self._build_card(index, ctk_image)
            card.pack(side="left", padx=(theme.PADDING_SMALL, 0), pady=theme.PADDING_SMALL)
            self._cards.append(card)
        if self._cards:
            self._highlight(self._current_index)
        return bool(self._cards)

    def _build_card(self, index: int, ctk_image: ctk.CTkImage) -> ctk.CTkFrame:
        card = ctk.CTkFrame(
            self._scroll_area, fg_color=theme.COLOR_BG, corner_radius=theme.CORNER_RADIUS,
            border_width=1, border_color=theme.COLOR_BORDER,
        )
        image_label = ctk.CTkLabel(card, image=ctk_image, text="")
        image_label.pack(padx=theme.PADDING_SMALL, pady=(theme.PADDING_SMALL, 2))
        number_label = ctk.CTkLabel(
            card, text=str(index + 1), font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED,
        )
        number_label.pack(pady=(0, theme.PADDING_SMALL))
        for widget in (card, image_label, number_label):
            widget.bind("<Button-1>", lambda _event, i=index: self._on_page_click(i))
        return card

    def set_current_page(self, index: int) -> None:
        """Aktualisiert nur die Hervorhebung (z. B. nach Bild-/Zurueck-Weiter-
        Navigation in der grossen Ansicht), ohne die Miniaturen neu zu
        rendern."""
        self._current_index = index
        self._highlight(index)

    def _highlight(self, index: int) -> None:
        for i, card in enumerate(self._cards):
            is_current = i == index
            card.configure(
                border_color=theme.COLOR_ACCENT if is_current else theme.COLOR_BORDER,
                border_width=2 if is_current else 1,
            )

    def _clear(self) -> None:
        for card in self._cards:
            card.destroy()
        self._cards = []
        self._images = []

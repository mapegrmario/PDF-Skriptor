"""
organize_ui.py
Container-Ansicht fuer das Organisieren-Modul. Schaltet zwischen den
Unter-Werkzeugen Zusammenfuegen, Trennen, Drehen und Loeschen um.
"""

import customtkinter as ctk
from language import t
import theme
from organize_merge_ui import OrganizeMergeTool
from organize_split_ui import OrganizeSplitTool
from organize_rotate_ui import OrganizeRotateTool
from organize_delete_ui import OrganizeDeleteTool

_SUB_TOOLS = {
    "merge": ("organize_tab_merge", OrganizeMergeTool),
    "split": ("organize_tab_split", OrganizeSplitTool),
    "rotate": ("organize_tab_rotate", OrganizeRotateTool),
    "delete": ("organize_tab_delete", OrganizeDeleteTool),
}


class OrganizeView(ctk.CTkFrame):
    """Oberste Ansicht des Organisieren-Moduls mit Unter-Werkzeug-Auswahl."""

    def __init__(self, master, file_manager) -> None:
        super().__init__(master, fg_color=theme.COLOR_BG)
        self._file_manager = file_manager
        self._tool_container: ctk.CTkFrame | None = None
        self._active_tool: ctk.CTkFrame | None = None
        self._build_ui()
        self._show_tool("merge")

    def _build_ui(self) -> None:
        title = ctk.CTkLabel(self, text=t("nav_organize"), font=theme.font_title(), text_color=theme.COLOR_TEXT)
        title.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(theme.PADDING_LARGE, theme.PADDING_SMALL))

        self._key_by_display = {t(label_key): key for key, (label_key, _cls) in _SUB_TOOLS.items()}
        values = list(self._key_by_display.keys())
        self._selector = ctk.CTkSegmentedButton(self, values=values, command=self._handle_tool_selected)
        self._selector.set(values[0])
        self._selector.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        self._tool_container = ctk.CTkFrame(self, fg_color="transparent")
        self._tool_container.pack(fill="both", expand=True, padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_LARGE))

    def _handle_tool_selected(self, value: str) -> None:
        key = self._key_by_display.get(value)
        if key is not None:
            self._show_tool(key)

    def _show_tool(self, key: str) -> None:
        if self._active_tool is not None:
            self._active_tool.destroy()
        _label_key, tool_cls = _SUB_TOOLS[key]
        self._active_tool = tool_cls(self._tool_container, self._file_manager)
        self._active_tool.pack(fill="both", expand=True)

"""
cert_logic.py
Erzeugt ein selbstsigniertes X.509-Zertifikat (RSA 2048) samt privatem
Schluessel als PKCS#12-Datei fuer die digitale Signatur, oder merkt
sich den Pfad zu einem bereits vorhandenen Zertifikat. Das Passwort
wird nie gespeichert - nur die dadurch bereits verschluesselte
.p12-Datei selbst (wie das ~/.config/pdf-skriptor-Muster von
settings.py und signature_logic.py).
"""

import datetime
import json
import os
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.serialization import pkcs12
import settings as settings_store
from logger_setup import log_exception

_CERT_FILENAME = "signatur_zertifikat.p12"
_INFO_FILENAME = "signatur_zertifikat_info.json"


def _config_dir() -> str:
    path = os.path.join(os.path.expanduser("~"), ".config", "pdf-skriptor")
    os.makedirs(path, exist_ok=True)
    return path


def default_certificate_path() -> str:
    return os.path.join(_config_dir(), _CERT_FILENAME)


def _info_path() -> str:
    return os.path.join(_config_dir(), _INFO_FILENAME)


def generate_self_signed_certificate(common_name: str, email: str, organization: str, password: str) -> bool:
    """Erzeugt ein neues, 10 Jahre gueltiges Zertifikat und macht es zum
    aktiven Signatur-Zertifikat."""
    try:
        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        name_attrs = [x509.NameAttribute(NameOID.COMMON_NAME, common_name)]
        if email:
            name_attrs.append(x509.NameAttribute(NameOID.EMAIL_ADDRESS, email))
        if organization:
            name_attrs.append(x509.NameAttribute(NameOID.ORGANIZATION_NAME, organization))
        subject = issuer = x509.Name(name_attrs)

        valid_until = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=3650)
        cert = (
            x509.CertificateBuilder()
            .subject_name(subject).issuer_name(issuer).public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(datetime.datetime.now(datetime.timezone.utc))
            .not_valid_after(valid_until)
            .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
            .add_extension(
                x509.KeyUsage(
                    digital_signature=True, content_commitment=True, key_encipherment=False,
                    data_encipherment=False, key_agreement=False, key_cert_sign=False,
                    crl_sign=False, encipher_only=False, decipher_only=False,
                ),
                critical=True,
            )
            .sign(key, hashes.SHA256())
        )

        p12_bytes = pkcs12.serialize_key_and_certificates(
            name=b"pdf-skriptor-signatur", key=key, cert=cert, cas=None,
            encryption_algorithm=serialization.BestAvailableEncryption(password.encode("utf-8")),
        )
        cert_path = default_certificate_path()
        with open(cert_path, "wb") as file:
            file.write(p12_bytes)

        info = {
            "common_name": common_name, "email": email, "organization": organization,
            "valid_until": valid_until.strftime("%d.%m.%Y"), "source": "generated",
        }
        with open(_info_path(), "w", encoding="utf-8") as file:
            json.dump(info, file, ensure_ascii=False)

        settings_store.update_setting("certificate_path", cert_path)
        return True
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Erzeugen des Zertifikats", exc)
        return False


def use_external_certificate(path: str) -> None:
    """Merkt sich den Pfad zu einem bereits vorhandenen .p12/.pfx als
    aktives Zertifikat. Da das Passwort dabei nicht bekannt ist, wird
    keine Info-Datei angelegt - es wird nur der Dateiname angezeigt."""
    if os.path.exists(_info_path()):
        os.remove(_info_path())
    settings_store.update_setting("certificate_path", path)


def get_active_certificate_path() -> str | None:
    path = settings_store.load_settings().get("certificate_path")
    return path if path and os.path.exists(path) else None


def get_certificate_info() -> dict | None:
    """Anzeige-Infos zum aktiven Zertifikat: bei selbst erzeugten mit
    Name/E-Mail/Gueltigkeit, bei extern geladenen nur der Dateiname."""
    active_path = get_active_certificate_path()
    if not active_path:
        return None
    if active_path == default_certificate_path() and os.path.exists(_info_path()):
        try:
            with open(_info_path(), "r", encoding="utf-8") as file:
                info = json.load(file)
            info["path"] = active_path
            return info
        except (OSError, json.JSONDecodeError) as exc:
            log_exception("Zertifikatsinfo konnte nicht gelesen werden", exc)
    return {"path": active_path, "source": "external"}

"""
search_ui.py
Volltextsuche im aktiven Dokument (aehnlich Strg+F): Suchbegriff
eingeben, alle Treffer werden auf der jeweiligen Seite gelb markiert,
der aktuelle Treffer orange hervorgehoben; "Weiter"/"Zurück" springt
zwischen den Treffern inkl. Seitenwechsel. Reine Navigationshilfe -
es wird nichts in der Datei gespeichert.
"""

import os
import customtkinter as ctk
from language import t
import theme
from search_logic import find_matches
from file_list_sync import sync_active_file

_ACTIVE_COLOR = "#FF7A1A"
_OTHER_COLOR = "#FFE066"


class SearchView(ctk.CTkFrame):
    """Werkzeug-Panel fuer die Volltextsuche in der aktiven Datei."""

    def __init__(self, master, file_manager, document_view) -> None:
        super().__init__(master, fg_color=theme.COLOR_BG)
        self._file_manager = file_manager
        self._document_view = document_view
        self._active_path: str | None = None
        self._matches: list[dict] = []
        self._active_index: int | None = None
        self._build_ui()
        sync_active_file(self, self._file_manager, self._handle_active_changed)

    def _build_ui(self) -> None:
        title = ctk.CTkLabel(self, text=t("nav_search"), font=theme.font_title(), text_color=theme.COLOR_TEXT)
        title.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(theme.PADDING_LARGE, theme.PADDING_SMALL))

        self._active_file_label = ctk.CTkLabel(self, text="", font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED)
        self._active_file_label.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        self._search_entry = ctk.CTkEntry(self, placeholder_text=t("search_placeholder"))
        self._search_entry.pack(fill="x", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_SMALL))
        self._search_entry.bind("<Return>", self._handle_search)

        search_button = ctk.CTkButton(
            self, text=t("search_button"), fg_color=theme.COLOR_ACCENT, hover_color=theme.COLOR_ACCENT_HOVER,
            corner_radius=theme.CORNER_RADIUS, command=self._handle_search,
        )
        search_button.pack(fill="x", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_SMALL))

        nav_row = ctk.CTkFrame(self, fg_color="transparent")
        nav_row.pack(fill="x", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_SMALL))
        prev_button = ctk.CTkButton(
            nav_row, text="◀ " + t("search_prev"), fg_color="transparent", border_width=1,
            border_color=theme.COLOR_BORDER, text_color=theme.COLOR_TEXT, hover_color=theme.COLOR_ACCENT_SOFT,
            corner_radius=theme.CORNER_RADIUS, command=self._handle_prev,
        )
        prev_button.pack(side="left", fill="x", expand=True, padx=(0, 4))
        next_button = ctk.CTkButton(
            nav_row, text=t("search_next") + " ▶", fg_color="transparent", border_width=1,
            border_color=theme.COLOR_BORDER, text_color=theme.COLOR_TEXT, hover_color=theme.COLOR_ACCENT_SOFT,
            corner_radius=theme.CORNER_RADIUS, command=self._handle_next,
        )
        next_button.pack(side="left", fill="x", expand=True, padx=(4, 0))

        self._counter_label = ctk.CTkLabel(self, text="", font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED)
        self._counter_label.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_LARGE))

    def _handle_active_changed(self, path: str | None) -> None:
        self._active_path = path
        if path:
            self._active_file_label.configure(text=f"📄 {os.path.basename(path)}")
        else:
            self._active_file_label.configure(text=t("no_active_file_hint"))
        self._reset_matches()

    def on_shown(self) -> None:
        self._document_view.set_overlay_callback(self._draw_overlays)
        self._document_view.refresh()

    def on_hidden(self) -> None:
        self._document_view.clear_overlay_callback()

    def _reset_matches(self) -> None:
        self._matches = []
        self._active_index = None
        self._counter_label.configure(text="")
        self._document_view.refresh()

    def _handle_search(self, event=None) -> None:
        term = self._search_entry.get().strip()
        if not self._active_path or not term:
            self._reset_matches()
            return
        self._matches = find_matches(self._active_path, term)
        self._active_index = 0 if self._matches else None
        self._update_counter()
        if self._active_index is not None:
            self._jump_to_active()
        else:
            self._document_view.refresh()

    def _handle_next(self) -> None:
        if not self._matches:
            return
        self._active_index = (self._active_index + 1) % len(self._matches)
        self._update_counter()
        self._jump_to_active()

    def _handle_prev(self) -> None:
        if not self._matches:
            return
        self._active_index = (self._active_index - 1) % len(self._matches)
        self._update_counter()
        self._jump_to_active()

    def _update_counter(self) -> None:
        if not self._matches:
            self._counter_label.configure(text=t("search_no_matches"))
        else:
            self._counter_label.configure(
                text=t("search_match_counter").format(current=self._active_index + 1, total=len(self._matches))
            )

    def _jump_to_active(self) -> None:
        match = self._matches[self._active_index]
        if match["page"] != self._document_view.get_page_index():
            self._document_view.set_page_index(match["page"])
        else:
            self._document_view.refresh()
        self._scroll_to_match(match)

    def _scroll_to_match(self, match: dict) -> None:
        canvas = self._document_view.get_canvas()
        zoom = self._document_view.get_zoom()
        region = canvas.cget("scrollregion")
        if not region:
            return
        _, _, _, total_height = [float(value) for value in region.split()]
        if total_height <= 0:
            return
        target_y = match["rect"][1] * zoom
        fraction = max(0.0, min(1.0, (target_y - 60) / total_height))
        canvas.yview_moveto(fraction)

    def _draw_overlays(self) -> None:
        canvas = self._document_view.get_canvas()
        zoom = self._document_view.get_zoom()
        page_index = self._document_view.get_page_index()
        for index, match in enumerate(self._matches):
            if match["page"] != page_index:
                continue
            x0, y0, x1, y1 = [value * zoom for value in match["rect"]]
            if index == self._active_index:
                canvas.create_rectangle(x0, y0, x1, y1, fill=_ACTIVE_COLOR, outline=_ACTIVE_COLOR, stipple="gray75")
            else:
                canvas.create_rectangle(x0, y0, x1, y1, fill=_OTHER_COLOR, outline="", stipple="gray50")

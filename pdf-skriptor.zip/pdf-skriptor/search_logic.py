"""
search_logic.py
Durchsucht eine PDF-Datei seitenweise nach einem Suchbegriff und
liefert je Treffer Seite und Position (Rechteck in Seiten-Koordinaten)
zurueck - Grundlage fuer die Volltextsuche mit Trefferhervorhebung in
der Dokumentenansicht (aehnlich Strg+F im Firefox-PDF-Betrachter).
"""

import pymupdf as fitz  # "fitz" ist der veraltete Alias, siehe PyMuPDF-Deprecation-Hinweis
from logger_setup import log_exception


def find_matches(path: str, term: str) -> list[dict]:
    """Liefert alle Treffer ueber die gesamte Datei, sortiert nach Seite
    und Position auf der Seite. Jeder Treffer: {"page": 0-basierte
    Seitenzahl, "rect": [x0, y0, x1, y1]}. Leere Liste bei leerem
    Suchbegriff, fehlender Datei oder keinem Treffer. Gross-/
    Kleinschreibung wird nicht unterschieden (PyMuPDF-Standardverhalten)."""
    if not term.strip():
        return []
    matches: list[dict] = []
    try:
        document = fitz.open(path)
        for page_index, page in enumerate(document):
            for rect in page.search_for(term):
                matches.append({"page": page_index, "rect": [rect.x0, rect.y0, rect.x1, rect.y1]})
        document.close()
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler bei der Volltextsuche", exc)
    return matches

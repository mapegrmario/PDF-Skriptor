"""
compare_logic.py
Vergleicht den Textinhalt zweier PDF-Dateien seitenweise und liefert
eine zeilenbasierte Diff-Darstellung (hinzugefügt/entfernt/unverändert).
"""

import difflib
import pymupdf as fitz  # "fitz" ist der veraltete Alias, siehe PyMuPDF-Deprecation-Hinweis
from logger_setup import log_exception


def extract_page_texts(path: str) -> list[str]:
    """Liest den Text jeder Seite einer PDF-Datei aus."""
    try:
        document = fitz.open(path)
        texts = [page.get_text() for page in document]
        document.close()
        return texts
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Lesen des PDF-Textes für Vergleich", exc)
        return []


def compare_texts(text_a: str, text_b: str) -> list[tuple[str, str]]:
    """Erstellt eine zeilenweise Diff-Liste: (Markierung, Zeileninhalt)."""
    lines_a = text_a.splitlines()
    lines_b = text_b.splitlines()
    matcher = difflib.SequenceMatcher(None, lines_a, lines_b)
    result = []
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            for line in lines_a[i1:i2]:
                result.append(("=", line))
        elif tag == "delete":
            for line in lines_a[i1:i2]:
                result.append(("-", line))
        elif tag == "insert":
            for line in lines_b[j1:j2]:
                result.append(("+", line))
        elif tag == "replace":
            for line in lines_a[i1:i2]:
                result.append(("-", line))
            for line in lines_b[j1:j2]:
                result.append(("+", line))
    return result


def compare_documents(path_a: str, path_b: str) -> dict:
    """Vergleicht zwei PDF-Dokumente Seite fuer Seite und liefert Statistik + Diffs."""
    texts_a = extract_page_texts(path_a)
    texts_b = extract_page_texts(path_b)
    max_pages = max(len(texts_a), len(texts_b))

    pages = []
    for index in range(max_pages):
        text_a = texts_a[index] if index < len(texts_a) else ""
        text_b = texts_b[index] if index < len(texts_b) else ""
        diff = compare_texts(text_a, text_b)
        added = sum(1 for tag, _ in diff if tag == "+")
        removed = sum(1 for tag, _ in diff if tag == "-")
        pages.append({"page": index + 1, "diff": diff, "added": added, "removed": removed})

    return {
        "page_count_a": len(texts_a),
        "page_count_b": len(texts_b),
        "pages": pages,
    }

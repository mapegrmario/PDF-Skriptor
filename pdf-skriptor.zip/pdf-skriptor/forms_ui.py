"""
forms_ui.py
UI fuer das Formulare-Modul: zeigt alle Formularfelder der aktiven
PDF-Datei in einer scrollbaren Liste an und speichert die
ausgefuellten Werte.
"""

import os
import tkinter.filedialog as filedialog
from tkinter import messagebox
import customtkinter as ctk
from language import t
import settings as settings_store
import theme
from scroll_helpers import bind_mousewheel_scroll
from forms_logic import get_form_fields, fill_form
from file_list_sync import sync_active_file, load_result_file


class FormsView(ctk.CTkFrame):
    """Ansicht zum Ausfuellen von PDF-Formularen der aktiven Datei."""

    def __init__(self, master, file_manager) -> None:
        super().__init__(master, fg_color=theme.COLOR_BG)
        self._file_manager = file_manager
        self._active_path: str | None = None
        self._field_widgets: dict[str, ctk.CTkBaseClass] = {}
        self._scroll_area: ctk.CTkScrollableFrame | None = None
        self._build_ui()
        sync_active_file(self, self._file_manager, self._handle_active_changed)

    def _build_ui(self) -> None:
        title = ctk.CTkLabel(self, text=t("nav_forms"), font=theme.font_title(), text_color=theme.COLOR_TEXT)
        title.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(theme.PADDING_LARGE, theme.PADDING_SMALL))

        self._active_file_label = ctk.CTkLabel(self, text="", font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED)
        self._active_file_label.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        self._scroll_area = ctk.CTkScrollableFrame(self, fg_color=theme.COLOR_BG_SECONDARY, corner_radius=theme.CORNER_RADIUS)
        self._scroll_area.pack(fill="both", expand=True, padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))
        bind_mousewheel_scroll(self._scroll_area)

        save_button = ctk.CTkButton(
            self, text=t("forms_save_button"), fg_color=theme.COLOR_ACCENT,
            hover_color=theme.COLOR_ACCENT_HOVER, corner_radius=theme.CORNER_RADIUS,
            command=self._handle_save,
        )
        save_button.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_LARGE))

    def _handle_active_changed(self, path: str | None) -> None:
        self._active_path = path
        if path:
            self._active_file_label.configure(text=f"📄 {os.path.basename(path)}")
        else:
            self._active_file_label.configure(text=t("no_active_file_hint"))
        self._load_fields()

    def _load_fields(self) -> None:
        for child in self._scroll_area.winfo_children():
            child.destroy()
        self._field_widgets.clear()

        if not self._active_path:
            self._show_empty_hint(t("no_active_file_hint"))
            return

        fields = get_form_fields(self._active_path)
        if not fields:
            self._show_empty_hint("Diese Datei enthält keine ausfüllbaren Formularfelder.")
            return

        for field in fields:
            self._add_field_row(field)

    def _show_empty_hint(self, text: str) -> None:
        label = ctk.CTkLabel(self._scroll_area, text=text, font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED)
        label.pack(padx=theme.PADDING_MEDIUM, pady=theme.PADDING_MEDIUM)

    def _add_field_row(self, field: dict) -> None:
        row = ctk.CTkFrame(self._scroll_area, fg_color="transparent")
        row.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=theme.PADDING_SMALL)

        label = ctk.CTkLabel(
            row, text=field["label"], font=theme.font_small(), text_color=theme.COLOR_TEXT, anchor="w",
            wraplength=300, justify="left",
        )
        label.pack(anchor="w")

        if field["type"] == "checkbox":
            var = ctk.BooleanVar(value=field["value"] not in ("", "/Off", "Off"))
            widget = ctk.CTkCheckBox(row, text="", variable=var)
            widget.pack(anchor="w", pady=(2, 0))
            self._field_widgets[field["name"]] = var
        else:
            entry = ctk.CTkEntry(row)
            entry.insert(0, field["value"])
            entry.pack(fill="x", pady=(2, 0))
            self._field_widgets[field["name"]] = entry

    def _collect_values(self) -> dict:
        values = {}
        for name, widget in self._field_widgets.items():
            if isinstance(widget, ctk.BooleanVar):
                values[name] = "/Yes" if widget.get() else "/Off"
            else:
                values[name] = widget.get()
        return values

    def _handle_save(self) -> None:
        if not self._active_path or not self._field_widgets:
            messagebox.showinfo(t("app_title"), "Keine Formularfelder zum Speichern vorhanden.")
            return

        settings = settings_store.load_settings()
        base_name = os.path.splitext(os.path.basename(self._active_path))[0]
        default_path = os.path.join(settings.get("output_dir", "~"), f"{base_name}_ausgefuellt.pdf")
        output_path = filedialog.asksaveasfilename(
            initialfile=os.path.basename(default_path),
            initialdir=os.path.dirname(default_path),
            defaultextension=".pdf",
            filetypes=[("PDF-Dateien", "*.pdf")],
        )
        if not output_path:
            return

        success = fill_form(self._active_path, output_path, self._collect_values())
        if success:
            load_result_file(self._file_manager, output_path)
            messagebox.showinfo(t("app_title"), t("save_success"))
        else:
            messagebox.showerror(t("app_title"), t("error_generic"))


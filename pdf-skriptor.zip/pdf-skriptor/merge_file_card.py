"""
merge_file_card.py
Eine einzelne, per Maus verschiebbare Datei-Karte fuer die Reihenfolge
im "Zusammenfuegen"-Unterwerkzeug von Organisieren (QA-Fix: die
Reihenfolge liess sich vorher nirgends direkt aendern, siehe
Usability-Audit). Technisch identisches Drag-Verhalten wie
reorder_card.py, nur mit Dateiname statt Seiten-Miniatur.
"""

import os
import customtkinter as ctk
import theme


class MergeFileCard(ctk.CTkFrame):
    """Zeigt eine Datei mit laufender Nummer; leitet Maus-Ereignisse an
    die uebergeordnete Ansicht weiter, die die Liste neu sortiert."""

    def __init__(self, master, path: str, on_drag_start, on_drag_motion, on_drag_end) -> None:
        super().__init__(
            master, fg_color=theme.COLOR_BG, corner_radius=theme.CORNER_RADIUS,
            border_width=1, border_color=theme.COLOR_BORDER,
        )
        self.path = path
        self._on_drag_start = on_drag_start
        self._on_drag_motion = on_drag_motion
        self._on_drag_end = on_drag_end
        self._build_ui()

    def _build_ui(self) -> None:
        self._number_label = ctk.CTkLabel(self, text="", font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED, width=22)
        self._number_label.pack(padx=(theme.PADDING_SMALL, 2), pady=theme.PADDING_SMALL, side="left")

        name_label = ctk.CTkLabel(
            self, text=f"⠿ {os.path.basename(self.path)}", font=theme.font_body(), text_color=theme.COLOR_TEXT, anchor="w",
        )
        name_label.pack(padx=(0, theme.PADDING_SMALL), pady=theme.PADDING_SMALL, side="left", fill="x", expand=True)

        for widget in (self, self._number_label, name_label):
            widget.bind("<ButtonPress-1>", self._handle_press)
            widget.bind("<B1-Motion>", self._handle_motion)
            widget.bind("<ButtonRelease-1>", self._handle_release)

    def set_position(self, position: int) -> None:
        self._number_label.configure(text=f"{position}.")

    def _handle_press(self, event) -> None:
        self._on_drag_start(self)

    def _handle_motion(self, event) -> None:
        self._on_drag_motion(self, self.winfo_pointery())

    def _handle_release(self, event) -> None:
        self._on_drag_end(self)

    def set_dragging(self, dragging: bool) -> None:
        self.configure(
            border_color=theme.COLOR_ACCENT if dragging else theme.COLOR_BORDER,
            border_width=2 if dragging else 1,
        )

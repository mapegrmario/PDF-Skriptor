"""
compare_ui.py
UI fuer das Vergleich-Modul: zwei Dateien aus der Werkbank auswaehlen
und eine farbig markierte, seitenweise Diff-Ansicht anzeigen.
"""

import os
import customtkinter as ctk
from language import t
import theme
from scroll_helpers import bind_mousewheel_scroll
from compare_logic import compare_documents
from file_list_sync import sync_refresh_callback

_COLOR_ADDED = "#E4F7EA"
_COLOR_REMOVED = "#FBE8E7"
_TEXT_ADDED = "#1E7A3C"
_TEXT_REMOVED = "#B8352F"


class CompareView(ctk.CTkFrame):
    """Ansicht zum Vergleich zweier PDF-Versionen."""

    def __init__(self, master, file_manager) -> None:
        super().__init__(master, fg_color=theme.COLOR_BG)
        self._file_manager = file_manager
        self._path_a: str | None = None
        self._path_b: str | None = None
        self._result_area: ctk.CTkScrollableFrame | None = None
        self._build_ui()

    def _build_ui(self) -> None:
        title = ctk.CTkLabel(self, text=t("compare_title"), font=theme.font_title(), text_color=theme.COLOR_TEXT)
        title.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(theme.PADDING_LARGE, theme.PADDING_SMALL))

        label_a = ctk.CTkLabel(self, text=t("compare_file_a"), font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED)
        label_a.pack(anchor="w", padx=theme.PADDING_LARGE)

        files = self._file_manager.get_files()
        file_names = [os.path.basename(path) for path in files] or [t("no_files_loaded")]

        self._selector_a = ctk.CTkOptionMenu(self, values=file_names, command=self._handle_a_selected)
        self._selector_a.pack(fill="x", padx=theme.PADDING_LARGE, pady=(2, theme.PADDING_SMALL))

        label_b = ctk.CTkLabel(self, text=t("compare_file_b"), font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED)
        label_b.pack(anchor="w", padx=theme.PADDING_LARGE)

        self._selector_b = ctk.CTkOptionMenu(self, values=file_names, command=self._handle_b_selected)
        self._selector_b.pack(fill="x", padx=theme.PADDING_LARGE, pady=(2, theme.PADDING_MEDIUM))

        if len(files) >= 2:
            self._path_a, self._path_b = files[0], files[1]
            self._selector_b.set(os.path.basename(files[1]))

        compare_button = ctk.CTkButton(
            self, text=t("compare_button"), fg_color=theme.COLOR_ACCENT, hover_color=theme.COLOR_ACCENT_HOVER,
            corner_radius=theme.CORNER_RADIUS, command=self._handle_compare,
        )
        compare_button.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        self._result_area = ctk.CTkScrollableFrame(self, fg_color=theme.COLOR_BG_SECONDARY, corner_radius=theme.CORNER_RADIUS)
        self._result_area.pack(fill="both", expand=True, padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_LARGE))
        bind_mousewheel_scroll(self._result_area)

        sync_refresh_callback(self, self._file_manager, self._handle_files_changed)

    def _handle_files_changed(self, files: list[str]) -> None:
        """Haelt beide Datei-Selektoren aktuell; Datei B bevorzugt die zweite
        verfuegbare Datei, damit ein sinnvoller Vergleich vorbelegt ist."""
        names = [os.path.basename(path) for path in files] or [t("no_files_loaded")]
        self._selector_a.configure(values=names)
        self._selector_b.configure(values=names)

        current_a = self._selector_a.get()
        if current_a not in names:
            self._selector_a.set(names[0])
            self._handle_a_selected(names[0])

        current_b = self._selector_b.get()
        if current_b not in names:
            default_b = names[1] if len(names) > 1 else names[0]
            self._selector_b.set(default_b)
            self._handle_b_selected(default_b)

    def _handle_a_selected(self, name: str) -> None:
        self._path_a = self._resolve_path(name)

    def _handle_b_selected(self, name: str) -> None:
        self._path_b = self._resolve_path(name)

    def _resolve_path(self, name: str) -> str | None:
        for path in self._file_manager.get_files():
            if os.path.basename(path) == name:
                return path
        return None

    def _handle_compare(self) -> None:
        for child in self._result_area.winfo_children():
            child.destroy()

        if not self._path_a or not self._path_b:
            self._add_info_line("Bitte zwei Dateien zum Vergleich auswählen.")
            return

        result = compare_documents(self._path_a, self._path_b)
        summary = ctk.CTkLabel(
            self._result_area,
            text=f"{result['page_count_a']} Seiten vs. {result['page_count_b']} Seiten",
            font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED,
        )
        summary.pack(anchor="w", padx=theme.PADDING_MEDIUM, pady=(theme.PADDING_MEDIUM, theme.PADDING_SMALL))

        for page_info in result["pages"]:
            if page_info["added"] == 0 and page_info["removed"] == 0:
                continue
            self._add_page_diff(page_info)

    def _add_page_diff(self, page_info: dict) -> None:
        heading = ctk.CTkLabel(
            self._result_area, text=f"Seite {page_info['page']}  (+{page_info['added']} / −{page_info['removed']})",
            font=theme.font_heading(), text_color=theme.COLOR_ACCENT,
        )
        heading.pack(anchor="w", padx=theme.PADDING_MEDIUM, pady=(theme.PADDING_MEDIUM, 2))

        for tag, line in page_info["diff"]:
            if tag == "=":
                continue
            color = _TEXT_ADDED if tag == "+" else _TEXT_REMOVED
            bg = _COLOR_ADDED if tag == "+" else _COLOR_REMOVED
            prefix = "+ " if tag == "+" else "− "
            row = ctk.CTkLabel(
                self._result_area, text=prefix + line, font=theme.font_small(), text_color=color,
                fg_color=bg, anchor="w", wraplength=300, justify="left",
            )
            row.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=1)

    def _add_info_line(self, text: str) -> None:
        label = ctk.CTkLabel(self._result_area, text=text, font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED)
        label.pack(padx=theme.PADDING_MEDIUM, pady=theme.PADDING_MEDIUM)


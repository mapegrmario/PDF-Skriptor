#!/bin/bash
# ============================================================================
# run.sh - Startet PDF Skriptor unabhaengig vom aktuellen Arbeitsverzeichnis.
# Wird vom Startmenü-Eintrag (pdf-skriptor.desktop) aufgerufen.
# ============================================================================

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR" || exit 1

if [ ! -d "venv" ]; then
    echo "Virtuelle Umgebung nicht gefunden. Bitte zuerst './install.sh' ausführen." >&2
    exit 1
fi

# shellcheck disable=SC1091
source venv/bin/activate
exec python3 main.py

"""
compress_logic.py
Komprimiert PDF-Dateien ueber das systemweit installierte Ghostscript.
Bietet mehrere Qualitaetsstufen und liefert Groessenvergleiche, damit
der Nutzer vor dem endgueltigen Speichern eine informierte Wahl trifft.
"""

import os
import shutil
import subprocess
from logger_setup import log_exception

QUALITY_PRESETS = {
    "hoch": "/prepress",
    "mittel": "/ebook",
    "niedrig": "/screen",
}


def is_ghostscript_available() -> bool:
    return shutil.which("gs") is not None


def get_file_size_kb(path: str) -> float:
    try:
        return os.path.getsize(path) / 1024
    except OSError:
        return 0.0


def compress_pdf(input_path: str, output_path: str, quality: str = "mittel") -> bool:
    """Komprimiert eine PDF-Datei mit der gewaehlten Qualitaetsstufe."""
    if not is_ghostscript_available():
        return False

    setting = QUALITY_PRESETS.get(quality, "/ebook")
    command = [
        "gs", "-sDEVICE=pdfwrite", "-dCompatibilityLevel=1.4",
        f"-dPDFSETTINGS={setting}", "-dNOPAUSE", "-dBATCH", "-dQUIET",
        f"-sOutputFile={output_path}", input_path,
    ]
    try:
        result = subprocess.run(command, capture_output=True, timeout=120, check=False)
        if result.returncode != 0:
            log_exception("Ghostscript Fehlercode", Exception(result.stderr.decode(errors="ignore")))
            return False
        return os.path.isfile(output_path)
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler bei der PDF-Komprimierung", exc)
        return False


def estimate_all_qualities(input_path: str, temp_dir: str) -> dict:
    """Erstellt fuer jede Qualitaetsstufe eine temporaere Datei und gibt Groessen zurueck."""
    original_size = get_file_size_kb(input_path)
    results = {"original": original_size}
    for quality in QUALITY_PRESETS:
        temp_output = os.path.join(temp_dir, f"vorschau_{quality}.pdf")
        if compress_pdf(input_path, temp_output, quality):
            results[quality] = get_file_size_kb(temp_output)
        else:
            results[quality] = None
    return results

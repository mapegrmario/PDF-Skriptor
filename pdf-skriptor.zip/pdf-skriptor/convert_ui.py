"""
convert_ui.py
UI fuer das Konvertierung-Modul: Format waehlen (Markdown/Text),
Tabellenerkennung anzeigen und Ergebnis als Datei speichern. Arbeitet
immer mit der aktuell aktiven Datei aus der Werkbank.
"""

import os
import tkinter.filedialog as filedialog
from tkinter import messagebox
import customtkinter as ctk
from language import t
import settings as settings_store
import theme
from convert_logic import convert_to_text, convert_to_markdown, count_detected_tables
from file_list_sync import sync_active_file


class ConvertView(ctk.CTkFrame):
    """Ansicht zur Konvertierung der aktiven Datei nach Markdown oder Text."""

    def __init__(self, master, file_manager) -> None:
        super().__init__(master, fg_color=theme.COLOR_BG)
        self._file_manager = file_manager
        self._active_path: str | None = None
        self._last_result = ""
        self._build_ui()
        sync_active_file(self, self._file_manager, self._handle_active_changed)

    def _build_ui(self) -> None:
        title = ctk.CTkLabel(self, text=t("nav_convert"), font=theme.font_title(), text_color=theme.COLOR_TEXT)
        title.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(theme.PADDING_LARGE, theme.PADDING_SMALL))

        self._active_file_label = ctk.CTkLabel(self, text="", font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED)
        self._active_file_label.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_SMALL))

        control_row = ctk.CTkFrame(self, fg_color="transparent")
        control_row.pack(fill="x", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        self._format_selector = ctk.CTkSegmentedButton(control_row, values=["Markdown", t("convert_plain_text")])
        self._format_selector.set("Markdown")
        self._format_selector.pack(side="left")

        preview_button = ctk.CTkButton(
            self, text=t("convert_generate_preview"), fg_color="transparent", border_width=1, border_color=theme.COLOR_BORDER,
            text_color=theme.COLOR_TEXT, hover_color=theme.COLOR_ACCENT_SOFT, corner_radius=theme.CORNER_RADIUS,
            command=self._handle_preview,
        )
        preview_button.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        self._info_label = ctk.CTkLabel(self, text="", font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED)
        self._info_label.pack(anchor="w", padx=theme.PADDING_LARGE)

        self._preview_box = ctk.CTkTextbox(self, fg_color=theme.COLOR_BG_SECONDARY, corner_radius=theme.CORNER_RADIUS)
        self._preview_box.pack(fill="both", expand=True, padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        save_button = ctk.CTkButton(
            self, text=t("convert_save_as_file"), fg_color=theme.COLOR_ACCENT, hover_color=theme.COLOR_ACCENT_HOVER,
            corner_radius=theme.CORNER_RADIUS, command=self._handle_save,
        )
        save_button.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_LARGE))

    def _handle_active_changed(self, path: str | None) -> None:
        self._active_path = path
        self._last_result = ""
        if path:
            self._active_file_label.configure(text=f"📄 {os.path.basename(path)}")
        else:
            self._active_file_label.configure(text=t("no_active_file_hint"))
        self._preview_box.delete("1.0", "end")
        self._info_label.configure(text="")

    def _handle_preview(self) -> None:
        if not self._active_path:
            messagebox.showinfo(t("app_title"), t("no_active_file_hint"))
            return

        is_markdown = self._format_selector.get() == "Markdown"
        self._last_result = convert_to_markdown(self._active_path) if is_markdown else convert_to_text(self._active_path)

        self._preview_box.delete("1.0", "end")
        self._preview_box.insert("1.0", self._last_result)

        if is_markdown:
            table_count = count_detected_tables(self._active_path)
            self._info_label.configure(text=t("convert_tables_detected").format(n=table_count))
        else:
            self._info_label.configure(text=t("convert_plain_text_info"))

    def _handle_save(self) -> None:
        if not self._last_result:
            messagebox.showinfo(t("app_title"), t("convert_preview_first"))
            return

        is_markdown = self._format_selector.get() == "Markdown"
        extension = ".md" if is_markdown else ".txt"
        settings = settings_store.load_settings()
        base_name = os.path.splitext(os.path.basename(self._active_path))[0]
        default_path = os.path.join(settings.get("output_dir", "~"), f"{base_name}{extension}")

        output_path = filedialog.asksaveasfilename(
            initialfile=os.path.basename(default_path),
            initialdir=os.path.dirname(default_path),
            defaultextension=extension,
            filetypes=[("Markdown", "*.md"), ("Text", "*.txt")],
        )
        if not output_path:
            return

        try:
            with open(output_path, "w", encoding="utf-8") as file:
                file.write(self._last_result)
            messagebox.showinfo(t("app_title"), t("save_success"))
        except OSError:
            messagebox.showerror(t("app_title"), t("error_generic"))

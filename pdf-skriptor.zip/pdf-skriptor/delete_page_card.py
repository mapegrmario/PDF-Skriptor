"""
delete_page_card.py
Eine einzelne, anklickbare Seiten-Vorschaukarte fuer die visuelle
Seitenauswahl im "Loeschen"-Unterwerkzeug von Organisieren (QA-Fix:
vorher nur Texteingabe moeglich, siehe Usability-Audit). Analog zu
reorder_card.py, aber togglebar statt ziehbar - ein Klick markiert die
Seite zum Loeschen, ein weiterer Klick hebt die Markierung auf.
"""

import customtkinter as ctk
import theme

_SELECTED_BORDER = "#DC2626"


class DeletePageCard(ctk.CTkFrame):
    """Zeigt ein Seiten-Vorschaubild; togglet per Klick den
    Auswahlzustand und meldet ihn an die uebergeordnete Ansicht."""

    def __init__(self, master, page_number: int, thumbnail_image: ctk.CTkImage, on_toggle) -> None:
        super().__init__(
            master, fg_color=theme.COLOR_BG_SECONDARY, corner_radius=theme.CORNER_RADIUS,
            border_width=1, border_color=theme.COLOR_BORDER,
        )
        self.page_number = page_number
        self._on_toggle = on_toggle
        self._selected = False
        self._build_ui(thumbnail_image)

    def _build_ui(self, thumbnail_image: ctk.CTkImage) -> None:
        self._image_label = ctk.CTkLabel(self, image=thumbnail_image, text="")
        self._image_label.pack(padx=theme.PADDING_SMALL, pady=(theme.PADDING_SMALL, 2))

        self._number_label = ctk.CTkLabel(
            self, text=str(self.page_number), font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED,
        )
        self._number_label.pack(pady=(0, theme.PADDING_SMALL))

        for widget in (self, self._image_label, self._number_label):
            widget.bind("<ButtonPress-1>", self._handle_click)

    def _handle_click(self, event) -> None:
        self.set_selected(not self._selected)
        self._on_toggle(self.page_number, self._selected)

    def set_selected(self, selected: bool) -> None:
        self._selected = selected
        self.configure(
            border_color=_SELECTED_BORDER if selected else theme.COLOR_BORDER,
            border_width=2 if selected else 1,
        )
        self._number_label.configure(text_color=_SELECTED_BORDER if selected else theme.COLOR_TEXT_MUTED)

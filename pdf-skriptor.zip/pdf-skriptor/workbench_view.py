"""
workbench_view.py
Kompakte Werkbank am oberen Rand des Hauptfensters. Zeigt alle
geladenen PDF-Dateien als anklickbare "Chips" - ein Klick macht die
Datei zur aktiven Datei, mit der alle Werkzeuge arbeiten und die in
der zentralen Dokumentenansicht erscheint. Bei vielen geladenen
Dateien wird der Bereich vertikal scrollbar, statt untere Zeilen
abzuschneiden. Bewusst kompakt gehalten, damit die rechte Menü-/
Werkzeug-Spalte (die sich unabhaengig davon ueber die gesamte
Fensterhoehe erstreckt) moeglichst viel vertikalen Platz hat.
"""

import os
import tkinter.filedialog as filedialog
import customtkinter as ctk
from language import t
import theme
from scroll_helpers import bind_mousewheel_scroll

_CHIP_WIDTH = 190
_CHIP_HEIGHT = 32
_CHIP_GAP = 8
_CHIP_ROW_VISIBLE_HEIGHT = 46  # zeigt eine Zeile, Rest scrollbar - kompakt
_MAX_NAME_LENGTH = 22


def _truncate_name(name: str) -> str:
    if len(name) <= _MAX_NAME_LENGTH:
        return name
    return name[: _MAX_NAME_LENGTH - 1] + "…"


class WorkbenchView(ctk.CTkFrame):
    """Kopfbereich mit Dateiauswahl-Chips."""

    def __init__(self, master, file_manager) -> None:
        super().__init__(master, fg_color=theme.COLOR_BG_SECONDARY, corner_radius=0)
        self._file_manager = file_manager
        self._chip_buttons: dict[str, ctk.CTkButton] = {}
        self._chip_row: ctk.CTkScrollableFrame | None = None
        self._current_columns = 4
        self._build_ui()

        self._file_manager.register_listener(self._on_files_changed)
        self._file_manager.register_active_listener(self._on_active_changed)
        self.bind("<Destroy>", self._handle_destroy)

        self._on_files_changed(self._file_manager.get_files())

    def _build_ui(self) -> None:
        self.grid_columnconfigure(0, weight=1)

        button_row = ctk.CTkFrame(self, fg_color="transparent")
        button_row.grid(row=0, column=0, sticky="ew", padx=theme.PADDING_MEDIUM, pady=(theme.PADDING_SMALL, 4))
        button_row.grid_columnconfigure(0, weight=1)

        self._title_label = ctk.CTkLabel(
            button_row, text=t("no_files_loaded"), font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED,
        )
        self._title_label.grid(row=0, column=0, sticky="w")

        self._select_button = ctk.CTkButton(
            button_row, text=t("select_files"), fg_color=theme.COLOR_ACCENT,
            hover_color=theme.COLOR_ACCENT_HOVER, corner_radius=theme.CORNER_RADIUS,
            command=self._handle_select_files,
        )
        self._select_button.grid(row=0, column=1, padx=(theme.PADDING_SMALL, theme.PADDING_SMALL))

        self._clear_button = ctk.CTkButton(
            button_row, text=t("clear_files"), fg_color="transparent",
            border_width=1, border_color=theme.COLOR_BORDER, text_color=theme.COLOR_TEXT,
            hover_color=theme.COLOR_ACCENT_SOFT, corner_radius=theme.CORNER_RADIUS,
            command=self._file_manager.clear,
        )
        self._clear_button.grid(row=0, column=2)

        # Klar abgegrenzte, aber kompakte Karte fuer den Chip-Bereich.
        # QA-Fix (Usability-Audit, Befund 1.1): sticky="nsew" + Row-Weight,
        # damit die Karte den von aussen (PanedWindow) zugewiesenen Platz
        # tatsaechlich fuellt, statt als grosse leere Flaeche darunter
        # sichtbar zu bleiben - im Leerzustand zeigt sie stattdessen die
        # neue, einladende Drop-Zone (siehe _dropzone weiter unten).
        self.grid_rowconfigure(1, weight=1)
        card = ctk.CTkFrame(self, fg_color=theme.COLOR_BG, corner_radius=theme.CORNER_RADIUS, border_width=1, border_color=theme.COLOR_BORDER)
        card.grid(row=1, column=0, sticky="nsew", padx=theme.PADDING_MEDIUM, pady=(0, theme.PADDING_SMALL))
        card.grid_columnconfigure(0, weight=1)
        card.grid_rowconfigure(1, weight=1)

        self._chip_row = ctk.CTkScrollableFrame(
            card, fg_color="transparent", height=_CHIP_ROW_VISIBLE_HEIGHT,
        )
        self._chip_row.grid(row=0, column=0, sticky="ew", padx=4, pady=4)

        self._dropzone = ctk.CTkLabel(
            card, text=f"📥\n{t('workbench_dropzone_text')}", font=theme.font_body(),
            text_color=theme.COLOR_TEXT_MUTED, justify="center",
        )

        bind_mousewheel_scroll(self._chip_row)
        self.bind("<Configure>", self._handle_resize)

    def _handle_resize(self, event) -> None:
        available_width = event.width - 2 * theme.PADDING_MEDIUM - 8
        if available_width <= 0:
            return
        columns = max(1, available_width // (_CHIP_WIDTH + _CHIP_GAP))
        if columns != self._current_columns:
            self._current_columns = columns
            self._on_files_changed(self._file_manager.get_files())

    def _handle_select_files(self) -> None:
        paths = filedialog.askopenfilenames(filetypes=[("PDF-Dateien", "*.pdf")])
        if paths:
            self._file_manager.add_files(list(paths))

    def _on_files_changed(self, files: list[str]) -> None:
        for child in self._chip_row.winfo_children():
            child.destroy()
        self._chip_buttons.clear()

        if not files:
            self._title_label.configure(text=t("drop_files_hint"))
            self._dropzone.place(relx=0.5, rely=0.5, anchor="center")
            return
        self._dropzone.place_forget()
        self._title_label.configure(text=f"{len(files)} {t('files_loaded')}")

        active_path = self._file_manager.get_active_file()
        for index, path in enumerate(files):
            self._add_chip(path, is_active=(path == active_path), index=index)

    def _add_chip(self, path: str, is_active: bool, index: int) -> None:
        name = _truncate_name(os.path.basename(path))
        chip_frame = ctk.CTkFrame(
            self._chip_row, corner_radius=theme.CORNER_RADIUS, width=_CHIP_WIDTH, height=_CHIP_HEIGHT,
            fg_color=theme.COLOR_ACCENT if is_active else theme.COLOR_BG_SECONDARY,
            border_width=0 if is_active else 1, border_color=theme.COLOR_BORDER,
        )
        row, col = divmod(index, self._current_columns)
        chip_frame.grid(row=row, column=col, padx=(0, _CHIP_GAP), pady=(0, _CHIP_GAP), sticky="w")
        chip_frame.grid_propagate(False)

        text_color = "white" if is_active else theme.COLOR_TEXT

        name_button = ctk.CTkButton(
            chip_frame, text=name, fg_color="transparent", hover_color=theme.COLOR_ACCENT_HOVER if is_active else theme.COLOR_ACCENT_SOFT,
            text_color=text_color, corner_radius=theme.CORNER_RADIUS, height=24, anchor="w",
            command=lambda p=path: self._file_manager.set_active_file(p),
        )
        name_button.pack(side="left", fill="x", expand=True, padx=(theme.PADDING_SMALL, 0), pady=4)

        remove_button = ctk.CTkButton(
            chip_frame, text="✕", width=22, height=24, fg_color="transparent",
            hover_color=theme.COLOR_ERROR, text_color=text_color, corner_radius=theme.CORNER_RADIUS,
            command=lambda p=path: self._file_manager.remove_file(p),
        )
        remove_button.pack(side="left", padx=(2, theme.PADDING_SMALL), pady=4)

        self._chip_buttons[path] = chip_frame

    def _on_active_changed(self, active_path: str | None) -> None:
        # Chips einfach neu aufbauen - bei ueblichen Dateimengen (wenige bis
        # einige Dutzend) performant genug und deutlich robuster als eine
        # partielle Aktualisierung einzelner Farben.
        self._on_files_changed(self._file_manager.get_files())

    def _handle_destroy(self, event) -> None:
        self._file_manager.unregister_listener(self._on_files_changed)
        self._file_manager.unregister_active_listener(self._on_active_changed)

    def retranslate(self) -> None:
        """Aktualisiert statische Texte nach einem Sprachwechsel."""
        self._select_button.configure(text=t("select_files"))
        self._clear_button.configure(text=t("clear_files"))
        self._dropzone.configure(text=f"📥\n{t('workbench_dropzone_text')}")
        self._on_files_changed(self._file_manager.get_files())

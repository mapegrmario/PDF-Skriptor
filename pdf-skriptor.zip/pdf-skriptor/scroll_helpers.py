"""
scroll_helpers.py
Gemeinsame Hilfsfunktion fuer zuverlaessiges UND sanftes Mausrad-
Scrollen in CTkScrollableFrame-Bereichen (vertikal oder horizontal).

Zuverlaessigkeit: Eine dauerhafte bind_all()-Bindung (wie urspruenglich
in mehreren Ansichten verwendet) wird von JEDER ANDEREN Ansicht
ueberschrieben, die ebenfalls bind_all() fuer dieselbe
Ereignis-Sequenz aufruft - danach scrollt die zuerst gebundene Ansicht
nicht mehr, auch wenn sie wieder sichtbar ist. Der zuverlaessige
Ansatz: bind_all() nur aktivieren, waehrend sich die Maus tatsaechlich
ueber dem jeweiligen Bereich befindet (<Enter>/<Leave>), und beim
Verlassen wieder entfernen. Einzelne <MouseWheel>-Bindungen direkt an
Kind-Widgets (Buttons, Labels) werden von CustomTkinter oft nicht
zuverlaessig durchgereicht, daher bind_all() waehrend des Hovers
statt dessen.

Sanftheit: Ohne explizites "yscrollincrement"/"xscrollincrement"
scrollt eine Tk-Canvas pro Mausrad-Kerbe um eine intern uneinheitlich
grosse "Einheit" - das fuehlt sich ruckartig/hakelig an. Stattdessen
wird hier jede Kerbe in eine weiche, ausklingende Gleitbewegung
uebersetzt (mehrere kleine Teilschritte mit abnehmender Geschwindigkeit
statt eines einzelnen harten Sprungs) - nachfolgende Kerben waehrend
einer laufenden Bewegung verlaengern die Gleitstrecke, statt sie zu
unterbrechen.

Der Abklingfaktor pro Tick wird auf die tatsaechlich vergangene Zeit
skaliert (statt eine feste Tick-Dauer anzunehmen): Wenn das
Betriebssystem einen Tick verzoegert (Systemlast, viele Widgets beim
Neuzeichnen), gleicht der naechste Tick das automatisch aus, anstatt
dass die Bewegung sichtbar stockt/ruckelt.

WICHTIG - bewusst KEINE Scroll-Rand-Erkennung ueber canvas.yview()/
xview(): Ein frueherer Versuch, an einem bereits erreichten Scroll-Rand
kein weiteres Momentum mehr aufzubauen, hat sich auf canvas.yview()
verlassen, um zu pruefen, ob bereits ganz oben/unten gescrollt ist. Bei
der von CTkScrollableFrame intern verwalteten Canvas liefert
yview()/xview() aber nachweislich nicht immer einen aussagekraeftigen
Wert (u. a. bleibt "scrollregion" leer, da CTkScrollableFrame die
Sichtbarkeit anders verwaltet als eine klassische Tk-Canvas) - das
fuehrte dazu, dass jede einzelne Mausrad-Bewegung faelschlich als
"bereits am Rand" erkannt und dadurch komplett blockiert wurde
(Scrollen ging gar nicht mehr). Diese Datei verzichtet deshalb bewusst
auf jede Rand-Vorabpruefung; das Scrollen selbst (yview_scroll/
xview_scroll) bleibt davon unberuehrt und funktioniert unabhaengig
davon zuverlaessig.

QA-Fix (Usability-Audit, Befund 4.2): Nach einem Sprachwechsel (der in
app_window.py._reload_after_language_change ALLE Ansichten zerstoert
und neu aufbaut) blieb das Kachelmenue komplett unscrollbar haengen.
Ursache, in zwei Teilen:
1. <Leave> feuert nur bei tatsaechlicher Mauszeiger-BEWEGUNG ueber die
   Widget-Grenze hinweg. Wird eine Ansicht per grid_forget()/destroy()
   entfernt, WAEHREND sich die Maus (unbewegt) noch darueber befindet,
   feuert kein <Leave> - die per bind_all() gesetzte, globale
   Mausrad-Bindung bleibt aktiv und zeigt danach auf eine bereits
   zerstoerte Canvas ("tote" Bindung).
2. Wird direkt danach eine NEUE Ansicht an derselben Bildschirmstelle
   eingeblendet, faengt der Mauszeiger (der sich ja nicht bewegt hat)
   kein <Enter> fuer sie ein - ihre eigene Mausrad-Bindung wird nie
   aktiviert. Ergebnis: Scrollen erreicht nur noch die tote alte
   Bindung, die auf eine zerstoerte Canvas zeigt und nichts mehr tut.
Fix: <Destroy> loest jetzt zusaetzlich unbind_all() aus (nicht nur die
Animation abbrechen), und <Map> (feuert zuverlaessig bei jedem
grid()/erneutem Einblenden, unabhaengig von Mauszeiger-Bewegung)
aktiviert die Bindung zusaetzlich sofort, falls sich der Mauszeiger in
diesem Moment bereits ueber dem Bereich befindet.
"""

import time
import customtkinter as ctk

_PIXELS_PER_NOTCH = 130
_EASE_FACTOR = 0.32
_TICK_MS = 16
_MIN_STEP = 0.6


def _pointer_is_over(widget) -> bool:
    try:
        px, py = widget.winfo_pointerx(), widget.winfo_pointery()
        wx, wy = widget.winfo_rootx(), widget.winfo_rooty()
        return wx <= px < wx + widget.winfo_width() and wy <= py < wy + widget.winfo_height()
    except Exception:  # noqa: BLE001 - Widget evtl. gerade im Auf-/Abbau
        return False


def bind_mousewheel_scroll(scroll_area: ctk.CTkScrollableFrame, orientation: str = "vertical") -> None:
    """Aktiviert zuverlaessiges, sanft auslaufendes Mausrad-Scrollen fuer
    eine CTkScrollableFrame, solange sich die Maus darueber befindet.
    orientation="vertical" (Standard, unveraendertes Verhalten aller
    bisherigen Aufrufstellen) nutzt das Mausrad direkt; orientation=
    "horizontal" (z. B. page_preview_strip.py) scrollt seitlich."""
    canvas = scroll_area._parent_canvas
    if orientation == "horizontal":
        canvas.configure(xscrollincrement=1)
        view_scroll = canvas.xview_scroll
    else:
        canvas.configure(yscrollincrement=1)
        view_scroll = canvas.yview_scroll
    pending = {"amount": 0.0, "job": None, "last_tick": 0.0, "bound": False}

    def _cancel() -> None:
        if pending["job"] is not None:
            canvas.after_cancel(pending["job"])
            pending["job"] = None
        pending["amount"] = 0.0
        pending["last_tick"] = 0.0

    def _decay_factor(elapsed_ms: float) -> float:
        # Entspricht bei genau _TICK_MS exakt _EASE_FACTOR, gleicht einen
        # verspaeteten Tick aber korrekt aus (kontinuierliches Aequivalent
        # mehrerer regulaerer Ticks), statt sichtbar hinterherzuhinken.
        return 1 - (1 - _EASE_FACTOR) ** (elapsed_ms / _TICK_MS)

    def _tick() -> None:
        now = time.perf_counter()
        elapsed_ms = (now - pending["last_tick"]) * 1000 if pending["last_tick"] else _TICK_MS
        pending["last_tick"] = now
        step = pending["amount"] * _decay_factor(elapsed_ms)
        if abs(step) < _MIN_STEP:
            if abs(pending["amount"]) >= 1:
                view_scroll(int(round(pending["amount"])), "units")
            pending["amount"] = 0.0
            pending["job"] = None
            pending["last_tick"] = 0.0
            return
        view_scroll(int(round(step)), "units")
        pending["amount"] -= step
        pending["job"] = canvas.after(_TICK_MS, _tick)

    def _on_mousewheel(event) -> None:
        delta = -1 if getattr(event, "num", None) == 5 or getattr(event, "delta", 0) < 0 else 1
        pending["amount"] += -delta * _PIXELS_PER_NOTCH
        if pending["job"] is None:
            pending["last_tick"] = time.perf_counter()
            pending["job"] = canvas.after(_TICK_MS, _tick)

    def _activate() -> None:
        if pending["bound"]:
            return
        pending["bound"] = True
        scroll_area.bind_all("<MouseWheel>", _on_mousewheel)
        scroll_area.bind_all("<Button-4>", _on_mousewheel)
        scroll_area.bind_all("<Button-5>", _on_mousewheel)

    def _deactivate() -> None:
        if not pending["bound"]:
            return
        pending["bound"] = False
        scroll_area.unbind_all("<MouseWheel>")
        scroll_area.unbind_all("<Button-4>")
        scroll_area.unbind_all("<Button-5>")
        _cancel()

    def _on_enter(_event) -> None:
        _activate()

    def _on_leave(_event) -> None:
        _deactivate()

    def _on_map(_event) -> None:
        # Fix fuer die Sprachwechsel-Scroll-Sperre: <Enter> feuert nicht,
        # wenn der Mauszeiger beim Einblenden bereits unbewegt ueber dem
        # Bereich steht - hier stattdessen aktiv nachpruefen. after_idle,
        # damit winfo_width()/winfo_height() bereits die frisch
        # aufgebaute Geometrie widerspiegeln, nicht Platzhalterwerte.
        scroll_area.after_idle(lambda: _activate() if _pointer_is_over(scroll_area) else None)

    def _on_unmap(_event) -> None:
        _deactivate()

    def _on_destroy(_event) -> None:
        # Sicherheitsnetz: greift auch, wenn weder <Leave> noch <Unmap>
        # vorher gefeuert haben (siehe Docstring oben) - verhindert eine
        # global registrierte Bindung, die auf eine zerstoerte Canvas zeigt.
        _deactivate()

    scroll_area.bind("<Enter>", _on_enter)
    scroll_area.bind("<Leave>", _on_leave)
    scroll_area.bind("<Map>", _on_map)
    scroll_area.bind("<Unmap>", _on_unmap)
    scroll_area.bind("<Destroy>", _on_destroy)

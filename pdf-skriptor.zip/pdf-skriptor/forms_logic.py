"""
forms_logic.py
Liest AcroForm-Feldnamen aus einer PDF-Datei und schreibt ausgefuellte
Werte in eine neue Datei. Deckt Textfelder und Kontrollkaestchen ab.
"""

from pypdf import PdfReader, PdfWriter
from pypdf.generic import NameObject, BooleanObject, DictionaryObject
from logger_setup import log_exception

# QA-Fix (Runde 5, Live-Test "Formulare ausfüllen"): PDFs, deren Formularfelder
# ohne eigenes /DR (Default Resources) am AcroForm erzeugt wurden - z. B. von
# manchen Formular-Generatoren, reproduziert mit PyMuPDF-erzeugten Testfeldern -
# liessen pypdf beim Speichern mit "AttributeError: 'dict' object has no
# attribute 'get_object'" abstuerzen (pypdf._writer._update_field_annotation
# geht intern von einem vorhandenen /DR/Font aus). Betrifft nur PDFs ohne
# eigenes /DR; bereits vorhandene Default Resources (z. B. aus Acrobat,
# LibreOffice) bleiben unangetastet.
_FALLBACK_FONT_NAME = "/Helv"
_FALLBACK_FONT_BASE = "/Helvetica"


def _ensure_default_resources(writer: PdfWriter) -> None:
    """Ergaenzt ein minimales /DR/Font mit Helvetica, falls das AcroForm
    keines besitzt - verhindert den oben beschriebenen pypdf-Absturz und
    liefert nebenbei eine korrekt aussehende Feld-Erscheinung statt der
    sonst nur intern (nicht im Dialog) sichtbaren Warnung "Font dictionary
    for /Helv not found."."""
    acroform = writer._root_object.get("/AcroForm")
    if acroform is None:
        return
    acro_obj = acroform.get_object()
    if "/DR" in acro_obj:
        return
    helv = DictionaryObject({
        NameObject("/Type"): NameObject("/Font"),
        NameObject("/Subtype"): NameObject("/Type1"),
        NameObject("/BaseFont"): NameObject(_FALLBACK_FONT_BASE),
        NameObject("/Encoding"): NameObject("/WinAnsiEncoding"),
    })
    font_dict = DictionaryObject({NameObject(_FALLBACK_FONT_NAME): helv})
    acro_obj[NameObject("/DR")] = DictionaryObject({NameObject("/Font"): font_dict})


def get_form_fields(path: str) -> list[dict]:
    """Liest alle Formularfelder mit Typ und aktuellem Wert aus."""
    fields = []
    try:
        reader = PdfReader(path)
        raw_fields = reader.get_fields() or {}
        for name, field in raw_fields.items():
            field_type = str(field.get("/FT", ""))
            value = field.get("/V", "")
            # QA-Fix (Usability-Audit, Befund 2.4): /TU ist die vom
            # PDF-Ersteller hinterlegte sprechende Beschreibung eines
            # Feldes (Tooltip/Alternativname) - falls vorhanden, lesbarer
            # als der oft kryptische interne Feldname (z. B. bei mit
            # Formular-Generatoren erzeugten PDFs). Fallback auf den
            # technischen Namen, wenn kein /TU hinterlegt ist.
            tooltip = field.get("/TU")
            fields.append({
                "name": name,
                "label": str(tooltip) if tooltip else name,
                "type": "checkbox" if field_type == "/Btn" else "text",
                "value": str(value) if value else "",
            })
        return fields
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Lesen der Formularfelder", exc)
        return fields


def has_form_fields(path: str) -> bool:
    return len(get_form_fields(path)) > 0


def fill_form(path: str, output_path: str, values: dict) -> bool:
    """Schreibt die uebergebenen Feldwerte in eine ausgefuellte Kopie der PDF."""
    try:
        reader = PdfReader(path)
        writer = PdfWriter()
        writer.append(reader)
        _ensure_default_resources(writer)
        for page in writer.pages:
            writer.update_page_form_field_values(page, values)
        if writer._root_object.get("/AcroForm") is not None:
            writer._root_object["/AcroForm"][NameObject("/NeedAppearances")] = BooleanObject(True)
        with open(output_path, "wb") as file:
            writer.write(file)
        return True
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Ausfüllen des Formulars", exc)
        return False

"""
sign_cert_ui.py
Unter-Werkzeug "Zertifikat" des Digitale-Signatur-Moduls: zeigt das
aktuell aktive Signatur-Zertifikat an, erlaubt das Erzeugen eines
neuen selbstsignierten Zertifikats oder die Auswahl einer vorhandenen
.p12/.pfx-Datei (z. B. eines echten, von einer Stelle ausgegebenen
Zertifikats).
"""

import os
import tkinter.filedialog as filedialog
from tkinter import messagebox
import customtkinter as ctk
from language import t
import theme
from cert_logic import generate_self_signed_certificate, use_external_certificate, get_certificate_info


class SignCertTool(ctk.CTkFrame):
    """Verwaltung des aktiven Signatur-Zertifikats."""

    def __init__(self, master, file_manager) -> None:
        super().__init__(master, fg_color="transparent")
        self._build_ui()
        self._refresh_status()

    def _build_ui(self) -> None:
        self._status_label = ctk.CTkLabel(
            self, text="", font=theme.font_body(), text_color=theme.COLOR_TEXT,
            wraplength=300, justify="left",
        )
        self._status_label.pack(anchor="w", pady=(0, theme.PADDING_MEDIUM))

        generate_card = ctk.CTkFrame(self, fg_color=theme.COLOR_BG_SECONDARY, corner_radius=theme.CORNER_RADIUS)
        generate_card.pack(fill="x", pady=(0, theme.PADDING_SMALL))
        ctk.CTkLabel(generate_card, text=t("sign_cert_generate_title"), font=theme.font_body(), text_color=theme.COLOR_TEXT, anchor="w").pack(anchor="w", padx=theme.PADDING_MEDIUM, pady=(theme.PADDING_MEDIUM, 4))

        self._name_entry = ctk.CTkEntry(generate_card, placeholder_text=t("sign_cert_name_placeholder"))
        self._name_entry.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=2)
        self._email_entry = ctk.CTkEntry(generate_card, placeholder_text=t("sign_cert_email_placeholder"))
        self._email_entry.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=2)
        self._org_entry = ctk.CTkEntry(generate_card, placeholder_text=t("sign_cert_org_placeholder"))
        self._org_entry.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=2)
        self._password_entry = ctk.CTkEntry(generate_card, placeholder_text=t("sign_cert_password_placeholder"), show="•")
        self._password_entry.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=2)
        self._password_confirm_entry = ctk.CTkEntry(generate_card, placeholder_text=t("sign_cert_password_confirm_placeholder"), show="•")
        self._password_confirm_entry.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=(2, theme.PADDING_SMALL))

        generate_button = ctk.CTkButton(
            generate_card, text=t("sign_cert_generate_button"), fg_color=theme.COLOR_ACCENT,
            hover_color=theme.COLOR_ACCENT_HOVER, corner_radius=theme.CORNER_RADIUS, command=self._handle_generate,
        )
        generate_button.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=(0, theme.PADDING_MEDIUM))

        external_button = ctk.CTkButton(
            self, text=t("sign_cert_use_external"), fg_color="transparent", border_width=1,
            border_color=theme.COLOR_BORDER, text_color=theme.COLOR_TEXT, hover_color=theme.COLOR_ACCENT_SOFT,
            corner_radius=theme.CORNER_RADIUS, command=self._handle_use_external,
        )
        external_button.pack(fill="x")

    def _refresh_status(self) -> None:
        info = get_certificate_info()
        if not info:
            self._status_label.configure(text=t("sign_cert_none_active"))
        elif info.get("source") == "generated":
            self._status_label.configure(
                text=t("sign_cert_active_generated").format(
                    name=info.get("common_name", ""), valid_until=info.get("valid_until", ""),
                )
            )
        else:
            self._status_label.configure(text=t("sign_cert_active_external").format(filename=os.path.basename(info.get("path", ""))))

    def _handle_generate(self) -> None:
        name = self._name_entry.get().strip()
        password = self._password_entry.get()
        if not name or not password:
            messagebox.showinfo(t("app_title"), t("sign_cert_missing_fields"))
            return
        if password != self._password_confirm_entry.get():
            messagebox.showerror(t("app_title"), t("sign_cert_password_mismatch"))
            return

        success = generate_self_signed_certificate(name, self._email_entry.get().strip(), self._org_entry.get().strip(), password)
        if success:
            messagebox.showinfo(t("app_title"), t("sign_cert_generated_success"))
            self._refresh_status()
        else:
            messagebox.showerror(t("app_title"), t("error_generic"))

    def _handle_use_external(self) -> None:
        path = filedialog.askopenfilename(filetypes=[("PKCS#12-Zertifikate", "*.p12 *.pfx"), ("Alle Dateien", "*.*")])
        if not path:
            return
        use_external_certificate(path)
        messagebox.showinfo(t("app_title"), t("sign_cert_external_selected"))
        self._refresh_status()

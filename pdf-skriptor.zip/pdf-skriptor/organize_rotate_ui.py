"""
organize_rotate_ui.py
Unter-Werkzeug: Dreht alle Seiten der aktiven PDF-Datei um
90, 180 oder 270 Grad und speichert das Ergebnis als neue Datei.
"""

import os
import tkinter.filedialog as filedialog
from tkinter import messagebox
import customtkinter as ctk
from language import t
import settings as settings_store
import theme
from organize_logic import rotate_pages
from file_list_sync import sync_active_file, load_result_file


class OrganizeRotateTool(ctk.CTkFrame):
    """UI zum Drehen aller Seiten der aktiven PDF-Datei."""

    def __init__(self, master, file_manager) -> None:
        super().__init__(master, fg_color="transparent")
        self._file_manager = file_manager
        self._active_path: str | None = None
        self._build_ui()
        sync_active_file(self, self._file_manager, self._handle_active_changed)

    def _build_ui(self) -> None:
        self._active_file_label = ctk.CTkLabel(self, text="", font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED)
        self._active_file_label.pack(anchor="w", pady=(0, theme.PADDING_MEDIUM))

        self._angle_selector = ctk.CTkSegmentedButton(self, values=["90°", "180°", "270°"])
        self._angle_selector.set("90°")
        self._angle_selector.pack(anchor="w", pady=(0, theme.PADDING_MEDIUM))

        rotate_button = ctk.CTkButton(
            self, text=t("rotate_and_save"), fg_color=theme.COLOR_ACCENT,
            hover_color=theme.COLOR_ACCENT_HOVER, corner_radius=theme.CORNER_RADIUS,
            command=self._handle_rotate,
        )
        rotate_button.pack(anchor="w")

    def _handle_active_changed(self, path: str | None) -> None:
        self._active_path = path
        if path:
            self._active_file_label.configure(text=f"📄 {os.path.basename(path)}")
        else:
            self._active_file_label.configure(text=t("no_active_file_hint"))

    def _handle_rotate(self) -> None:
        if not self._active_path:
            messagebox.showinfo(t("app_title"), t("no_active_file_hint"))
            return

        degrees = int(self._angle_selector.get().replace("°", ""))
        settings = settings_store.load_settings()
        base_name = os.path.splitext(os.path.basename(self._active_path))[0]
        default_path = os.path.join(settings.get("output_dir", "~"), f"{base_name}_gedreht.pdf")
        output_path = filedialog.asksaveasfilename(
            initialfile=os.path.basename(default_path),
            initialdir=os.path.dirname(default_path),
            defaultextension=".pdf",
            filetypes=[("PDF-Dateien", "*.pdf")],
        )
        if not output_path:
            return

        success = rotate_pages(self._active_path, output_path, degrees)
        if success:
            load_result_file(self._file_manager, output_path)
            messagebox.showinfo(t("app_title"), t("save_success"))
        else:
            messagebox.showerror(t("app_title"), t("error_generic"))

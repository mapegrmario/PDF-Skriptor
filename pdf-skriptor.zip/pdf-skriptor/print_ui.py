"""
print_ui.py
UI fuer das Drucken-Modul: Druckerauswahl (per lpstat ermittelt),
Kopienanzahl und ein Drucken-Knopf fuer die aktive Datei. Neue Funktion,
kein Ersatz fuer die bestehende "Drucken erlauben"-Berechtigung im
Sicherheit-Werkzeug (das ist eine PDF-Rechte-Einstellung, kein
tatsaechlicher Druckvorgang).
"""

import os
from tkinter import messagebox
import customtkinter as ctk
import fitz
from language import t
import settings as settings_store
import theme
from print_logic import list_printers, get_default_printer, print_file, is_valid_page_range
from file_list_sync import sync_active_file

_MIN_COPIES = 1
_MAX_COPIES = 99
_MODE_ALL = "print_range_all"
_MODE_CUSTOM = "print_range_custom"


class PrintView(ctk.CTkFrame):
    """Ansicht zum Drucken der aktiven Datei ueber CUPS (lp)."""

    def __init__(self, master, file_manager) -> None:
        super().__init__(master, fg_color=theme.COLOR_BG)
        self._file_manager = file_manager
        self._active_path: str | None = None
        self._page_count = 0
        self._copies = _MIN_COPIES
        self._build_ui()
        self._load_printers()
        sync_active_file(self, self._file_manager, self._handle_active_changed)

    def _build_ui(self) -> None:
        title = ctk.CTkLabel(self, text=t("nav_print"), font=theme.font_title(), text_color=theme.COLOR_TEXT)
        title.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(theme.PADDING_LARGE, theme.PADDING_SMALL))

        self._active_file_label = ctk.CTkLabel(self, text="", font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED)
        self._active_file_label.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        self._card = ctk.CTkFrame(self, fg_color=theme.COLOR_BG_SECONDARY, corner_radius=theme.CORNER_RADIUS)
        self._card.pack(fill="x", padx=theme.PADDING_LARGE, pady=theme.PADDING_SMALL)

        ctk.CTkLabel(
            self._card, text=t("print_printer_label"), font=theme.font_small(), text_color=theme.COLOR_TEXT, anchor="w",
        ).pack(anchor="w", padx=theme.PADDING_MEDIUM, pady=(theme.PADDING_MEDIUM, 2))
        self._printer_menu = ctk.CTkOptionMenu(
            self._card, values=[t("print_no_printers")], fg_color=theme.COLOR_BG,
            button_color=theme.COLOR_ACCENT, button_hover_color=theme.COLOR_ACCENT_HOVER,
        )
        self._printer_menu.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=(0, theme.PADDING_SMALL))

        copies_row = ctk.CTkFrame(self._card, fg_color="transparent")
        copies_row.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=(0, theme.PADDING_MEDIUM))
        ctk.CTkLabel(
            copies_row, text=t("print_copies_label"), font=theme.font_small(), text_color=theme.COLOR_TEXT,
        ).pack(side="left")
        ctk.CTkButton(
            copies_row, text="–", width=28, command=lambda: self._change_copies(-1),
            fg_color="transparent", border_width=1, border_color=theme.COLOR_BORDER,
            text_color=theme.COLOR_TEXT, hover_color=theme.COLOR_ACCENT_SOFT,
        ).pack(side="right")
        self._copies_label = ctk.CTkLabel(copies_row, text=str(self._copies), font=theme.font_body(), text_color=theme.COLOR_TEXT, width=28)
        self._copies_label.pack(side="right", padx=8)
        ctk.CTkButton(
            copies_row, text="+", width=28, command=lambda: self._change_copies(1),
            fg_color="transparent", border_width=1, border_color=theme.COLOR_BORDER,
            text_color=theme.COLOR_TEXT, hover_color=theme.COLOR_ACCENT_SOFT,
        ).pack(side="right")

        # Neue Funktion (Runde 9): einzelne Seiten drucken statt immer der
        # ganzen Datei. Eingabefeld nur einblenden, wenn tatsaechlich ein
        # Bereich gewaehlt ist - im (haeufigeren) Alle-Seiten-Fall bleibt
        # die Ansicht so aufgeraeumt wie vorher.
        self._range_key_by_display = {t(_MODE_ALL): _MODE_ALL, t(_MODE_CUSTOM): _MODE_CUSTOM}
        range_values = [t(_MODE_ALL), t(_MODE_CUSTOM)]
        self._range_selector = ctk.CTkSegmentedButton(
            self._card, values=range_values, command=self._handle_range_mode_selected,
        )
        self._range_selector.set(range_values[0])
        self._range_selector.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=(0, theme.PADDING_SMALL))

        self._range_entry_row = ctk.CTkFrame(self._card, fg_color="transparent")
        self._range_entry = ctk.CTkEntry(self._range_entry_row, placeholder_text=t("print_range_placeholder"))
        self._range_entry.pack(fill="x")
        self._range_hint = ctk.CTkLabel(
            self._range_entry_row, text="", font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED, anchor="w",
        )
        self._range_hint.pack(anchor="w", pady=(4, 0))
        # _range_entry_row wird erst bei Bedarf gepackt, siehe _handle_range_mode_selected()

        self._print_button = ctk.CTkButton(
            self, text=t("print_button"), fg_color=theme.COLOR_ACCENT, hover_color=theme.COLOR_ACCENT_HOVER,
            corner_radius=theme.CORNER_RADIUS, command=self._handle_print,
        )
        self._print_button.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(theme.PADDING_MEDIUM, theme.PADDING_LARGE))

    def _load_printers(self) -> None:
        printers = list_printers()
        if not printers:
            self._printer_menu.configure(values=[t("print_no_printers")])
            self._printer_menu.set(t("print_no_printers"))
            self._print_button.configure(state="disabled")
            return
        self._printer_menu.configure(values=printers)
        settings = settings_store.load_settings()
        preferred = settings.get("last_used_printer") or get_default_printer()
        self._printer_menu.set(preferred if preferred in printers else printers[0])

    def _change_copies(self, delta: int) -> None:
        self._copies = max(_MIN_COPIES, min(_MAX_COPIES, self._copies + delta))
        self._copies_label.configure(text=str(self._copies))

    def _handle_range_mode_selected(self, display_value: str) -> None:
        mode = self._range_key_by_display.get(display_value, _MODE_ALL)
        if mode == _MODE_CUSTOM:
            self._range_entry_row.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=(0, theme.PADDING_MEDIUM))
        else:
            self._range_entry_row.pack_forget()

    def _handle_active_changed(self, path: str | None) -> None:
        self._active_path = path
        if path:
            self._active_file_label.configure(text=f"📄 {os.path.basename(path)}")
            try:
                with fitz.open(path) as document:
                    self._page_count = document.page_count
            except (OSError, RuntimeError):
                self._page_count = 0
            self._range_hint.configure(
                text=t("print_range_hint").format(n=self._page_count) if self._page_count else "",
            )
        else:
            self._active_file_label.configure(text=t("no_active_file_hint"))
            self._page_count = 0
            self._range_hint.configure(text="")

    def _handle_print(self) -> None:
        if not self._active_path:
            messagebox.showinfo(t("app_title"), t("no_active_file_hint"))
            return
        printer = self._printer_menu.get()
        if printer == t("print_no_printers"):
            return

        page_range = ""
        if self._range_key_by_display.get(self._range_selector.get()) == _MODE_CUSTOM:
            page_range = self._range_entry.get().strip()
            if not page_range:
                messagebox.showinfo(t("app_title"), t("print_range_empty"))
                return
            if not is_valid_page_range(page_range):
                messagebox.showerror(t("app_title"), t("print_range_invalid"))
                return

        if print_file(self._active_path, printer, self._copies, page_range):
            settings = settings_store.load_settings()
            settings["last_used_printer"] = printer
            settings_store.save_settings(settings)
            messagebox.showinfo(t("app_title"), t("print_success"))
        else:
            messagebox.showerror(t("app_title"), t("print_error"))

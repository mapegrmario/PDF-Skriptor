"""
reorder_card.py
Eine einzelne, per Maus verschiebbare Seiten-Vorschaukarte fuer das
Modul "Seiten neu ordnen". Meldet Drag-Start/-Bewegung/-Ende an die
uebergeordnete Ansicht (reorder_ui.py), die die eigentliche
Neusortierung der Liste vornimmt - die Karte selbst kennt ihre
Position in der Liste nicht, nur ihre urspruengliche Seitenzahl.
"""

import customtkinter as ctk
import theme


class ReorderCard(ctk.CTkFrame):
    """Zeigt ein Seiten-Vorschaubild mit Originalseitenzahl; leitet
    Maus-Ereignisse an die uebergeordnete Ansicht weiter."""

    def __init__(self, master, original_page_number: int, thumbnail_image: ctk.CTkImage, on_drag_start, on_drag_motion, on_drag_end) -> None:
        super().__init__(
            master, fg_color=theme.COLOR_BG_SECONDARY, corner_radius=theme.CORNER_RADIUS,
            border_width=1, border_color=theme.COLOR_BORDER,
        )
        self._on_drag_start = on_drag_start
        self._on_drag_motion = on_drag_motion
        self._on_drag_end = on_drag_end
        self._build_ui(original_page_number, thumbnail_image)

    def _build_ui(self, original_page_number: int, thumbnail_image: ctk.CTkImage) -> None:
        image_label = ctk.CTkLabel(self, image=thumbnail_image, text="")
        image_label.pack(padx=theme.PADDING_SMALL, pady=(theme.PADDING_SMALL, 2), side="left")

        self._number_label = ctk.CTkLabel(
            self, text=f"⠿  Seite {original_page_number}", font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED,
        )
        self._number_label.pack(padx=theme.PADDING_SMALL, side="left")

        for widget in (self, image_label, self._number_label):
            widget.bind("<ButtonPress-1>", self._handle_press)
            widget.bind("<B1-Motion>", self._handle_motion)
            widget.bind("<ButtonRelease-1>", self._handle_release)

    def _handle_press(self, event) -> None:
        self._on_drag_start(self)

    def _handle_motion(self, event) -> None:
        # winfo_pointery() liefert Bildschirmkoordinaten, unabhaengig
        # davon, ueber welchem Kindwidget das Ereignis ausgeloest wurde.
        self._on_drag_motion(self, self.winfo_pointery())

    def _handle_release(self, event) -> None:
        self._on_drag_end(self)

    def set_dragging(self, dragging: bool) -> None:
        self.configure(
            border_color=theme.COLOR_ACCENT if dragging else theme.COLOR_BORDER,
            border_width=2 if dragging else 1,
        )

"""
organize_split_ui.py
Unter-Werkzeug: Trennt die aktive PDF-Datei in einzelne
Seiten-Dateien auf.
"""

import os
import tkinter.filedialog as filedialog
from tkinter import messagebox
import customtkinter as ctk
from language import t
import settings as settings_store
import theme
from organize_logic import split_pdf, get_page_count
from file_list_sync import sync_active_file, load_result_files


class OrganizeSplitTool(ctk.CTkFrame):
    """UI zum Trennen der aktiven PDF-Datei in Einzelseiten."""

    def __init__(self, master, file_manager) -> None:
        super().__init__(master, fg_color="transparent")
        self._file_manager = file_manager
        self._active_path: str | None = None
        self._info_label: ctk.CTkLabel | None = None
        self._build_ui()
        sync_active_file(self, self._file_manager, self._handle_active_changed)

    def _build_ui(self) -> None:
        self._active_file_label = ctk.CTkLabel(self, text="", font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED)
        self._active_file_label.pack(anchor="w", pady=(0, theme.PADDING_SMALL))

        self._info_label = ctk.CTkLabel(self, text="", font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED)
        self._info_label.pack(anchor="w", pady=(0, theme.PADDING_MEDIUM))

        split_button = ctk.CTkButton(
            self, text=t("split_into_pages"), fg_color=theme.COLOR_ACCENT,
            hover_color=theme.COLOR_ACCENT_HOVER, corner_radius=theme.CORNER_RADIUS,
            command=self._handle_split,
        )
        split_button.pack(anchor="w")

    def _handle_active_changed(self, path: str | None) -> None:
        self._active_path = path
        if path:
            self._active_file_label.configure(text=f"📄 {os.path.basename(path)}")
            count = get_page_count(path)
            self._info_label.configure(text=t("split_page_count").format(n=count))
        else:
            self._active_file_label.configure(text=t("no_active_file_hint"))
            self._info_label.configure(text="")

    def _handle_split(self) -> None:
        if not self._active_path:
            messagebox.showinfo(t("app_title"), t("no_active_file_hint"))
            return

        settings = settings_store.load_settings()
        output_dir = filedialog.askdirectory(initialdir=settings.get("output_dir", "~"))
        if not output_dir:
            return

        created_files = split_pdf(self._active_path, output_dir)
        if created_files:
            load_result_files(self._file_manager, created_files)
            messagebox.showinfo(t("app_title"), t("split_result").format(n=len(created_files)))
        else:
            messagebox.showerror(t("app_title"), t("error_generic"))

"""
security_logic.py
Verschluesselt PDF-Dateien mit Passwort und regelt einzelne Rechte
(Drucken, Kopieren) ueber pikepdf/qpdf.
"""

import pikepdf
from logger_setup import log_exception


def encrypt_pdf(
    input_path: str,
    output_path: str,
    user_password: str,
    owner_password: str,
    allow_printing: bool = True,
    allow_copying: bool = True,
) -> bool:
    """Verschluesselt eine PDF-Datei mit Nutzer-/Eigentuemer-Passwort und Rechten."""
    try:
        permissions = pikepdf.Permissions(
            extract=allow_copying,
            print_lowres=allow_printing,
            print_highres=allow_printing,
        )
        with pikepdf.open(input_path) as pdf:
            pdf.save(
                output_path,
                encryption=pikepdf.Encryption(
                    user=user_password,
                    owner=owner_password or user_password,
                    allow=permissions,
                ),
            )
        return True
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler bei der Verschlüsselung", exc)
        return False


def remove_password(input_path: str, output_path: str, current_password: str) -> bool:
    """Entfernt den Passwortschutz einer PDF-Datei, sofern das Passwort bekannt ist."""
    try:
        with pikepdf.open(input_path, password=current_password) as pdf:
            pdf.save(output_path)
        return True
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Entfernen des Passworts", exc)
        return False


def is_encrypted(path: str) -> bool:
    try:
        with pikepdf.open(path):
            return False
    except pikepdf.PasswordError:
        return True
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Prüfen der Verschlüsselung", exc)
        return False

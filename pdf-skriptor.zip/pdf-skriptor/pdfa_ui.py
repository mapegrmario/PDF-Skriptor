"""
pdfa_ui.py
UI fuer die PDF/A-Konvertierung: ein Klick wandelt die aktive Datei in
PDF/A-2b um (Langzeitarchivierung, z. B. GoBD-konforme Ablage). Bewusst
minimalistisch gehalten - PDF/A-2b ist der in der Praxis am meisten
empfohlene Standard, eine Auswahl weiterer Konformitaetsstufen wuerde
hier nur unnoetig verwirren.
"""

import os
import tkinter.filedialog as filedialog
from tkinter import messagebox
import customtkinter as ctk
from language import t
import settings as settings_store
import theme
from pdfa_logic import convert_to_pdfa, is_pdfa_supported
from file_list_sync import sync_active_file, load_result_file


class PdfaView(ctk.CTkFrame):
    """Ansicht zur PDF/A-Konvertierung der aktiven Datei."""

    def __init__(self, master, file_manager) -> None:
        super().__init__(master, fg_color=theme.COLOR_BG)
        self._file_manager = file_manager
        self._active_path: str | None = None
        self._build_ui()

    def _build_ui(self) -> None:
        title = ctk.CTkLabel(self, text=t("nav_pdfa"), font=theme.font_title(), text_color=theme.COLOR_TEXT)
        title.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(theme.PADDING_LARGE, theme.PADDING_SMALL))

        if not is_pdfa_supported():
            warning = ctk.CTkLabel(
                self, text=t("pdfa_unavailable_hint"), font=theme.font_body(),
                text_color=theme.COLOR_WARNING, wraplength=300, justify="left",
            )
            warning.pack(anchor="w", padx=theme.PADDING_LARGE, pady=theme.PADDING_MEDIUM)
            return

        self._active_file_label = ctk.CTkLabel(self, text="", font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED)
        self._active_file_label.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        explanation = ctk.CTkLabel(
            self, text=t("pdfa_explanation"), font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED,
            wraplength=300, justify="left",
        )
        explanation.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        convert_button = ctk.CTkButton(
            self, text=t("pdfa_convert"), fg_color=theme.COLOR_ACCENT, hover_color=theme.COLOR_ACCENT_HOVER,
            corner_radius=theme.CORNER_RADIUS, command=self._handle_convert,
        )
        convert_button.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_LARGE))

        sync_active_file(self, self._file_manager, self._handle_active_changed)

    def _handle_active_changed(self, path: str | None) -> None:
        self._active_path = path
        if path:
            self._active_file_label.configure(text=f"📄 {os.path.basename(path)}")
        else:
            self._active_file_label.configure(text=t("no_active_file_hint"))

    def _handle_convert(self) -> None:
        if not self._active_path:
            messagebox.showinfo(t("app_title"), t("no_active_file_hint"))
            return

        settings = settings_store.load_settings()
        base_name = os.path.splitext(os.path.basename(self._active_path))[0]
        default_path = os.path.join(settings.get("output_dir", "~"), f"{base_name}_pdfa.pdf")
        output_path = filedialog.asksaveasfilename(
            initialfile=os.path.basename(default_path),
            initialdir=os.path.dirname(default_path),
            defaultextension=".pdf",
            filetypes=[("PDF-Dateien", "*.pdf")],
        )
        if not output_path:
            return

        success = convert_to_pdfa(self._active_path, output_path)
        if success:
            load_result_file(self._file_manager, output_path)
            messagebox.showinfo(t("app_title"), t("save_success"))
        else:
            messagebox.showerror(t("app_title"), t("error_generic"))

"""
redact_logic.py
Entfernt Text und Bildinhalte innerhalb definierter Bereiche dauerhaft
aus einer PDF-Datei (echte Redaction, kein reiner schwarzer Balken).
Nutzt PyMuPDF, das den zugrunde liegenden Inhalt physisch entfernt.
"""

import pymupdf as fitz  # "fitz" ist der veraltete Alias, siehe PyMuPDF-Deprecation-Hinweis
from logger_setup import log_exception


def find_text_matches(path: str, search_term: str) -> list[dict]:
    """Sucht einen Begriff in allen Seiten und liefert Fundstellen mit Rechteck."""
    matches = []
    if not search_term.strip():
        return matches
    try:
        document = fitz.open(path)
        for page_index, page in enumerate(document):
            rects = page.search_for(search_term)
            for rect in rects:
                matches.append({
                    "page": page_index,
                    "rect": [rect.x0, rect.y0, rect.x1, rect.y1],
                })
        document.close()
        return matches
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler bei der Textsuche für Redaction", exc)
        return matches


def apply_redactions(path: str, output_path: str, redaction_areas: list[dict]) -> bool:
    """Schwaerzt und entfernt den Inhalt in den angegebenen Bereichen dauerhaft.

    redaction_areas: Liste von {"page": int, "rect": [x0, y0, x1, y1]}
    """
    try:
        document = fitz.open(path)
        for area in redaction_areas:
            page = document[area["page"]]
            rect = fitz.Rect(*area["rect"])
            page.add_redact_annot(rect, fill=(0, 0, 0))
        for page in document:
            page.apply_redactions()
        document.save(output_path)
        document.close()
        return True
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Anwenden der Redaction", exc)
        return False


def get_page_count(path: str) -> int:
    try:
        document = fitz.open(path)
        count = document.page_count
        document.close()
        return count
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Ermitteln der Seitenzahl (Redaction)", exc)
        return 0

"""
annotate_logic.py
Fuegt Anmerkungen in eine PDF-Seite ein: Freihand-Tintenlinien,
rechteckige Hervorhebungen und wiederverwendbare Text-Stempel.
Arbeitet auf einer bereits geoeffneten PyMuPDF-Dokumentinstanz, damit
mehrere Anmerkungen gesammelt und gemeinsam gespeichert werden koennen.
"""

import pymupdf as fitz  # "fitz" ist der veraltete Alias, siehe PyMuPDF-Deprecation-Hinweis
from logger_setup import log_exception

STAMP_PRESETS = ["Geprüft", "Kopie", "Vertraulich", "Entwurf"]


def open_document(path: str) -> fitz.Document | None:
    try:
        return fitz.open(path)
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Öffnen des Dokuments für Anmerkungen", exc)
        return None


def add_ink_stroke(document: fitz.Document, page_index: int, points: list[tuple[float, float]], color=(0.9, 0.1, 0.1), width: float = 2.0) -> bool:
    """Fuegt eine Freihandlinie (Tinten-Annotation) auf der angegebenen Seite hinzu.
    Farbe und Strichstaerke sind frei waehlbar (siehe annotate_style.py)."""
    try:
        page = document[page_index]
        annot = page.add_ink_annot([points])
        annot.set_colors(stroke=color)
        annot.set_border(width=width)
        annot.update()
        return True
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Hinzufügen der Freihand-Anmerkung", exc)
        return False


def add_highlight(document: fitz.Document, page_index: int, rect: list[float], color=(1.0, 0.92, 0.3)) -> bool:
    """Fuegt eine rechteckige Hervorhebung ein."""
    try:
        page = document[page_index]
        annot = page.add_rect_annot(fitz.Rect(*rect))
        annot.set_colors(stroke=color, fill=color)
        annot.set_opacity(0.4)
        annot.update()
        return True
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Hinzufügen der Hervorhebung", exc)
        return False


_TEXT_TOOL_SUBJECT = "pdfskriptor_text"


def add_text(document: fitz.Document, page_index: int, position: tuple[float, float], text: str, font_size: float = 14.0, font_name: str = "helv") -> bool:
    """Platziert frei eingegebenen Text an der angegebenen Position
    (neues Werkzeug aus dem Usability-Audit - schliesst die Luecke
    zwischen 'Formular ausfuellen' und 'gar keine Textoption'). Wird mit
    einem Subject-Tag versehen, damit find_text_annot_at_point() es beim
    Verschieben-per-Ziehen von anderen Anmerkungsarten unterscheiden kann.
    font_name erwartet einen PyMuPDF-Basis-14-Fontcode ('helv'/'tiro'/
    'cour' - siehe text_tool_dialog.py _FONT_CHOICES); kein Embedding
    noetig, da diese drei Schriften in jedem PDF-Reader vorhanden sind."""
    try:
        page = document[page_index]
        line_count = text.count("\n") + 1
        longest_line = max((len(line) for line in text.split("\n")), default=1)
        width = max(120, min(400, longest_line * font_size * 0.6))
        height = max(24, line_count * font_size * 1.4)
        rect = fitz.Rect(position[0], position[1], position[0] + width, position[1] + height)
        annot = page.add_freetext_annot(rect, text, fontsize=font_size, fontname=font_name, text_color=(0, 0, 0), fill_color=None)
        annot.set_info(subject=_TEXT_TOOL_SUBJECT)
        annot.update()
        return True
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Hinzufügen des Textfelds", exc)
        return False


def find_text_annot_at_point(document: fitz.Document, page_index: int, x: float, y: float):
    """Sucht ein mit dem Text-Werkzeug platziertes Textfeld an der
    angegebenen Position (Seitenkoordinaten) - fuer das
    Verschieben-per-Ziehen zur Korrektur. Findet bewusst nur eigene
    Textfelder (Subject-Tag), keine Stempel oder anderen Anmerkungen.

    Gibt (page, annot) zurueck, NICHT nur annot: PyMuPDF-Annot-Objekte
    halten nur eine SCHWACHE Referenz auf ihre Seite - haelt der
    Aufrufer die zurueckgegebene Seite nicht am Leben (z. B. als
    Instanzattribut waehrend eines Ziehvorgangs), wird die Referenz
    ungueltig ("weakly-referenced object no longer exists"), sobald
    diese Funktion zurueckkehrt und die hier lokale Seiten-Variable
    von Python aufgeraeumt wird - selbst ein erneutes document[page_index]
    im Aufrufer erzeugt ein NEUES Python-Objekt und haelt nicht dieselbe
    schwach referenzierte Seite am Leben."""
    try:
        page = document[page_index]
        point = fitz.Point(x, y)
        hit = None
        for annot in page.annots():
            if annot.info.get("subject") == _TEXT_TOOL_SUBJECT and annot.rect.contains(point):
                hit = annot
        return page, hit
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler bei der Textfeld-Suche", exc)
        return None, None


def move_text_annot(annot, new_top_left: tuple[float, float]) -> bool:
    """Verschiebt ein bereits platziertes Textfeld an eine neue Position,
    Groesse und Inhalt bleiben unveraendert (Korrektur der Platzierung)."""
    try:
        rect = annot.rect
        new_rect = fitz.Rect(
            new_top_left[0], new_top_left[1], new_top_left[0] + rect.width, new_top_left[1] + rect.height,
        )
        annot.set_rect(new_rect)
        annot.update()
        return True
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Verschieben des Textfelds", exc)
        return False


def add_stamp(document: fitz.Document, page_index: int, position: tuple[float, float], text: str) -> bool:
    """Fuegt einen wiederverwendbaren Text-Stempel an der angegebenen Position ein."""
    try:
        page = document[page_index]
        rect = fitz.Rect(position[0], position[1], position[0] + 120, position[1] + 30)
        annot = page.add_freetext_annot(
            rect, text, fontsize=14, text_color=(0.8, 0, 0), fill_color=(1, 1, 1),
        )
        annot.set_border(width=1)
        annot.update()
        return True
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Hinzufügen des Stempels", exc)
        return False


def delete_annot_at_point(document: fitz.Document, page_index: int, x: float, y: float) -> bool:
    """Radierer: sucht die zuletzt hinzugefuegte Anmerkung, deren
    Begrenzungsrechteck den angegebenen Punkt (Seitenkoordinaten, nicht
    Canvas-Pixel) enthaelt, und entfernt sie. Gibt True zurueck, wenn eine
    Anmerkung gefunden und geloescht wurde."""
    try:
        page = document[page_index]
        point = fitz.Point(x, y)
        hit = None
        for annot in page.annots():
            if annot.rect.contains(point):
                hit = annot
        if hit is None:
            return False
        page.delete_annot(hit)
        return True
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Entfernen der Anmerkung", exc)
        return False


def save_document(document: fitz.Document, output_path: str) -> bool:
    try:
        document.save(output_path)
        return True
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Speichern der Anmerkungen", exc)
        return False

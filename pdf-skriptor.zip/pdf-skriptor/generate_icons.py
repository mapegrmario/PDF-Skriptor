"""
generate_icons.py
Erzeugt die farbigen 3D-Badge-Icons (icon_<modul>.png) fuer die
Menu-Kacheln in home_view.py: ein einfacher weisser Glyph je Werkzeug
auf dem in icon_style.py definierten Farbverlaufs-Badge. Reines
Build-Werkzeug - erzeugt einmalig die PNG-Dateien im Unterordner
"icons/" (eigener Ordner auf Wunsch, da 21 Bilddateien sonst den
Hauptordner unuebersichtlich gefuellt haetten); muss nur erneut
laufen, wenn ein neues Modul hinzukommt oder der Stil geaendert
werden soll.
Aufruf: python3 generate_icons.py
"""

import os
from icon_style import make_badge, WHITE, SHADE
import math

ICONS_DIR = "icons"

# ---- Glyphen ----

def g_pages(draw, box, s):
    x0, y0, x1, y1 = box
    w, h = x1 - x0, y1 - y0
    back = [x0 + w * 0.16, y0, x1, y1 - h * 0.16]
    draw.rounded_rectangle(back, radius=w * 0.08, fill=(255, 255, 255, 130))
    front = [x0, y0 + h * 0.16, x1 - w * 0.16, y1]
    draw.rounded_rectangle(front, radius=w * 0.08, fill=WHITE)
    for i in range(3):
        ly = front[1] + h * 0.22 + i * h * 0.16
        draw.line([front[0] + w * 0.12, ly, front[2] - w * 0.12, ly], fill=SHADE, width=int(w * 0.05))


def g_checklist(draw, box, s):
    x0, y0, x1, y1 = box
    w, h = x1 - x0, y1 - y0
    draw.rounded_rectangle(box, radius=w * 0.10, fill=WHITE)
    for i in range(3):
        cy = y0 + h * 0.24 + i * h * 0.28
        bs = w * 0.12
        draw.rounded_rectangle([x0 + w * 0.14, cy - bs / 2, x0 + w * 0.14 + bs, cy + bs / 2], radius=bs * 0.25, outline=SHADE, width=int(w * 0.025))
        draw.line([x0 + w * 0.38, cy, x1 - w * 0.14, cy], fill=SHADE, width=int(w * 0.045))


def g_tag(draw, box, s):
    x0, y0, x1, y1 = box
    w, h = x1 - x0, y1 - y0
    draw.polygon([
        (x0, y0 + h * 0.38), (x0 + w * 0.38, y0),
        (x1, y0), (x1, y0 + h * 0.62),
        (x0 + w * 0.62, y1), (x0, y0 + h * 0.62),
    ], fill=WHITE)
    hole_r = w * 0.075
    hx, hy = x0 + w * 0.62, y0 + h * 0.24
    draw.ellipse([hx - hole_r, hy - hole_r, hx + hole_r, hy + hole_r], fill=(0, 0, 0, 110))


def g_compress(draw, box, s):
    x0, y0, x1, y1 = box
    w, h = x1 - x0, y1 - y0
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    draw.polygon([(x0, y0), (x0 + w * 0.34, y0), (cx, cy - h * 0.05), (x0, y0 + h * 0.34)], fill=WHITE)
    draw.polygon([(x1, y1), (x1 - w * 0.34, y1), (cx, cy + h * 0.05), (x1, y1 - h * 0.34)], fill=WHITE)
    lw = int(w * 0.09)
    draw.line([x0 + w * 0.30, y0 + w * 0.30, cx - w * 0.06, cy - h * 0.06], fill=WHITE, width=lw)
    draw.line([x1 - w * 0.30, y1 - w * 0.30, cx + w * 0.06, cy + h * 0.06], fill=WHITE, width=lw)


def g_lock(draw, box, s):
    x0, y0, x1, y1 = box
    w = x1 - x0
    body_top = y0 + w * 0.42
    draw.rounded_rectangle([x0, body_top, x1, y1], radius=w * 0.10, fill=WHITE)
    shackle_w = w * 0.5
    cx = (x0 + x1) / 2
    draw.arc([cx - shackle_w / 2, y0, cx + shackle_w / 2, body_top + w * 0.14], start=180, end=360, fill=WHITE, width=int(w * 0.14))
    kr = w * 0.07
    draw.ellipse([cx - kr, body_top + w * 0.18, cx + kr, body_top + w * 0.18 + kr * 2], fill=SHADE)


def g_pencil(draw, box, s):
    x0, y0, x1, y1 = box
    draw.line([x0, y1, x1, y0], fill=WHITE, width=int((x1 - x0) * 0.20))
    draw.polygon([(x0, y1), (x0 + (x1 - x0) * 0.18, y1), (x0 + (x1 - x0) * 0.09, y1 - (x1 - x0) * 0.18)], fill=(255, 210, 100, 255))


def g_bookmark(draw, box, s):
    x0, y0, x1, y1 = box
    mid = (x0 + x1) / 2
    notch = (y1 - y0) * 0.22
    draw.polygon([(x0, y0), (x1, y0), (x1, y1), (mid, y1 - notch), (x0, y1)], fill=WHITE)


def g_header_footer(draw, box, s):
    x0, y0, x1, y1 = box
    w, h = x1 - x0, y1 - y0
    draw.rounded_rectangle(box, radius=w * 0.10, outline=WHITE, width=int(w * 0.05))
    draw.rectangle([x0 + w * 0.05, y0 + h * 0.05, x1 - w * 0.05, y0 + h * 0.24], fill=WHITE)
    draw.rectangle([x0 + w * 0.05, y1 - h * 0.24, x1 - w * 0.05, y1 - h * 0.05], fill=WHITE)
    for i in range(2):
        ly = y0 + h * 0.44 + i * h * 0.18
        draw.line([x0 + w * 0.14, ly, x1 - w * 0.14, ly], fill=(255, 255, 255, 200), width=int(w * 0.05))


def g_droplet(draw, box, s):
    x0, y0, x1, y1 = box
    cx = (x0 + x1) / 2
    w = x1 - x0
    r = w * 0.34
    cy = y1 - r
    draw.polygon([(cx, y0), (cx - r * 0.98, cy - r * 0.10), (cx + r * 0.98, cy - r * 0.10)], fill=WHITE)
    draw.ellipse([cx - r, cy - r, cx + r, cy + r], fill=WHITE)
    hr = w * 0.09
    draw.ellipse([cx - hr * 1.8, cy - hr * 0.6, cx - hr * 0.3, cy + hr * 0.9], fill=(255, 255, 255, 120))


def g_archive(draw, box, s):
    x0, y0, x1, y1 = box
    w, h = x1 - x0, y1 - y0
    draw.rounded_rectangle([x0, y0, x1, y0 + h * 0.28], radius=w * 0.06, fill=WHITE)
    draw.rounded_rectangle([x0 + w * 0.05, y0 + h * 0.30, x1 - w * 0.05, y1], radius=w * 0.06, fill=(255, 255, 255, 190))
    draw.rounded_rectangle([x0 + w * 0.32, y0 + h * 0.44, x1 - w * 0.32, y0 + h * 0.58], radius=h * 0.03, fill=SHADE)


def g_magnifier(draw, box, s, extra_lines=False):
    x0, y0, x1, y1 = box
    w = x1 - x0
    r = w * 0.34
    cx, cy = x0 + r + w * 0.02, y0 + r + w * 0.02
    lw = int(w * 0.13)
    draw.ellipse([cx - r, cy - r, cx + r, cy + r], outline=WHITE, width=lw)
    draw.line([cx + r * 0.68, cy + r * 0.68, x1, y1], fill=WHITE, width=lw)
    if extra_lines:
        for i in range(2):
            ly = y0 + w * 0.06 + i * w * 0.14
            draw.line([cx - r * 0.4, ly, cx + r * 0.55, ly], fill=(255, 255, 255, 140), width=int(w * 0.045))


def g_ocr(draw, box, s):
    g_magnifier(draw, box, s, extra_lines=True)


def g_layers(draw, box, s):
    x0, y0, x1, y1 = box
    w, h = x1 - x0, y1 - y0
    side = w * 0.58
    step = w * 0.24
    lw = int(w * 0.045)
    draw.rounded_rectangle([x0, y0, x0 + side, y0 + side], radius=w * 0.09, outline=(255, 255, 255, 150), width=lw)
    draw.rounded_rectangle([x0 + step, y0 + step, x0 + step + side, y0 + step + side], radius=w * 0.09, outline=(255, 255, 255, 200), width=lw)
    draw.rounded_rectangle([x0 + 2 * step, y0 + 2 * step, x0 + 2 * step + side, y0 + 2 * step + side], radius=w * 0.09, fill=WHITE)


def g_seal(draw, box, s):
    x0, y0, x1, y1 = box
    w = x1 - x0
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2 - w * 0.05
    r = w * 0.36
    draw.ellipse([cx - r, cy - r, cx + r, cy + r], fill=WHITE)
    draw.line([cx - r * 0.45, cy, cx - r * 0.1, cy + r * 0.4], fill=(200, 30, 60, 255), width=int(w * 0.09))
    draw.line([cx - r * 0.1, cy + r * 0.4, cx + r * 0.5, cy - r * 0.35], fill=(200, 30, 60, 255), width=int(w * 0.09))
    draw.polygon([(cx - r * 0.5, cy + r * 0.7), (cx - r * 0.15, cy + r * 0.7), (cx - r * 0.32, cy + r * 1.4)], fill=WHITE)
    draw.polygon([(cx + r * 0.5, cy + r * 0.7), (cx + r * 0.15, cy + r * 0.7), (cx + r * 0.32, cy + r * 1.4)], fill=WHITE)


def g_swap(draw, box, s):
    x0, y0, x1, y1 = box
    w, h = x1 - x0, y1 - y0
    cy1, cy2 = y0 + h * 0.32, y0 + h * 0.68
    lw = int(w * 0.11)
    draw.line([x0, cy1, x1 - w * 0.18, cy1], fill=WHITE, width=lw)
    draw.polygon([(x1, cy1), (x1 - w * 0.24, cy1 - h * 0.14), (x1 - w * 0.24, cy1 + h * 0.14)], fill=WHITE)
    draw.line([x0 + w * 0.18, cy2, x1, cy2], fill=WHITE, width=lw)
    draw.polygon([(x0, cy2), (x0 + w * 0.24, cy2 - h * 0.14), (x0 + w * 0.24, cy2 + h * 0.14)], fill=WHITE)


def g_redact(draw, box, s):
    x0, y0, x1, y1 = box
    w, h = x1 - x0, y1 - y0
    draw.rounded_rectangle(box, radius=w * 0.08, fill=(255, 255, 255, 210))
    for i, frac in enumerate((0.24, 0.50, 0.76)):
        ly = y0 + h * frac
        if i == 1:
            draw.rounded_rectangle([x0 + w * 0.10, ly - h * 0.08, x1 - w * 0.10, ly + h * 0.08], radius=h * 0.03, fill=(20, 20, 25, 255))
        else:
            draw.line([x0 + w * 0.12, ly, x1 - w * 0.12, ly], fill=SHADE, width=int(w * 0.05))


def g_convert(draw, box, s):
    x0, y0, x1, y1 = box
    w, h = x1 - x0, y1 - y0
    doc = [x0, y0, x0 + w * 0.55, y1]
    draw.rounded_rectangle(doc, radius=w * 0.06, fill=WHITE)
    for i in range(3):
        ly = y0 + h * 0.22 + i * h * 0.22
        draw.line([doc[0] + w * 0.08, ly, doc[2] - w * 0.08, ly], fill=SHADE, width=int(w * 0.045))
    ay = (y0 + y1) / 2
    draw.line([x0 + w * 0.62, ay, x1, ay], fill=WHITE, width=int(w * 0.10))
    draw.polygon([(x1, ay), (x1 - w * 0.16, ay - h * 0.12), (x1 - w * 0.16, ay + h * 0.12)], fill=WHITE)


def g_chain(draw, box, s):
    x0, y0, x1, y1 = box
    w, h = x1 - x0, y1 - y0
    lw = int(w * 0.13)
    draw.rounded_rectangle([x0, y0 + h * 0.18, x0 + w * 0.62, y0 + h * 0.62], radius=h * 0.20, outline=WHITE, width=lw)
    draw.rounded_rectangle([x0 + w * 0.38, y0 + h * 0.38, x1, y0 + h * 0.82], radius=h * 0.20, outline=WHITE, width=lw)


def g_gear(draw, box, s):
    x0, y0, x1, y1 = box
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    r_out = (x1 - x0) / 2
    teeth = 8
    pts = []
    for i in range(teeth * 2):
        r = r_out if i % 2 == 0 else r_out * 0.78
        angle = math.pi * i / teeth
        pts.append((cx + r * math.sin(angle), cy - r * math.cos(angle)))
    draw.polygon(pts, fill=WHITE)
    r_in = r_out * 0.55
    draw.ellipse([cx - r_in * 0.5, cy - r_in * 0.5, cx + r_in * 0.5, cy + r_in * 0.5], fill=(0, 0, 0, 70))


def g_printer(draw, box, s):
    x0, y0, x1, y1 = box
    w, h = x1 - x0, y1 - y0
    # Blatt, das oben aus dem Drucker herausragt
    draw.rectangle([x0 + w * 0.24, y0, x1 - w * 0.24, y0 + h * 0.28], fill=WHITE)
    # Druckerkoerper
    draw.rounded_rectangle([x0, y0 + h * 0.24, x1, y1 - h * 0.12], radius=w * 0.07, fill=WHITE)
    # Ausgabeschlitz
    draw.rectangle([x0 + w * 0.16, y0 + h * 0.40, x1 - w * 0.16, y0 + h * 0.48], fill=SHADE)
    # Austretendes Blatt unten
    draw.rectangle([x0 + w * 0.20, y1 - h * 0.28, x1 - w * 0.20, y1], fill=(255, 255, 255, 190))


def g_question(draw, box, s):
    x0, y0, x1, y1 = box
    w = x1 - x0
    cx = (x0 + x1) / 2
    lw = int(w * 0.15)
    draw.arc([x0 + w * 0.12, y0, x1 - w * 0.12, y0 + w * 0.62], start=200, end=460, fill=WHITE, width=lw)
    draw.line([cx, y0 + w * 0.52, cx, y0 + w * 0.72], fill=WHITE, width=lw)
    r = w * 0.09
    draw.ellipse([cx - r, y1 - r * 2, cx + r, y1], fill=WHITE)


def g_info(draw, box, s):
    x0, y0, x1, y1 = box
    w = x1 - x0
    cx = (x0 + x1) / 2
    r = w * 0.09
    draw.ellipse([cx - r, y0, cx + r, y0 + r * 2], fill=WHITE)
    draw.rounded_rectangle([cx - w * 0.09, y0 + w * 0.32, cx + w * 0.09, y1], radius=w * 0.05, fill=WHITE)


ICONS = {
    "organize": ("#3B82F6", g_pages),
    "forms": ("#14B8A6", g_checklist),
    "metadata": ("#8B5CF6", g_tag),
    "compress": ("#F97316", g_compress),
    "security": ("#DC2626", g_lock),
    "annotate": ("#EAB308", g_pencil),
    "outline": ("#6366F1", g_bookmark),
    "header_footer": ("#0EA5E9", g_header_footer),
    "watermark": ("#06B6D4", g_droplet),
    "pdfa": ("#92400E", g_archive),
    "search": ("#10B981", g_magnifier),
    "reorder": ("#A855F7", g_layers),
    "sign": ("#E11D48", g_seal),
    "print": ("#1E3A8A", g_printer),
    "ocr": ("#22C55E", g_ocr),
    "compare": ("#F59E0B", g_swap),
    "redact": ("#334155", g_redact),
    "convert": ("#7C3AED", g_convert),
    "pipeline": ("#F43F5E", g_chain),
    "settings": ("#64748B", g_gear),
    "help": ("#2563EB", g_question),
    "about": ("#0EA5E9", g_info),
}

def generate_all() -> None:
    base_dir = os.path.dirname(os.path.abspath(__file__))
    icons_dir = os.path.join(base_dir, ICONS_DIR)
    os.makedirs(icons_dir, exist_ok=True)
    for key, (color, fn) in ICONS.items():
        icon = make_badge(color, fn)
        icon.save(os.path.join(icons_dir, f"icon_{key}.png"))
    print(f"{len(ICONS)} Icons erzeugt in '{ICONS_DIR}/'.")


if __name__ == "__main__":
    generate_all()

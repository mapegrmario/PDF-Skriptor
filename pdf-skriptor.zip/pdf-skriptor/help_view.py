"""
help_view.py
Zeigt die integrierte Hilfe-Sektion innerhalb der Anwendung an.
Alle Erklaerungen erscheinen direkt in der GUI, kein externes Fenster.
"""

import customtkinter as ctk
from language import t, get_language
import theme
from scroll_helpers import bind_mousewheel_scroll

_HELP_SECTIONS = {
    "de": [
        ("Organisieren", "Seiten zusammenfügen, trennen, sortieren, drehen oder löschen."),
        ("Formulare", "PDF-Formularfelder direkt in der App ausfüllen und als neue Datei speichern."),
        ("Metadaten", "Titel, Autor und weitere Angaben einzeln oder für mehrere Dateien gleichzeitig bearbeiten."),
        ("Komprimieren", "Dateigröße verringern und die Wirkung der Qualitätsstufe vorab vergleichen."),
        ("Sicherheit", "Dokumente mit Passwort schützen und Rechte wie Drucken oder Kopieren einschränken."),
        ("Anmerkungen", "Freihand-Notizen (Farbe/Strichstärke wählbar), Textmarkierungen, frei platzierte Textfelder, wiederverwendbare Stempel und eine einmalig gezeichnete Unterschrift einfügen; per Radierer gezielt wieder entfernen."),
        ("Lesezeichen", "Inhaltsverzeichnis der aktiven Datei anzeigen, Einträge hinzufügen oder löschen und per Klick direkt zur passenden Seite springen."),
        ("Kopf-/Fußzeile", "Text mit Platzhaltern (Seite, Datum, Aktenzeichen) auf jede Seite anwenden, inklusive fortlaufender Aktenzeichen-Nummerierung."),
        ("Wasserzeichen", "Diagonalen Text mit wählbarer Farbe, Schriftgröße, Transparenz und Drehwinkel auf jede Seite anwenden."),
        ("PDF/A-Archivierung", "Die aktive Datei nach PDF/A-2b umwandeln - dem Standard für die dauerhafte, GoBD-konforme Archivierung."),
        ("Suche", "Volltextsuche im aktiven Dokument mit farbiger Trefferhervorhebung; springt seitenübergreifend zwischen den Treffern."),
        ("Seiten neu ordnen", "Seiten als Vorschaubilder anzeigen und per Drag & Drop in eine neue Reihenfolge bringen."),
        ("Digitale Signatur", "Kryptographische Signatur mit selbstsigniertem oder vorhandenem Zertifikat erzeugen; Signaturen beliebiger PDF-Dateien auf Unversehrtheit prüfen."),
        ("Drucken", "Die aktive Datei über einen bei CUPS eingerichteten Drucker ausgeben, mit Auswahl von Drucker und Kopienanzahl."),
        ("OCR", "Durchsuchbare PDFs aus Scans erzeugen. Wählt zwischen Deutsch, Englisch oder beidem."),
        ("Vergleich", "Zwei PDF-Versionen Seite für Seite vergleichen, Änderungen farbig markiert."),
        ("Redaction", "Inhalte dauerhaft entfernen – per Textsuche oder manuell markierter Bereich."),
        ("Konvertierung", "PDF-Inhalte als Markdown oder reinen Text exportieren, inklusive erkannter Tabellen."),
        ("Batch-Pipeline", "Mehrere Werkzeuge zu einer Kette verbinden und auf alle PDFs eines Ordners anwenden."),
        ("Allgemein", "Dateien per Drag & Drop irgendwo im Fenster ablegen oder über 'Dateien auswählen' laden. Alle Werkzeuge arbeiten mit der in der Werkbank angeklickten aktiven Datei. Ergebnisse werden im gewählten Ausgabeordner gespeichert."),
    ],
    "en": [
        ("Organize", "Merge, split, sort, rotate, or delete pages."),
        ("Forms", "Fill out PDF form fields directly in the app and save as a new file."),
        ("Metadata", "Edit title, author, and other details individually or across multiple files at once."),
        ("Compress", "Reduce file size and preview the effect of the quality level beforehand."),
        ("Security", "Protect documents with a password and restrict rights such as printing or copying."),
        ("Annotations", "Add freehand notes (color/thickness adjustable), text highlights, freely placed text boxes, reusable stamps, and a signature you draw once and reuse; remove any of them again with the eraser."),
        ("Bookmarks", "View the active file's table of contents, add or remove entries, and jump straight to a page with one click."),
        ("Header/Footer", "Apply text with placeholders (page, date, case number) to every page, including running case-number numbering."),
        ("Watermark", "Apply diagonal text with adjustable color, font size, opacity, and rotation to every page."),
        ("PDF/A Archiving", "Convert the active file to PDF/A-2b - the standard for durable, compliant long-term archiving."),
        ("Search", "Full-text search across the active document with colored match highlighting; jumps between matches across pages."),
        ("Reorder Pages", "View pages as thumbnails and drag them into a new order."),
        ("Digital Signature", "Create a cryptographic signature with a self-signed or existing certificate; verify the signatures of any PDF file for tampering."),
        ("Print", "Send the active file to a printer set up in CUPS, with a choice of printer and number of copies."),
        ("OCR", "Create searchable PDFs from scans. Choose German, English, or both."),
        ("Compare", "Compare two PDF versions page by page, with changes highlighted in color."),
        ("Redaction", "Permanently remove content – via text search or manually marked areas."),
        ("Conversion", "Export PDF content as Markdown or plain text, including detected tables."),
        ("Batch Pipeline", "Chain multiple tools together and apply them to all PDFs in a folder."),
        ("General", "Drop files anywhere in the window via drag & drop, or use 'Select files'. All tools work with the active file clicked in the workbench. Results are saved to the selected output folder."),
    ],
}


class HelpView(ctk.CTkFrame):
    """Scrollbare Hilfe-Ansicht mit Erklaerungen zu jedem Modul."""

    def __init__(self, master) -> None:
        super().__init__(master, fg_color=theme.COLOR_BG)
        self._build_ui()

    def _build_ui(self) -> None:
        title = ctk.CTkLabel(self, text=t("help_title"), font=theme.font_title(), text_color=theme.COLOR_TEXT)
        title.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(theme.PADDING_LARGE, theme.PADDING_MEDIUM))

        scroll_area = ctk.CTkScrollableFrame(self, fg_color="transparent")
        scroll_area.pack(fill="both", expand=True, padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_LARGE))
        bind_mousewheel_scroll(scroll_area)

        sections = _HELP_SECTIONS.get(get_language(), _HELP_SECTIONS["de"])
        for heading, body in sections:
            self._add_section(scroll_area, heading, body)

    def _add_section(self, parent, heading: str, body: str) -> None:
        card = ctk.CTkFrame(parent, fg_color=theme.COLOR_BG_SECONDARY, corner_radius=theme.CORNER_RADIUS)
        card.pack(fill="x", pady=theme.PADDING_SMALL)

        heading_label = ctk.CTkLabel(card, text=heading, font=theme.font_heading(), text_color=theme.COLOR_ACCENT)
        heading_label.pack(anchor="w", padx=theme.PADDING_MEDIUM, pady=(theme.PADDING_MEDIUM, 2))

        body_label = ctk.CTkLabel(
            card, text=body, font=theme.font_body(), text_color=theme.COLOR_TEXT,
            wraplength=300, justify="left",
        )
        body_label.pack(anchor="w", padx=theme.PADDING_MEDIUM, pady=(0, theme.PADDING_MEDIUM))

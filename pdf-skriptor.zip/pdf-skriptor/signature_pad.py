"""
signature_pad.py
Kleiner modaler Dialog zum Zeichnen einer Unterschrift per Maus. Erfasst
die Striche als Punktlisten in genau der Groesse von
signature_logic.CANVAS_SIZE und uebergibt sie beim Bestaetigen an eine
Callback-Funktion.
"""

import tkinter as tk
import customtkinter as ctk
from language import t
import theme
from signature_logic import CANVAS_SIZE


class SignaturePad(ctk.CTkToplevel):
    """Modales Zeichenfenster; ruft on_confirm(strokes) auf, wenn der
    Nutzer mindestens einen Strich gezeichnet und bestaetigt hat."""

    def __init__(self, master, on_confirm) -> None:
        super().__init__(master)
        self.title(t("signature_dialog_title"))
        self.resizable(False, False)
        self._on_confirm = on_confirm
        self._strokes: list[list[tuple[float, float]]] = []
        self._current_stroke: list[tuple[float, float]] = []
        self._build_ui()
        self.transient(master)
        self.grab_set()

    def _build_ui(self) -> None:
        hint = ctk.CTkLabel(
            self, text=t("signature_dialog_hint"), font=theme.font_small(),
            text_color=theme.COLOR_TEXT_MUTED, wraplength=CANVAS_SIZE[0],
        )
        hint.pack(padx=theme.PADDING_LARGE, pady=(theme.PADDING_LARGE, theme.PADDING_SMALL))

        width, height = CANVAS_SIZE
        self._canvas = tk.Canvas(
            self, width=width, height=height, bg="white",
            highlightthickness=1, highlightbackground=theme.COLOR_BORDER,
        )
        self._canvas.pack(padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))
        self._canvas.bind("<ButtonPress-1>", self._start_stroke)
        self._canvas.bind("<B1-Motion>", self._extend_stroke)
        self._canvas.bind("<ButtonRelease-1>", self._end_stroke)

        button_row = ctk.CTkFrame(self, fg_color="transparent")
        button_row.pack(padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_LARGE), fill="x")

        clear_button = ctk.CTkButton(
            button_row, text=t("signature_clear"), fg_color="transparent", border_width=1,
            border_color=theme.COLOR_BORDER, text_color=theme.COLOR_TEXT, hover_color=theme.COLOR_ACCENT_SOFT,
            corner_radius=theme.CORNER_RADIUS, command=self._clear,
        )
        clear_button.pack(side="left")

        cancel_button = ctk.CTkButton(
            button_row, text=t("signature_cancel"), fg_color="transparent", border_width=1,
            border_color=theme.COLOR_BORDER, text_color=theme.COLOR_TEXT, hover_color=theme.COLOR_ACCENT_SOFT,
            corner_radius=theme.CORNER_RADIUS, command=self.destroy,
        )
        cancel_button.pack(side="right", padx=(theme.PADDING_SMALL, 0))

        confirm_button = ctk.CTkButton(
            button_row, text=t("signature_confirm"), fg_color=theme.COLOR_ACCENT,
            hover_color=theme.COLOR_ACCENT_HOVER, corner_radius=theme.CORNER_RADIUS, command=self._confirm,
        )
        confirm_button.pack(side="right")

    def _start_stroke(self, event) -> None:
        self._current_stroke = [(event.x, event.y)]

    def _extend_stroke(self, event) -> None:
        if not self._current_stroke:
            return
        last_x, last_y = self._current_stroke[-1]
        self._canvas.create_line(
            last_x, last_y, event.x, event.y, fill="#141414", width=3, capstyle="round", smooth=True,
        )
        self._current_stroke.append((event.x, event.y))

    def _end_stroke(self, event) -> None:
        if self._current_stroke:
            self._strokes.append(self._current_stroke)
        self._current_stroke = []

    def _clear(self) -> None:
        self._canvas.delete("all")
        self._strokes = []

    def _confirm(self) -> None:
        if self._strokes:
            self._on_confirm(self._strokes)
        self.destroy()

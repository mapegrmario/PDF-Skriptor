"""
print_logic.py
Drucken ueber CUPS (lp/lpstat) - der auf allen Zieldistributionen
(Ubuntu, Mint, LMDE, Fedora, openSUSE, Arch, MX Linux) im
Desktop-Standardumfang enthaltene Linux-Druckweg. Funktioniert identisch
fuer klassische Treiber- und treiberlose (IPP-Everywhere-)Warteschlangen,
da CUPS beide Faelle intern gleich als Druckerwarteschlange verwaltet -
lp/lpstat unterscheiden nicht danach.
"""

import logging
import os
import re
import subprocess
from logger_setup import log_exception

_logger = logging.getLogger("pdf_skriptor")
_PAGE_RANGE_PATTERN = re.compile(r"^\s*\d+(\s*-\s*\d+)?(\s*,\s*\d+(\s*-\s*\d+)?)*\s*$")

# QA-Fix (Runde 8, vom Nutzer gemeldet: "kein Drucker angezeigt, obwohl
# einer installiert ist"): lpstat uebersetzt seine Ausgabe abhaengig von
# der System-Locale (bekanntes, dokumentiertes CUPS-Verhalten, siehe z. B.
# apple/cups#1447) - auf einem deutschsprachigen System beginnt die Zeile
# z. B. mit "Drucker" statt "printer", wodurch das reine Wort-Parsing
# leer blieb, obwohl ein Drucker eingerichtet war. LC_ALL=C erzwingt die
# stabile, unlokalisierte (englische) Ausgabe fuer den Unterprozess, ohne
# die Systemsprache des Nutzers selbst zu aendern.
_ENV_C_LOCALE = {**os.environ, "LC_ALL": "C", "LANGUAGE": "C"}


def list_printers() -> list[str]:
    """Liefert die Namen aller bei CUPS eingerichteten Drucker (per
    'lpstat -p'). Leere Liste, wenn keiner eingerichtet oder CUPS nicht
    erreichbar ist - kein Fehler, das ist ein gueltiger Zustand."""
    try:
        result = subprocess.run(
            ["lpstat", "-p"], capture_output=True, text=True, timeout=5, env=_ENV_C_LOCALE,
        )
        printers = []
        for line in result.stdout.splitlines():
            # Zeilenformat (in der erzwungenen C-Locale): "printer <name> is idle. ..." bzw. "... disabled ..."
            parts = line.split()
            if len(parts) >= 2 and parts[0] == "printer":
                printers.append(parts[1])
        if not printers:
            # Nichts gefunden - zur Fehlersuche mitloggen, ob lpstat
            # ueberhaupt lief bzw. was es stattdessen ausgegeben hat.
            _logger.info(
                "lpstat -p lieferte keine Drucker (rc=%s, stdout=%r, stderr=%r)",
                result.returncode, result.stdout.strip(), result.stderr.strip(),
            )
        return printers
    except (OSError, subprocess.SubprocessError) as exc:
        log_exception("Fehler beim Abfragen der Drucker (lpstat)", exc)
        return []


def get_default_printer() -> str | None:
    """Liefert den bei CUPS als Standard hinterlegten Drucker, falls
    vorhanden (per 'lpstat -d')."""
    try:
        result = subprocess.run(
            ["lpstat", "-d"], capture_output=True, text=True, timeout=5, env=_ENV_C_LOCALE,
        )
        # Zeilenformat (C-Locale): "system default destination: <name>"
        line = result.stdout.strip()
        if ":" in line:
            name = line.split(":", 1)[1].strip()
            return name or None
        return None
    except (OSError, subprocess.SubprocessError) as exc:
        log_exception("Fehler beim Abfragen des Standarddruckers (lpstat)", exc)
        return None


def is_valid_page_range(text: str) -> bool:
    """Prueft, ob text eine gueltige CUPS-Seitenliste ist (z. B. "1,3-5,16").
    Rein formal (Ziffern/Kommas/Bindestriche) - ob die Seitenzahlen
    tatsaechlich im Dokument existieren, prueft CUPS beim Drucken selbst."""
    return bool(_PAGE_RANGE_PATTERN.match(text))


def print_file(path: str, printer: str | None, copies: int = 1, page_range: str = "") -> bool:
    """Schickt die Datei ueber lp an den angegebenen Drucker (oder den
    CUPS-Standarddrucker, falls printer leer ist). PDFs werden von CUPS
    direkt akzeptiert - keine Vorkonvertierung noetig.

    page_range: leer = alle Seiten, sonst eine CUPS-Seitenliste wie
    "1,3-5,16" (an lp -P durchgereicht, dort auch validiert).

    QA-Fix (Runde 9, gemeldet: "das Gedruckte ist sehr klein"): -o
    fit-to-page skaliert den Seiteninhalt automatisch auf die tatsaechliche
    Papiergroesse, -o media=a4 legt diese explizit auf A4 fest - ohne
    diese Optionen druckt CUPS die PDF-Seite in ihrer Originalgroesse ohne
    Anpassung an das eingelegte Papier, was bei einer Groessen-Abweichung
    zwischen PDF-Seite und Papier winzig oder falsch platziert wirken kann."""
    try:
        command = ["lp", "-n", str(max(1, copies)), "-o", "fit-to-page", "-o", "media=a4"]
        if printer:
            command += ["-d", printer]
        if page_range:
            command += ["-P", page_range]
        command.append(path)
        result = subprocess.run(command, capture_output=True, text=True, timeout=15, env=_ENV_C_LOCALE)
        if result.returncode != 0:
            _logger.info(
                "lp meldete einen Fehler (rc=%s, stdout=%r, stderr=%r)",
                result.returncode, result.stdout.strip(), result.stderr.strip(),
            )
        return result.returncode == 0
    except (OSError, subprocess.SubprocessError) as exc:
        log_exception("Fehler beim Drucken (lp)", exc)
        return False

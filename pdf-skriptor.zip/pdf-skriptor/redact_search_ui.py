"""
redact_search_ui.py
Unter-Werkzeug fuer Redaction: sucht einen Begriff in der aktiven
Datei und erlaubt das Schwaerzen aller (oder ausgewaehlter)
Fundstellen in einem Arbeitsgang.
"""

import os
import tkinter.filedialog as filedialog
from tkinter import messagebox
import customtkinter as ctk
from language import t
import settings as settings_store
import theme
from scroll_helpers import bind_mousewheel_scroll
from redact_logic import find_text_matches, apply_redactions
from file_list_sync import sync_active_file, load_result_file


class RedactSearchTool(ctk.CTkFrame):
    """UI zum Suchen und Schwaerzen eines Begriffs in der aktiven Datei."""

    def __init__(self, master, file_manager) -> None:
        super().__init__(master, fg_color="transparent")
        self._file_manager = file_manager
        self._active_path: str | None = None
        self._matches: list[dict] = []
        self._match_vars: list[ctk.BooleanVar] = []
        self._results_area: ctk.CTkScrollableFrame | None = None
        self._build_ui()
        sync_active_file(self, self._file_manager, self._handle_active_changed)

    def _build_ui(self) -> None:
        self._active_file_label = ctk.CTkLabel(self, text="", font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED)
        self._active_file_label.pack(anchor="w", pady=(0, theme.PADDING_MEDIUM))

        search_row = ctk.CTkFrame(self, fg_color="transparent")
        search_row.pack(fill="x", pady=(0, theme.PADDING_MEDIUM))

        self._search_entry = ctk.CTkEntry(search_row, placeholder_text=t("redact_search_placeholder"))
        self._search_entry.pack(side="left", fill="x", expand=True, padx=(0, theme.PADDING_SMALL))

        search_button = ctk.CTkButton(
            search_row, text=t("redact_search_button"), fg_color="transparent", border_width=1, border_color=theme.COLOR_BORDER,
            text_color=theme.COLOR_TEXT, hover_color=theme.COLOR_ACCENT_SOFT, corner_radius=theme.CORNER_RADIUS,
            command=self._handle_search,
        )
        search_button.pack(side="left")

        self._results_area = ctk.CTkScrollableFrame(self, fg_color=theme.COLOR_BG_SECONDARY, corner_radius=theme.CORNER_RADIUS)
        self._results_area.pack(fill="both", expand=True, pady=(0, theme.PADDING_MEDIUM))
        bind_mousewheel_scroll(self._results_area)

        apply_button = ctk.CTkButton(
            self, text=t("redact_search_apply_button"), fg_color=theme.COLOR_ERROR,
            hover_color="#B8352F", corner_radius=theme.CORNER_RADIUS, command=self._handle_apply,
        )
        apply_button.pack(anchor="w")

    def _handle_active_changed(self, path: str | None) -> None:
        self._active_path = path
        if path:
            self._active_file_label.configure(text=f"📄 {os.path.basename(path)}")
        else:
            self._active_file_label.configure(text=t("no_active_file_hint"))
        self._matches = []
        self._match_vars = []
        for child in self._results_area.winfo_children():
            child.destroy()

    def _handle_search(self) -> None:
        for child in self._results_area.winfo_children():
            child.destroy()
        self._match_vars.clear()

        if not self._active_path:
            self._add_info_line(t("no_active_file_hint"))
            return

        term = self._search_entry.get()
        self._matches = find_text_matches(self._active_path, term)
        if not self._matches:
            self._add_info_line("Keine Fundstellen für diesen Begriff gefunden.")
            return

        for index, match in enumerate(self._matches):
            var = ctk.BooleanVar(value=True)
            checkbox = ctk.CTkCheckBox(
                self._results_area, text=f"Seite {match['page'] + 1}", variable=var, font=theme.font_body(),
            )
            checkbox.pack(anchor="w", padx=theme.PADDING_MEDIUM, pady=2)
            self._match_vars.append(var)

    def _add_info_line(self, text: str) -> None:
        label = ctk.CTkLabel(self._results_area, text=text, font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED)
        label.pack(padx=theme.PADDING_MEDIUM, pady=theme.PADDING_MEDIUM)

    def _handle_apply(self) -> None:
        if not self._active_path or not self._matches:
            messagebox.showinfo(t("app_title"), "Bitte zuerst eine Suche durchführen.")
            return

        selected_areas = [match for match, var in zip(self._matches, self._match_vars) if var.get()]
        if not selected_areas:
            messagebox.showinfo(t("app_title"), "Bitte mindestens eine Fundstelle auswählen.")
            return

        settings = settings_store.load_settings()
        base_name = os.path.splitext(os.path.basename(self._active_path))[0]
        default_path = os.path.join(settings.get("output_dir", "~"), f"{base_name}_geschwaerzt.pdf")
        output_path = filedialog.asksaveasfilename(
            initialfile=os.path.basename(default_path),
            initialdir=os.path.dirname(default_path),
            defaultextension=".pdf",
            filetypes=[("PDF-Dateien", "*.pdf")],
        )
        if not output_path:
            return

        success = apply_redactions(self._active_path, output_path, selected_areas)
        if success:
            load_result_file(self._file_manager, output_path)
            messagebox.showinfo(t("app_title"), t("save_success"))
        else:
            messagebox.showerror(t("app_title"), t("error_generic"))


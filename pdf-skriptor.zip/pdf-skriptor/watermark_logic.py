"""
watermark_logic.py
Legt ein halbtransparentes, diagonal gedrehtes Text-Wasserzeichen ueber
jede Seite einer PDF-Datei - z. B. zur Kennzeichnung von Entwuerfen
oder vertraulichen Dokumenten im Buero-Alltag.
"""

import pymupdf as fitz  # "fitz" ist der veraltete Alias, siehe PyMuPDF-Deprecation-Hinweis
from logger_setup import log_exception


def apply_watermark(
    path: str, output_path: str, text: str, font_size: float = 54.0,
    opacity: float = 0.25, rotation: float = 45.0, color: tuple = (0.5, 0.5, 0.5),
) -> bool:
    """Zentriert den Text diagonal auf jeder Seite. rotation in Grad,
    opacity zwischen 0 (unsichtbar) und 1 (voll deckend)."""
    try:
        document = fitz.open(path)
        for page in document:
            center = fitz.Point(page.rect.width / 2, page.rect.height / 2)
            morph = (center, fitz.Matrix(rotation))
            text_width = fitz.get_text_length(text, fontsize=font_size)
            point = fitz.Point(center.x - text_width / 2, center.y)
            page.insert_text(
                point, text, fontsize=font_size, color=color,
                fill_opacity=opacity, morph=morph, overlay=True,
            )
        document.save(output_path)
        document.close()
        return True
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Einfügen des Wasserzeichens", exc)
        return False


def get_page_count(path: str) -> int:
    try:
        document = fitz.open(path)
        count = document.page_count
        document.close()
        return count
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Ermitteln der Seitenzahl", exc)
        return 0

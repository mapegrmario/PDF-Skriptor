"""
home_view.py
Startseite von PDF Skriptor: Begrüßung mit Avatar, kurze Erklärung des
Programmzwecks und Schnellzugriffs-Kacheln zu den wichtigsten
Werkzeugen. Erscheint in der schmalen Werkzeug-Seitenleiste, waehrend
die Dokumentenansicht in der Mitte permanent sichtbar bleibt.
Jede Kachel: farbiges 3D-Icon links (icons/icon_<modul>.png, siehe
generate_icons.py), Titel/Beschreibung rechts, duenner Rahmen in der
Icon-Farbe des jeweiligen Werkzeugs.
"""

import os
import customtkinter as ctk
from PIL import Image
from language import t
import theme
from scroll_helpers import bind_mousewheel_scroll

_AVATAR_FILENAME = "avatar.png"
_ICONS_SUBDIR = "icons"
_CARD_WRAPLENGTH = 210
_ICON_SIZE = 44
# Versatz zwischen dem farbigen Rahmen-Frame und dem Button darin (siehe
# Kommentar in _add_tool_card) - hier auf Modulebene, da sowohl beim Erzeugen
# der Kachel als auch beim spaeteren Breiten-Abgleich benoetigt.
_BORDER_GAP = 2

# (Modul-Schluessel, Notfall-Emoji falls PNG fehlt, Sprachschluessel,
# Beschreibungs-Sprachschluessel, Farbe - MUSS mit ICONS in generate_icons.py
# uebereinstimmen). QA-Fix: Beschreibung ist seit dem Usability-Audit ein
# Uebersetzungsschluessel (frueher hartkodiert deutscher Text, siehe
# _build_tool_section unten, wo er jetzt durch t() laeuft).
_OFFICE_TOOLS = [
    ("organize", "📄", "nav_organize", "desc_organize", "#3B82F6"),
    ("forms", "🖊️", "nav_forms", "desc_forms", "#14B8A6"),
    ("metadata", "🏷️", "nav_metadata", "desc_metadata", "#8B5CF6"),
    ("compress", "🗜️", "nav_compress", "desc_compress", "#F97316"),
    ("security", "🔒", "nav_security", "desc_security", "#DC2626"),
    ("annotate", "✏️", "nav_annotate", "desc_annotate", "#EAB308"),
    ("outline", "📑", "nav_outline", "desc_outline", "#6366F1"),
    ("header_footer", "🔢", "nav_header_footer", "desc_header_footer", "#0EA5E9"),
    ("watermark", "💧", "nav_watermark", "desc_watermark", "#06B6D4"),
    ("pdfa", "🗄️", "nav_pdfa", "desc_pdfa", "#92400E"),
    ("search", "🔍", "nav_search", "desc_search", "#10B981"),
    ("reorder", "🗂️", "nav_reorder", "desc_reorder", "#A855F7"),
    ("sign", "🔏", "nav_sign", "desc_sign", "#E11D48"),
    ("print", "🖨️", "nav_print", "desc_print", "#1E3A8A"),
]

_UNIQUE_TOOLS = [
    ("ocr", "🔍", "nav_ocr", "desc_ocr", "#22C55E"),
    ("compare", "⇄", "nav_compare", "desc_compare", "#F59E0B"),
    ("redact", "▪️", "nav_redact", "desc_redact", "#334155"),
    ("convert", "📝", "nav_convert", "desc_convert", "#7C3AED"),
    ("pipeline", "🔗", "nav_pipeline", "desc_pipeline", "#F43F5E"),
]

# QA-Fix (Usability-Audit, Befund 1.3): Einstellungen/Hilfe/Ueber sind
# jetzt als Icons direkt neben "☰ Menü" erreichbar (app_window.py) statt
# als zusaetzliche Kacheln ganz unten in dieser langen scrollbaren
# Liste - dadurch drei Kacheln kuerzer und die verbleibenden Werkzeuge
# insgesamt etwas naeher am oberen Rand.


class HomeView(ctk.CTkFrame):
    """Begrüßungsbildschirm mit Kurzüberblick und Schnellzugriff."""

    def __init__(self, master, on_navigate) -> None:
        super().__init__(master, fg_color=theme.COLOR_BG)
        self._on_navigate = on_navigate
        self._icon_images: list = []
        self._card_pairs: list[tuple] = []
        self._build_ui()
        # CTkButton zeichnet seine abgerundete Flaeche anhand des eigenen
        # width-Parameters (Default 140) und aktualisiert diesen NICHT
        # automatisch, nur weil pack(fill="both") das Widget breiter
        # zieht - die Klickflaeche waechst zwar korrekt mit, die sichtbare
        # Form bleibt aber zu schmal, wodurch der Rahmen-Frame dahinter auf
        # der rechten Seite als grosser, unpassender Farbblock durchscheint.
        # Deshalb hier einmalig nach dem ersten Layout UND bei jeder
        # Groessenaenderung die tatsaechliche Breite nachtragen.
        self.after(50, self._sync_card_widths)
        self._scroll_area.bind("<Configure>", lambda event: self._sync_card_widths())

    def _sync_card_widths(self) -> None:
        for border_frame, card in self._card_pairs:
            width = border_frame.winfo_width() - 2 * _BORDER_GAP
            if width > 10 and card.cget("width") != width:
                card.configure(width=width)

    def _build_ui(self) -> None:
        self._scroll_area = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self._scroll_area.pack(fill="both", expand=True, padx=theme.PADDING_MEDIUM, pady=theme.PADDING_MEDIUM)
        bind_mousewheel_scroll(self._scroll_area)

        scroll_area = self._scroll_area
        self._build_header(scroll_area)
        self._build_quick_start_hint(scroll_area)
        self._build_tool_section(scroll_area, t("home_office_heading"), _OFFICE_TOOLS)
        self._build_tool_section(scroll_area, t("home_unique_heading"), _UNIQUE_TOOLS)

    def _build_header(self, parent) -> None:
        header = ctk.CTkFrame(parent, fg_color="transparent")
        header.pack(fill="x", pady=(0, theme.PADDING_MEDIUM))

        avatar_image = self._load_square_image(_AVATAR_FILENAME, 72)
        if avatar_image is not None:
            avatar_label = ctk.CTkLabel(header, image=avatar_image, text="")
            avatar_label.pack(anchor="w", pady=(0, theme.PADDING_SMALL))

        greeting = ctk.CTkLabel(
            header, text=t("home_greeting"), font=theme.font_heading(), text_color=theme.COLOR_TEXT,
        )
        greeting.pack(anchor="w")

        intro = ctk.CTkLabel(
            header, text=t("home_intro"), font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED,
            wraplength=_CARD_WRAPLENGTH + 20, justify="left",
        )
        intro.pack(anchor="w", pady=(theme.PADDING_SMALL, 0))

    def _build_quick_start_hint(self, parent) -> None:
        hint_card = ctk.CTkFrame(parent, fg_color=theme.COLOR_ACCENT_SOFT, corner_radius=theme.CORNER_RADIUS)
        hint_card.pack(fill="x", pady=(0, theme.PADDING_MEDIUM))
        hint_label = ctk.CTkLabel(
            hint_card, text=f"💡  {t('home_quick_start')}", font=theme.font_small(), text_color=theme.COLOR_ACCENT,
            wraplength=_CARD_WRAPLENGTH, justify="left",
        )
        hint_label.pack(anchor="w", padx=theme.PADDING_MEDIUM, pady=theme.PADDING_MEDIUM)

    def _build_tool_section(self, parent, heading: str, tools: list[tuple]) -> None:
        heading_label = ctk.CTkLabel(parent, text=heading, font=theme.font_body(), text_color=theme.COLOR_TEXT)
        heading_label.pack(anchor="w", pady=(0, theme.PADDING_SMALL))

        column = ctk.CTkFrame(parent, fg_color="transparent")
        column.pack(fill="x", pady=(0, theme.PADDING_MEDIUM))

        sorted_tools = sorted(tools, key=lambda item: t(item[2]))
        for module_key, icon, label_key, desc_key, color in sorted_tools:
            self._add_tool_card(column, module_key, icon, t(label_key), t(desc_key), color)

    def _add_tool_card(self, column, module_key: str, icon: str, title: str, description: str, color: str) -> None:
        # Der farbige Rahmen kommt bewusst NICHT von CTkButton's eigenem
        # border_width: Die ueberlagerten Icon-/Text-Widgets (als "transparent"
        # deklariert) malen in CustomTkinter in Wirklichkeit eine deckende
        # Flaeche in der Hintergrundfarbe des Elternteils (keine echte
        # Transparenz) und wuerden den Rahmen des Buttons darunter teilweise
        # uebermalen. Stattdessen liegt ein groesserer, farbiger Frame HINTER
        # dem eigentlichen Button - der Rahmen entsteht rein durch den
        # kleinen sichtbaren Rand, den dieser Hintergrund-Frame ueberall
        # gleichmaessig ueberragt.
        # Der Versatz zwischen aussen (Frame) und innen (Button) betraegt
        # bewusst 2px statt 1px: CustomTkinter rundet corner_radius intern
        # in Abhaengigkeit von der Bildschirmskalierung auf eigene Schritte
        # (siehe draw_engine.__calc_optimal_corner_radius), wodurch zwei
        # UNABHAENGIG gezeichnete Rundungen bei nur 1px nominalem Versatz auf
        # manchen Skalierungsstufen nicht mehr exakt konzentrisch sind - das
        # zeigt sich als leicht ungleichmaessiger Rahmen genau in den Ecken.
        # 2px (_BORDER_GAP, Modulebene) lassen genug Spielraum, damit das
        # unabhaengige Runden beider Widgets nicht mehr sichtbar wird.
        border_frame = ctk.CTkFrame(column, fg_color=color, corner_radius=theme.CORNER_RADIUS + _BORDER_GAP)
        border_frame.pack(fill="x", pady=(0, theme.PADDING_SMALL))

        card = ctk.CTkButton(
            border_frame, text="", fg_color=theme.COLOR_BG_SECONDARY, hover=False,
            corner_radius=theme.CORNER_RADIUS, height=64, anchor="w",
            command=lambda: self._on_navigate(module_key),
        )
        card.pack(fill="both", expand=True, padx=_BORDER_GAP, pady=_BORDER_GAP)
        self._card_pairs.append((border_frame, card))

        # Icon und Text werden DIREKT auf die Kachel gelegt (nicht in einen
        # zusaetzlichen Vollflaechen-Frame) - ein transparenter CTkFrame
        # leitet Klicks in CustomTkinter naemlich nicht weiter, wuerde also
        # nur eine tote Zone ueber der restlichen Kachel erzeugen.
        icon_image = self._load_square_image(os.path.join(_ICONS_SUBDIR, f"icon_{module_key}.png"), _ICON_SIZE)
        if icon_image is not None:
            icon_label = ctk.CTkLabel(card, image=icon_image, text="", fg_color=theme.COLOR_BG_SECONDARY)
        else:
            icon_label = ctk.CTkLabel(
                card, text=icon, font=ctk.CTkFont(size=_ICON_SIZE // 2), fg_color=theme.COLOR_BG_SECONDARY,
            )
        icon_label.place(relx=0.06, rely=0.5, anchor="w")

        text_frame = ctk.CTkFrame(card, fg_color=theme.COLOR_BG_SECONDARY)
        text_frame.place(relx=0.06 + (_ICON_SIZE + 14) / 260, rely=0.5, anchor="w")

        title_label = ctk.CTkLabel(
            text_frame, text=title, font=theme.font_body(), text_color=theme.COLOR_TEXT, anchor="w",
            fg_color=theme.COLOR_BG_SECONDARY,
        )
        title_label.pack(anchor="w")
        description_label = ctk.CTkLabel(
            text_frame, text=description, font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED,
            justify="left", anchor="w", wraplength=_CARD_WRAPLENGTH, fg_color=theme.COLOR_BG_SECONDARY,
        )
        description_label.pack(anchor="w")

        # CTkLabel leitet einen <Button-1>-Klick auf sich selbst nicht an
        # Python weiter - nur die intern genutzten rohen tkinter-Widgets
        # (_label/_canvas) empfangen das Ereignis tatsaechlich. Dasselbe gilt
        # fuer <Enter>/<Leave> (Hover), deshalb unten die eigene, ueber alle
        # Teile der Kachel synchronisierte Hover-Faerbung statt des
        # eingebauten (aber hier abgeschalteten) CTkButton-Hovers - sonst
        # bliebe der weisse Hintergrund von Icon/Text beim Hover stehen,
        # waehrend nur der Button selbst die Hover-Farbe annimmt (genau der
        # gemeldete Fehler mit den eckigen weissen Flecken).
        def handle_click(_event=None) -> None:
            self._on_navigate(module_key)

        overlay_labels = (icon_label, title_label, description_label)
        for label in overlay_labels:
            label.bind("<Button-1>", handle_click)
            label._label.bind("<Button-1>", handle_click)
            label._canvas.bind("<Button-1>", handle_click)

        def set_hovered(is_hovered: bool) -> None:
            fill = theme.COLOR_ACCENT_SOFT if is_hovered else theme.COLOR_BG_SECONDARY
            card.configure(fg_color=fill)
            text_frame.configure(fg_color=fill)
            for label in overlay_labels:
                label.configure(fg_color=fill)

        hover_targets = [card._canvas] + [w for label in overlay_labels for w in (label._label, label._canvas)]
        for widget in hover_targets:
            widget.bind("<Enter>", lambda event: set_hovered(True), add="+")
            widget.bind("<Leave>", lambda event: set_hovered(False), add="+")

    def _load_square_image(self, filename: str, size: int):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        path = os.path.join(base_dir, filename)
        if not os.path.isfile(path):
            return None
        try:
            pil_image = Image.open(path)
            ctk_image = ctk.CTkImage(light_image=pil_image, dark_image=pil_image, size=(size, size))
            self._icon_images.append(ctk_image)
            return ctk_image
        except Exception:  # noqa: BLE001
            return None

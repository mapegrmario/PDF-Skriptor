"""
organize_delete_ui.py
Unter-Werkzeug: Entfernt einzelne, per Seitenzahl angegebene Seiten
aus der aktiven PDF-Datei (z. B. "1,3,5-7") und speichert das Ergebnis.
"""

import os
import tkinter.filedialog as filedialog
from tkinter import messagebox
import customtkinter as ctk
from language import t
import settings as settings_store
import theme
from organize_logic import delete_pages, get_page_count
from reorder_logic import render_thumbnails
from delete_page_card import DeletePageCard
from file_list_sync import sync_active_file, load_result_file

_THUMBNAIL_WIDTH = 70
_THUMBNAILS_PER_ROW = 4


class OrganizeDeleteTool(ctk.CTkFrame):
    """UI zum Loeschen einzelner Seiten aus der aktiven PDF-Datei -
    wahlweise per Texteingabe oder per Anklicken der Seiten-Miniaturen
    (beide Wege sind gleichwertig und bleiben synchron: Klicks werden in
    die Textzeile geschrieben, manuelle Texteingaben faerben passend
    die Miniaturen ein)."""

    def __init__(self, master, file_manager) -> None:
        super().__init__(master, fg_color="transparent")
        self._file_manager = file_manager
        self._active_path: str | None = None
        self._info_label: ctk.CTkLabel | None = None
        self._thumbnail_images: list = []
        self._page_cards: list[DeletePageCard] = []
        self._build_ui()
        sync_active_file(self, self._file_manager, self._handle_active_changed)

    def _build_ui(self) -> None:
        hint = ctk.CTkLabel(
            self, text=t("delete_hint"), font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED,
        )
        hint.pack(anchor="w", pady=(0, theme.PADDING_SMALL))

        self._active_file_label = ctk.CTkLabel(self, text="", font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED)
        self._active_file_label.pack(anchor="w", pady=(0, theme.PADDING_SMALL))

        self._info_label = ctk.CTkLabel(self, text="", font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED)
        self._info_label.pack(anchor="w", pady=(0, theme.PADDING_SMALL))

        self._pages_entry = ctk.CTkEntry(self, placeholder_text=t("delete_hint"))
        self._pages_entry.pack(anchor="w", fill="x", pady=(0, theme.PADDING_SMALL))
        self._pages_entry.bind("<KeyRelease>", self._handle_entry_typed)

        self._select_hint = ctk.CTkLabel(
            self, text=t("delete_select_hint"), font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED,
        )
        self._select_hint.pack(anchor="w", pady=(0, 4))

        self._thumbnail_area = ctk.CTkScrollableFrame(self, fg_color=theme.COLOR_BG, height=220)
        self._thumbnail_area.pack(anchor="w", fill="x", pady=(0, theme.PADDING_MEDIUM))
        for column in range(_THUMBNAILS_PER_ROW):
            self._thumbnail_area.grid_columnconfigure(column, weight=1)

        delete_button = ctk.CTkButton(
            self, text=t("delete_button"), fg_color=theme.COLOR_ERROR,
            hover_color="#B8352F", corner_radius=theme.CORNER_RADIUS,
            command=self._handle_delete,
        )
        delete_button.pack(anchor="w")

    def _handle_active_changed(self, path: str | None) -> None:
        self._active_path = path
        if path:
            self._active_file_label.configure(text=f"📄 {os.path.basename(path)}")
            count = get_page_count(path)
            self._info_label.configure(text=t("delete_page_count").format(n=count))
        else:
            self._active_file_label.configure(text=t("no_active_file_hint"))
            self._info_label.configure(text="")
        self._rebuild_thumbnails()

    def _rebuild_thumbnails(self) -> None:
        for card in self._page_cards:
            card.destroy()
        self._page_cards.clear()
        self._thumbnail_images.clear()
        if not self._active_path:
            return

        pil_images = render_thumbnails(self._active_path, width=_THUMBNAIL_WIDTH)
        selected = self._selected_pages_from_entry()
        for index, pil_image in enumerate(pil_images):
            page_number = index + 1
            ctk_image = ctk.CTkImage(
                light_image=pil_image, dark_image=pil_image,
                size=(pil_image.width, pil_image.height),
            )
            self._thumbnail_images.append(ctk_image)
            card = DeletePageCard(self._thumbnail_area, page_number, ctk_image, self._handle_card_toggled)
            card.grid(row=index // _THUMBNAILS_PER_ROW, column=index % _THUMBNAILS_PER_ROW, padx=3, pady=3)
            card.set_selected(page_number in selected)
            self._page_cards.append(card)

    def _parse_page_ranges(self, text: str, page_count: int) -> list[int]:
        """Wandelt Eingaben wie '1,3,5-7' in 0-basierte Seitenindizes um."""
        indices: set[int] = set()
        for part in text.split(","):
            part = part.strip()
            if not part:
                continue
            if "-" in part:
                start_str, end_str = part.split("-", 1)
                start, end = int(start_str), int(end_str)
                indices.update(range(start - 1, end))
            else:
                indices.add(int(part) - 1)
        return [i for i in indices if 0 <= i < page_count]

    def _selected_pages_from_entry(self) -> set[int]:
        """Liest die aktuelle Textzeile tolerant aus (1-basierte
        Seitenzahlen) - liefert eine leere Menge statt eines Fehlers,
        falls der Text gerade unvollstaendig/ungueltig ist (z. B.
        waehrend des Tippens)."""
        page_count = get_page_count(self._active_path) if self._active_path else 0
        try:
            return {i + 1 for i in self._parse_page_ranges(self._pages_entry.get(), page_count)}
        except ValueError:
            return set()

    def _set_entry_from_pages(self, pages: set[int]) -> None:
        self._pages_entry.delete(0, "end")
        self._pages_entry.insert(0, ",".join(str(p) for p in sorted(pages)))

    def _handle_card_toggled(self, page_number: int, selected: bool) -> None:
        pages = self._selected_pages_from_entry()
        if selected:
            pages.add(page_number)
        else:
            pages.discard(page_number)
        self._set_entry_from_pages(pages)

    def _handle_entry_typed(self, _event=None) -> None:
        selected = self._selected_pages_from_entry()
        for card in self._page_cards:
            card.set_selected(card.page_number in selected)

    def _handle_delete(self) -> None:
        if not self._active_path:
            messagebox.showinfo(t("app_title"), t("no_active_file_hint"))
            return

        page_count = get_page_count(self._active_path)
        try:
            page_indices = self._parse_page_ranges(self._pages_entry.get(), page_count)
        except ValueError:
            messagebox.showerror(t("app_title"), t("delete_invalid_range"))
            return

        if not page_indices:
            messagebox.showinfo(t("app_title"), t("delete_need_valid_pages"))
            return

        page_numbers = ", ".join(str(i + 1) for i in sorted(page_indices))
        if not messagebox.askyesno(
            t("app_title"), t("delete_pages_selected").format(n=len(page_indices), pages=page_numbers)
        ):
            return

        settings = settings_store.load_settings()
        base_name = os.path.splitext(os.path.basename(self._active_path))[0]
        default_path = os.path.join(settings.get("output_dir", "~"), f"{base_name}_bearbeitet.pdf")
        output_path = filedialog.asksaveasfilename(
            initialfile=os.path.basename(default_path),
            initialdir=os.path.dirname(default_path),
            defaultextension=".pdf",
            filetypes=[("PDF-Dateien", "*.pdf")],
        )
        if not output_path:
            return

        success = delete_pages(self._active_path, output_path, page_indices)
        if success:
            load_result_file(self._file_manager, output_path)
            messagebox.showinfo(t("app_title"), t("save_success"))
        else:
            messagebox.showerror(t("app_title"), t("error_generic"))

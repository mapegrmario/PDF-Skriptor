"""
outline_ui.py
Werkzeug-Panel fuer das Inhaltsverzeichnis (Lesezeichen/Bookmarks):
zeigt die vorhandenen Eintraege als bearbeitbare Liste
(outline_row.py), erlaubt Hinzufuegen/Loeschen/Umsortieren-per-Ebene
und springt beim Klick auf 🔎 direkt zur Zielseite in der gemeinsamen
Dokumentenansicht.
"""

import os
import tkinter.filedialog as filedialog
from tkinter import messagebox
import customtkinter as ctk
from language import t
import settings as settings_store
import theme
from outline_logic import read_outline, write_outline, get_page_count
from outline_row import OutlineRow
from file_list_sync import sync_active_file, load_result_file
from scroll_helpers import bind_mousewheel_scroll


class OutlineView(ctk.CTkFrame):
    """Werkzeug-Panel zum Anzeigen/Bearbeiten des Inhaltsverzeichnisses der aktiven Datei."""

    def __init__(self, master, file_manager, document_view) -> None:
        super().__init__(master, fg_color=theme.COLOR_BG)
        self._file_manager = file_manager
        self._document_view = document_view
        self._active_path: str | None = None
        self._page_count = 0
        self._rows: list[OutlineRow] = []
        self._build_ui()
        sync_active_file(self, self._file_manager, self._handle_active_changed)

    def _build_ui(self) -> None:
        title = ctk.CTkLabel(self, text=t("nav_outline"), font=theme.font_title(), text_color=theme.COLOR_TEXT)
        title.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(theme.PADDING_LARGE, theme.PADDING_SMALL))

        self._active_file_label = ctk.CTkLabel(self, text="", font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED)
        self._active_file_label.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_SMALL))

        self._hint_label = ctk.CTkLabel(
            self, text=t("outline_jump_hint"), font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED,
            wraplength=300, justify="left",
        )
        self._hint_label.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        self._scroll_area = ctk.CTkScrollableFrame(self, fg_color=theme.COLOR_BG, corner_radius=0)
        self._scroll_area.pack(fill="both", expand=True, padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_SMALL))
        bind_mousewheel_scroll(self._scroll_area)

        self._empty_label = ctk.CTkLabel(
            self._scroll_area, text=t("outline_empty_hint"), font=theme.font_small(),
            text_color=theme.COLOR_TEXT_MUTED, wraplength=280, justify="left",
        )

        add_button = ctk.CTkButton(
            self, text=t("outline_add_entry"), fg_color="transparent", border_width=1,
            border_color=theme.COLOR_BORDER, text_color=theme.COLOR_TEXT, hover_color=theme.COLOR_ACCENT_SOFT,
            corner_radius=theme.CORNER_RADIUS, command=self._handle_add_entry,
        )
        add_button.pack(fill="x", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_SMALL))

        save_button = ctk.CTkButton(
            self, text=t("outline_save"), fg_color=theme.COLOR_ACCENT, hover_color=theme.COLOR_ACCENT_HOVER,
            corner_radius=theme.CORNER_RADIUS, command=self._handle_save,
        )
        save_button.pack(fill="x", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_LARGE))

    def _handle_active_changed(self, path: str | None) -> None:
        self._active_path = path
        if path:
            self._active_file_label.configure(text=f"📄 {os.path.basename(path)}")
            self._page_count = get_page_count(path)
            self._load_entries(read_outline(path))
        else:
            self._active_file_label.configure(text=t("no_active_file_hint"))
            self._page_count = 0
            self._load_entries([])

    def _load_entries(self, entries: list[dict]) -> None:
        for row in self._rows:
            row.destroy()
        self._rows = []
        for entry in entries:
            self._add_row(entry["level"], entry["title"], entry["page"])
        self._refresh_empty_hint()

    def _add_row(self, level: int, title: str, page: int) -> None:
        row = OutlineRow(self._scroll_area, level, title, page, on_jump=self._jump_to_page, on_delete=self._remove_row)
        row.pack(fill="x", pady=(0, theme.PADDING_SMALL))
        self._rows.append(row)

    def _handle_add_entry(self) -> None:
        if not self._active_path:
            messagebox.showinfo(t("app_title"), t("no_active_file_hint"))
            return
        current_page = self._document_view.get_page_index() + 1
        self._add_row(1, "", current_page)
        self._refresh_empty_hint()

    def _remove_row(self, row: OutlineRow) -> None:
        row.destroy()
        self._rows.remove(row)
        self._refresh_empty_hint()

    def _refresh_empty_hint(self) -> None:
        if self._rows:
            self._empty_label.pack_forget()
        else:
            self._empty_label.pack(anchor="w", pady=theme.PADDING_MEDIUM)

    def _jump_to_page(self, page: int) -> None:
        self._document_view.set_page_index(page - 1)

    def _handle_save(self) -> None:
        if not self._active_path:
            messagebox.showinfo(t("app_title"), t("no_active_file_hint"))
            return

        entries = [row.get_values() for row in self._rows]
        for entry in entries:
            if not (1 <= entry["page"] <= max(self._page_count, 1)):
                messagebox.showerror(
                    t("app_title"),
                    t("outline_invalid_page").format(title=entry["title"] or "?", max=self._page_count),
                )
                return

        if not entries and not messagebox.askyesno(t("app_title"), t("outline_saved_no_entries")):
            return

        settings = settings_store.load_settings()
        base_name = os.path.splitext(os.path.basename(self._active_path))[0]
        default_path = os.path.join(settings.get("output_dir", "~"), f"{base_name}_lesezeichen.pdf")
        output_path = filedialog.asksaveasfilename(
            initialfile=os.path.basename(default_path),
            initialdir=os.path.dirname(default_path),
            defaultextension=".pdf",
            filetypes=[("PDF-Dateien", "*.pdf")],
        )
        if not output_path:
            return

        success = write_outline(self._active_path, output_path, entries)
        if success:
            load_result_file(self._file_manager, output_path)
            messagebox.showinfo(t("app_title"), t("save_success"))
        else:
            messagebox.showerror(t("app_title"), t("error_generic"))

"""
metadata_ui.py
UI fuer das Metadaten-Modul. Zeigt Metadaten der aktiven Datei zum
Bearbeiten und erlaubt optional das Uebertragen auf alle geladenen
Dateien (Batch-Modus) - z. B. fuer die Ablage/Archivierung im Büro.
"""

import os
from tkinter import messagebox
import customtkinter as ctk
from language import t
import theme
from metadata_logic import read_metadata, write_metadata, write_metadata_batch, METADATA_FIELDS
from file_list_sync import sync_active_file

_FIELD_LABEL_KEYS = {
    "/Title": "metadata_field_title",
    "/Author": "metadata_field_author",
    "/Subject": "metadata_field_subject",
    "/Keywords": "metadata_field_keywords",
}


class MetadataView(ctk.CTkFrame):
    """Ansicht zum Anzeigen und Bearbeiten von PDF-Metadaten der aktiven Datei."""

    def __init__(self, master, file_manager) -> None:
        super().__init__(master, fg_color=theme.COLOR_BG)
        self._file_manager = file_manager
        self._entries: dict[str, ctk.CTkEntry] = {}
        self._active_path: str | None = None
        self._batch_var = ctk.BooleanVar(value=False)
        self._build_ui()
        sync_active_file(self, self._file_manager, self._handle_active_changed)

    def _build_ui(self) -> None:
        title = ctk.CTkLabel(self, text=t("nav_metadata"), font=theme.font_title(), text_color=theme.COLOR_TEXT)
        title.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(theme.PADDING_LARGE, theme.PADDING_SMALL))

        self._active_file_label = ctk.CTkLabel(
            self, text="", font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED,
        )
        self._active_file_label.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        card = ctk.CTkFrame(self, fg_color=theme.COLOR_BG_SECONDARY, corner_radius=theme.CORNER_RADIUS)
        card.pack(fill="x", padx=theme.PADDING_LARGE, pady=theme.PADDING_SMALL)

        for field in METADATA_FIELDS:
            self._build_field_row(card, field)

        batch_checkbox = ctk.CTkCheckBox(
            self, text=t("metadata_batch_checkbox"),
            variable=self._batch_var, font=theme.font_small(),
        )
        batch_checkbox.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(theme.PADDING_MEDIUM, theme.PADDING_SMALL))

        save_button = ctk.CTkButton(
            self, text=t("metadata_save_button"), fg_color=theme.COLOR_ACCENT, hover_color=theme.COLOR_ACCENT_HOVER,
            corner_radius=theme.CORNER_RADIUS, command=self._handle_save,
        )
        save_button.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_LARGE))

    def _build_field_row(self, card, field: str) -> None:
        row = ctk.CTkFrame(card, fg_color="transparent")
        row.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=theme.PADDING_SMALL)

        label = ctk.CTkLabel(row, text=t(_FIELD_LABEL_KEYS[field]), font=theme.font_body(), text_color=theme.COLOR_TEXT, width=100, anchor="w")
        label.pack(side="left")

        entry = ctk.CTkEntry(row)
        entry.pack(side="left", fill="x", expand=True)
        self._entries[field] = entry

    def _handle_active_changed(self, path: str | None) -> None:
        self._active_path = path
        if path:
            self._active_file_label.configure(text=f"📄 {os.path.basename(path)}")
        else:
            self._active_file_label.configure(text=t("no_active_file_hint"))
        self._load_current_metadata()

    def _load_current_metadata(self) -> None:
        if not self._active_path:
            for entry in self._entries.values():
                entry.delete(0, "end")
            return
        values = read_metadata(self._active_path)
        for field, entry in self._entries.items():
            entry.delete(0, "end")
            entry.insert(0, values.get(field, ""))

    def _handle_save(self) -> None:
        if not self._active_path:
            messagebox.showinfo(t("app_title"), t("no_active_file_hint"))
            return

        values = {field: entry.get() for field, entry in self._entries.items()}

        if self._batch_var.get():
            files = self._file_manager.get_files()
            count = write_metadata_batch(files, values)
            messagebox.showinfo(t("app_title"), t("metadata_batch_result").format(count=count, total=len(files)))
        else:
            success = write_metadata(self._active_path, self._active_path, values)
            if success:
                messagebox.showinfo(t("app_title"), t("save_success"))
            else:
                messagebox.showerror(t("app_title"), t("error_generic"))

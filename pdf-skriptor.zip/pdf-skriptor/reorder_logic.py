"""
reorder_logic.py
Erzeugt kleine Seiten-Vorschaubilder und schreibt eine neue
Seitenreihenfolge in eine PDF-Datei - Grundlage fuer das
Drag-&-Drop-Neuordnen im Modul "Seiten neu ordnen".
"""

import pymupdf as fitz  # "fitz" ist der veraltete Alias, siehe PyMuPDF-Deprecation-Hinweis
from PIL import Image
from logger_setup import log_exception

_THUMBNAIL_WIDTH = 90


def get_page_count(path: str) -> int:
    try:
        document = fitz.open(path)
        count = document.page_count
        document.close()
        return count
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Ermitteln der Seitenzahl", exc)
        return 0


def render_thumbnails(path: str, width: int = _THUMBNAIL_WIDTH) -> list:
    """Liefert fuer jede Seite ein kleines Vorschaubild (feste Breite,
    proportionale Hoehe) in Originalreihenfolge - Index 0 = Seite 1.
    `width` ist optional (Standard = _THUMBNAIL_WIDTH, wie bisher fuer
    "Seiten neu ordnen") - page_preview_strip.py nutzt eine kleinere
    Breite fuer den kompakteren Streifen zwischen Werkbank und
    Seitenansicht."""
    thumbnails = []
    try:
        document = fitz.open(path)
        for page in document:
            zoom = width / page.rect.width
            pixmap = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom))
            mode = "RGB" if pixmap.n < 4 else "RGBA"
            image = Image.frombytes(mode, (pixmap.width, pixmap.height), pixmap.samples)
            thumbnails.append(image)
        document.close()
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Erzeugen der Seiten-Vorschau", exc)
    return thumbnails


def apply_page_order(path: str, output_path: str, order: list) -> bool:
    """order: Liste der 0-basierten Original-Seitenindizes in der neuen
    gewuenschten Reihenfolge (muss jede Seite genau einmal enthalten)."""
    try:
        document = fitz.open(path)
        document.select(order)
        document.save(output_path)
        document.close()
        return True
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Speichern der neuen Seitenreihenfolge", exc)
        return False

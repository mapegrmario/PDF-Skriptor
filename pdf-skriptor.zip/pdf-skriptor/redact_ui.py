"""
redact_ui.py
Container-Ansicht fuer das Redaction-Modul. Bietet zwei Wege, Inhalte
dauerhaft zu entfernen: automatische Suche nach einem Begriff oder
manuelles Markieren von Bereichen auf der Dokumentenansicht. Leitet
on_shown()/on_hidden() an das jeweils aktive Unter-Werkzeug weiter,
damit die geteilte Dokumentenansicht unabhaengig davon sauber
gebunden/geloest wird, ob das ganze Redaction-Modul oder nur der
interne Modus gewechselt wird.
"""

import customtkinter as ctk
from language import t
import theme
from redact_search_ui import RedactSearchTool
from redact_manual_ui import RedactManualTool

_MODES = {
    "redact_mode_search": RedactSearchTool,
    "redact_mode_manual": RedactManualTool,
}


class RedactView(ctk.CTkFrame):
    """Oberste Ansicht des Redaction-Moduls."""

    def __init__(self, master, file_manager, document_view) -> None:
        super().__init__(master, fg_color=theme.COLOR_BG)
        self._file_manager = file_manager
        self._document_view = document_view
        self._tool_container: ctk.CTkFrame | None = None
        self._active_tool: ctk.CTkFrame | None = None
        self._build_ui()

    def _build_ui(self) -> None:
        title = ctk.CTkLabel(self, text=t("redact_title"), font=theme.font_title(), text_color=theme.COLOR_TEXT)
        title.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(theme.PADDING_LARGE, theme.PADDING_SMALL))

        subtitle = ctk.CTkLabel(
            self, text=t("redact_subtitle"),
            font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED, wraplength=300, justify="left",
        )
        subtitle.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_SMALL))

        self._key_by_display = {t(mode_key): mode_key for mode_key in _MODES}
        values = list(self._key_by_display.keys())
        self._selector = ctk.CTkSegmentedButton(self, values=values, command=self._handle_mode_selected)
        self._selector.set(values[0])
        self._selector.pack(fill="x", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        self._tool_container = ctk.CTkFrame(self, fg_color="transparent")
        self._tool_container.pack(fill="both", expand=True, padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_LARGE))

        self._create_mode(list(_MODES.keys())[0])

    def _handle_mode_selected(self, value: str) -> None:
        # Wird nur durch einen echten Klick des Nutzers ausgeloest, das
        # Redaction-Modul ist in diesem Fall also garantiert sichtbar -
        # deshalb hier direkt on_shown()/on_hidden() am Unter-Werkzeug
        # aufrufen, nicht erst ueber app_window.py.
        mode_key = self._key_by_display.get(value)
        if mode_key is None:
            return
        if isinstance(self._active_tool, RedactManualTool):
            self._active_tool.on_hidden()
        self._create_mode(mode_key)
        if isinstance(self._active_tool, RedactManualTool):
            self._active_tool.on_shown()

    def has_unsaved_changes(self) -> bool:
        check = getattr(self._active_tool, "has_unsaved_changes", None)
        return bool(check()) if callable(check) else False

    def _create_mode(self, mode_key: str) -> None:
        if self._active_tool is not None:
            self._active_tool.destroy()

        tool_cls = _MODES[mode_key]
        if tool_cls is RedactManualTool:
            self._active_tool = tool_cls(self._tool_container, self._file_manager, self._document_view)
        else:
            self._active_tool = tool_cls(self._tool_container, self._file_manager)
        self._active_tool.pack(fill="both", expand=True)

    def on_shown(self) -> None:
        """Wird von app_window.py aufgerufen, wenn das gesamte
        Redaction-Modul (wieder) sichtbar wird."""
        if isinstance(self._active_tool, RedactManualTool):
            self._active_tool.on_shown()

    def on_hidden(self) -> None:
        """Wird von app_window.py aufgerufen, bevor zu einem anderen
        Werkzeug gewechselt wird."""
        if isinstance(self._active_tool, RedactManualTool):
            self._active_tool.on_hidden()

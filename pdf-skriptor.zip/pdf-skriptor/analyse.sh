#!/bin/bash
# ============================================================================
# PDF Skriptor – Analyse-Script
# Direktdiagnose von Installation, Konfiguration und Ausgabedateien ohne GUI
# Autor: Mario Peeß / Großenhain  |  mapegr@mailbox.org
# ============================================================================

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG="$SCRIPT_DIR/fehler.log"
SETTINGS="$HOME/.config/pdf-skriptor/pdf_skriptor_settings.json"
VENV="$SCRIPT_DIR/venv"

# ── Argumente ────────────────────────────────────────────────────────────────
OUTPUT_DIR=""
LOG_LINES=20
for i in "$@"; do
    case $i in
        --output-dir=*) OUTPUT_DIR="${i#*=}" ;;
        --log-lines=*) LOG_LINES="${i#*=}" ;;
        --full-log)
            [ -f "$LOG" ] && cat "$LOG" || echo "Kein fehler.log vorhanden."
            exit 0 ;;
        --help|-h)
            echo "Verwendung: $0 [--output-dir=PFAD] [--log-lines=N] [--full-log]"
            echo "  --output-dir=PFAD  Zu analysierender Ausgabeordner (Standard: aus den Einstellungen)"
            echo "  --log-lines=20     Anzahl Zeilen aus fehler.log am Ende (Standard: 20)"
            echo "  --full-log         Nur das komplette fehler.log ausgeben und beenden"
            exit 0 ;;
    esac
done

# Ausgabeordner aus den gespeicherten Einstellungen lesen, falls nicht per
# Argument angegeben - muss mit dem Ordner uebereinstimmen, den die GUI unter
# "Einstellungen" anzeigt.
if [ -z "$OUTPUT_DIR" ] && [ -f "$SETTINGS" ]; then
    OUTPUT_DIR=$(grep -o '"output_dir"[[:space:]]*:[[:space:]]*"[^"]*"' "$SETTINGS" | sed -E 's/.*: *"(.*)"/\1/')
fi
OUTPUT_DIR="${OUTPUT_DIR:-$HOME/Dokumente}"

# ── Header ───────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${BOLD}║          📄  PDF Skriptor – Analyse-Report               ║${NC}"
echo -e "${BOLD}╚══════════════════════════════════════════════════════════╝${NC}"
echo -e "   Datum:         $(date '+%d.%m.%Y %H:%M')"
echo -e "   Ausgabeordner: ${CYAN}${OUTPUT_DIR}${NC}"
echo ""

# ── Systemabhängigkeiten ─────────────────────────────────────────────────────
echo -e "${BLUE}── Systemabhängigkeiten ────────────────────────────────────${NC}"

check_tool() {
    local name="$1" cmd="$2" hint="$3"
    if command -v "$cmd" &>/dev/null; then
        local version_full version status
        version_full=$("$cmd" --version 2>&1)
        status=$?
        version=$(echo "$version_full" | head -1)
        if [ "$status" -eq 0 ]; then
            echo -e "   ${GREEN}✓${NC} ${name}: ${version}"
        else
            echo -e "   ${YELLOW}⚠${NC} ${name} gefunden, aber Aufruf schlägt fehl (evtl. defekte Abhängigkeit):"
            echo -e "       ${version}"
        fi
    else
        echo -e "   ${RED}✗${NC} ${name} nicht gefunden.  → ${hint}"
    fi
}

check_tool "Python 3"     "python3"  "sudo apt install python3"
check_tool "Ghostscript"  "gs"       "sudo apt install ghostscript"
check_tool "ocrmypdf"     "ocrmypdf" "sudo apt install ocrmypdf"
check_tool "qpdf"         "qpdf"     "sudo apt install qpdf"

if command -v tesseract &>/dev/null; then
    LANGS=$(tesseract --list-langs 2>&1 | tail -n +2 | tr '\n' ' ')
    echo -e "   ${GREEN}✓${NC} Tesseract-Sprachen: ${LANGS:-keine gefunden}"
else
    echo -e "   ${RED}✗${NC} Tesseract nicht gefunden.  → sudo apt install tesseract-ocr"
fi

if command -v gs &>/dev/null; then
    PDFA_TEMPLATE=$(ls /usr/share/ghostscript/*/lib/PDFA_def.ps 2>/dev/null | head -1)
    ICC_PROFILE="/usr/share/color/icc/ghostscript/srgb.icc"
    if [ -f "$PDFA_TEMPLATE" ] && { [ -f "$ICC_PROFILE" ] || ls /usr/share/ghostscript/*/iccprofiles/srgb.icc &>/dev/null; }; then
        echo -e "   ${GREEN}✓${NC} PDF/A-Archivierung: Zusatzdateien von Ghostscript gefunden"
    else
        echo -e "   ${YELLOW}⚠${NC} PDF/A-Archivierung: Ghostscript vorhanden, aber PDFA_def.ps/ICC-Profil fehlen (unvollständige Ghostscript-Installation?)"
    fi
fi
echo ""

# ── Speicherplatz ────────────────────────────────────────────────────────────
# Relevant vor allem fuer OCR: ocrmypdf legt waehrend der Verarbeitung
# groessere Zwischendateien in /tmp an. Ist dort zu wenig Platz frei, kann
# der Vorgang mitten im Schreiben abbrechen und eine leere/unvollstaendige
# PDF-Datei hinterlassen, obwohl kein deutlicher Fehler angezeigt wird.
echo -e "${BLUE}── Speicherplatz ───────────────────────────────────────────${NC}"
TMP_FREE=$(df -h /tmp 2>/dev/null | awk 'NR==2 {print $4}')
TMP_FREE_KB=$(df /tmp 2>/dev/null | awk 'NR==2 {print $4}')
if [ -n "$TMP_FREE_KB" ] && [ "$TMP_FREE_KB" -lt 1048576 ] 2>/dev/null; then
    echo -e "   ${YELLOW}⚠${NC}  Freier Speicher in /tmp: ${TMP_FREE:-unbekannt} (unter 1 GB - kann bei großen OCR-Scans knapp werden)"
else
    echo -e "   ${GREEN}✓${NC} Freier Speicher in /tmp: ${TMP_FREE:-unbekannt}"
fi
if [ -d "$OUTPUT_DIR" ]; then
    OUT_FREE=$(df -h "$OUTPUT_DIR" 2>/dev/null | awk 'NR==2 {print $4}')
    echo -e "   ${GREEN}✓${NC} Freier Speicher im Ausgabeordner: ${OUT_FREE:-unbekannt}"
fi
echo ""

# ── Python-Umgebung ──────────────────────────────────────────────────────────
echo -e "${BLUE}── Python-Umgebung ─────────────────────────────────────────${NC}"
if [ -d "$VENV" ] && [ -f "$VENV/bin/pip" ]; then
    echo -e "   ${GREEN}✓${NC} Virtuelle Umgebung gefunden: $VENV"
    echo "   Installierte Kern-Pakete:"
    "$VENV/bin/pip" list 2>/dev/null | grep -iE "^(customtkinter|pypdf|pikepdf|pymupdf|pillow|tkinterdnd2)[[:space:]]" | \
        while read -r line; do echo "     $line"; done
else
    echo -e "   ${YELLOW}⚠${NC}  Keine virtuelle Umgebung gefunden. Bitte './install.sh' ausführen."
fi
echo ""

# ── Aktuelle Einstellungen ───────────────────────────────────────────────────
echo -e "${BLUE}── Aktuelle Einstellungen ──────────────────────────────────${NC}"
if [ -f "$SETTINGS" ]; then
    LANG_SET=$(grep -o '"language"[[:space:]]*:[[:space:]]*"[^"]*"' "$SETTINGS" | sed -E 's/.*: *"(.*)"/\1/')
    THEME_SET=$(grep -o '"appearance_mode"[[:space:]]*:[[:space:]]*"[^"]*"' "$SETTINGS" | sed -E 's/.*: *"(.*)"/\1/')
    echo -e "   Sprache:          ${LANG_SET:-unbekannt}"
    echo -e "   Erscheinungsbild: ${THEME_SET:-unbekannt}"
    echo -e "   Ausgabeordner:    ${OUTPUT_DIR}"
else
    echo -e "   ${YELLOW}Noch keine Einstellungen gespeichert (erwartet unter: $SETTINGS)${NC}"
fi
echo ""

# ── Ausgabedateien ───────────────────────────────────────────────────────────
echo -e "${BLUE}── Ausgabedateien ──────────────────────────────────────────${NC}"
if [ -d "$OUTPUT_DIR" ]; then
    PDF_N=$(find "$OUTPUT_DIR" -maxdepth 1 -iname "*.pdf" -type f 2>/dev/null | wc -l)
    MD_N=$(find "$OUTPUT_DIR" -maxdepth 1 -iname "*.md" -type f 2>/dev/null | wc -l)
    TXT_N=$(find "$OUTPUT_DIR" -maxdepth 1 -iname "*.txt" -type f 2>/dev/null | wc -l)
    TOTAL_SIZE=$(find "$OUTPUT_DIR" -maxdepth 1 -iname "*.pdf" -type f -exec du -ch {} + 2>/dev/null | tail -1 | cut -f1)

    echo -e "   PDF-Dateien:      ${BOLD}${PDF_N}${NC}  (Gesamtgröße: ${TOTAL_SIZE:-0})"
    echo -e "   Markdown-Dateien: ${MD_N}"
    echo -e "   Text-Dateien:     ${TXT_N}"

    # Auffällig grosse Dateien (>50 MB) - z. B. Hinweis auf vergessene Komprimierung
    BIG_FILES=$(find "$OUTPUT_DIR" -maxdepth 1 -iname "*.pdf" -type f -size +50M 2>/dev/null)
    if [ -n "$BIG_FILES" ]; then
        echo -e "   ${YELLOW}⚠  Auffällig große PDFs (>50 MB):${NC}"
        echo "$BIG_FILES" | while read -r f; do echo "     $(basename "$f")"; done
    else
        echo -e "   ${GREEN}✓  Keine auffällig großen PDFs (>50 MB)${NC}"
    fi

    echo ""
    echo -e "${BLUE}── Zuletzt bearbeitete PDF-Dateien ─────────────────────────${NC}"
    if [ "$PDF_N" -gt 0 ] 2>/dev/null; then
        find "$OUTPUT_DIR" -maxdepth 1 -iname "*.pdf" -type f -printf '%T@ %p\n' 2>/dev/null | \
            sort -rn | head -5 | while read -r ts f; do
                printf "   %s  %s\n" "$(date -d @"${ts%.*}" '+%d.%m.%Y %H:%M' 2>/dev/null)" "$(basename "$f")"
            done
    else
        echo -e "   ${YELLOW}Keine PDF-Dateien im Ausgabeordner gefunden.${NC}"
    fi
else
    echo -e "   ${YELLOW}Ausgabeordner nicht gefunden: $OUTPUT_DIR${NC}"
fi

# ── Fehler-Log ───────────────────────────────────────────────────────────────
if [ -f "$LOG" ] && [ -s "$LOG" ]; then
    ERR_N=$(wc -l < "$LOG")
    echo ""
    echo -e "${BLUE}── Fehler-Log (letzte ${LOG_LINES} von ${ERR_N} Zeilen) ──────────────${NC}"
    tail -n "$LOG_LINES" "$LOG" | while read -r line; do echo "   $line"; done
    echo -e "   ${CYAN}Komplettes Log: $0 --full-log${NC}"
else
    echo ""
    echo -e "${GREEN}── Fehler-Log: leer, keine Fehler protokolliert ──${NC}"
fi

echo ""
echo -e "${BOLD}══════════════════════════════════════════════════════════${NC}"
echo -e "  Weitere Optionen: $0 --help"
echo ""

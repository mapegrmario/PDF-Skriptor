"""
reorder_ui.py
Werkzeug-Panel "Seiten neu ordnen": zeigt alle Seiten der aktiven
Datei als Vorschaukarten (reorder_card.py) und erlaubt, sie per
Drag & Drop in eine neue Reihenfolge zu bringen - analog zur
Miniaturansicht im Firefox-PDF-Betrachter. Beim Speichern wird eine
neue Datei mit der gewaehlten Reihenfolge angelegt.
"""

import os
import tkinter.filedialog as filedialog
from tkinter import messagebox
import customtkinter as ctk
from language import t
import settings as settings_store
import theme
from reorder_logic import render_thumbnails, apply_page_order
from reorder_card import ReorderCard
from file_list_sync import sync_active_file, load_result_file
from scroll_helpers import bind_mousewheel_scroll


class ReorderView(ctk.CTkFrame):
    """Ansicht zum visuellen Neuordnen der Seiten der aktiven Datei."""

    def __init__(self, master, file_manager) -> None:
        super().__init__(master, fg_color=theme.COLOR_BG)
        self._file_manager = file_manager
        self._active_path: str | None = None
        self._rows: list[dict] = []
        self._images: list = []
        self._dragging_card: ReorderCard | None = None
        self._build_ui()
        sync_active_file(self, self._file_manager, self._handle_active_changed)

    def _build_ui(self) -> None:
        title = ctk.CTkLabel(self, text=t("nav_reorder"), font=theme.font_title(), text_color=theme.COLOR_TEXT)
        title.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(theme.PADDING_LARGE, theme.PADDING_SMALL))

        self._active_file_label = ctk.CTkLabel(self, text="", font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED)
        self._active_file_label.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_SMALL))

        hint = ctk.CTkLabel(
            self, text=t("reorder_hint"), font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED,
            wraplength=300, justify="left",
        )
        hint.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        self._scroll_area = ctk.CTkScrollableFrame(self, fg_color=theme.COLOR_BG, corner_radius=0)
        self._scroll_area.pack(fill="both", expand=True, padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_SMALL))
        bind_mousewheel_scroll(self._scroll_area)

        button_row = ctk.CTkFrame(self, fg_color="transparent")
        button_row.pack(fill="x", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_LARGE))

        # QA-Fix (Runde 5, Live-Test "Seiten neu ordnen"): Erster Versuch war
        # eine explizite width= auf den Buttons - hat NICHT geholfen, weil bei
        # zwei nebeneinander gepackten fill="x"-Buttons in der nur 380px
        # breiten Seitenleiste (abzueglich Padding ca. 166px je Button) der
        # Packer die Breite ohnehin auf den verfuegbaren Platz zwingt, egal
        # welche width= angegeben ist. Laengere Beschriftungen (v. a. Deutsch:
        # "Neue Reihenfolge speichern") wurden dadurch links UND rechts
        # sichtbar abgeschnitten. Echter Fix: Buttons stapeln statt nebenein-
        # ander anordnen, damit jeder Button die volle Zeilenbreite bekommt -
        # robust unabhaengig von Sprache/Textlaenge, statt Breiten zu raten.
        reset_button = ctk.CTkButton(
            button_row, text=t("reorder_reset"), fg_color="transparent", border_width=1,
            border_color=theme.COLOR_BORDER, text_color=theme.COLOR_TEXT, hover_color=theme.COLOR_ACCENT_SOFT,
            corner_radius=theme.CORNER_RADIUS, command=self._handle_reset,
        )
        reset_button.pack(fill="x", pady=(0, 4))

        save_button = ctk.CTkButton(
            button_row, text=t("reorder_save"), fg_color=theme.COLOR_ACCENT, hover_color=theme.COLOR_ACCENT_HOVER,
            corner_radius=theme.CORNER_RADIUS, command=self._handle_save,
        )
        save_button.pack(fill="x")

    def _handle_active_changed(self, path: str | None) -> None:
        self._active_path = path
        if path:
            self._active_file_label.configure(text=f"📄 {os.path.basename(path)}")
            self._load_thumbnails(path)
        else:
            self._active_file_label.configure(text=t("no_active_file_hint"))
            self._clear_rows()

    def _clear_rows(self) -> None:
        for row in self._rows:
            row["card"].destroy()
        self._rows = []
        self._images = []

    def _load_thumbnails(self, path: str) -> None:
        self._clear_rows()
        for index, pil_image in enumerate(render_thumbnails(path)):
            ctk_image = ctk.CTkImage(light_image=pil_image, dark_image=pil_image, size=pil_image.size)
            self._images.append(ctk_image)
            card = ReorderCard(
                self._scroll_area, original_page_number=index + 1, thumbnail_image=ctk_image,
                on_drag_start=self._handle_drag_start, on_drag_motion=self._handle_drag_motion,
                on_drag_end=self._handle_drag_end,
            )
            card.pack(fill="x", pady=(0, theme.PADDING_SMALL))
            self._rows.append({"original_index": index, "card": card})

    def _handle_drag_start(self, card: ReorderCard) -> None:
        self._dragging_card = card
        card.set_dragging(True)

    def _handle_drag_motion(self, card: ReorderCard, pointer_y: int) -> None:
        if self._dragging_card is not card:
            return
        current_pos = self._index_of(card)
        if current_pos < 0:
            return
        for index, row in enumerate(self._rows):
            if row["card"] is card:
                continue
            other_card = row["card"]
            mid_y = other_card.winfo_rooty() + other_card.winfo_height() // 2
            if current_pos < index and pointer_y > mid_y:
                self._move_row(current_pos, index)
                break
            if current_pos > index and pointer_y < mid_y:
                self._move_row(current_pos, index)
                break

    def _handle_drag_end(self, card: ReorderCard) -> None:
        card.set_dragging(False)
        self._dragging_card = None

    def _index_of(self, card: ReorderCard) -> int:
        for index, row in enumerate(self._rows):
            if row["card"] is card:
                return index
        return -1

    def _move_row(self, from_index: int, to_index: int) -> None:
        row = self._rows.pop(from_index)
        self._rows.insert(to_index, row)
        self._repack_rows()

    def _repack_rows(self) -> None:
        for row in self._rows:
            row["card"].pack_forget()
        for row in self._rows:
            row["card"].pack(fill="x", pady=(0, theme.PADDING_SMALL))

    def _handle_reset(self) -> None:
        self._rows.sort(key=lambda row: row["original_index"])
        self._repack_rows()

    def _handle_save(self) -> None:
        if not self._active_path or not self._rows:
            messagebox.showinfo(t("app_title"), t("no_active_file_hint"))
            return

        settings = settings_store.load_settings()
        base_name = os.path.splitext(os.path.basename(self._active_path))[0]
        default_path = os.path.join(settings.get("output_dir", "~"), f"{base_name}_neu_sortiert.pdf")
        output_path = filedialog.asksaveasfilename(
            initialfile=os.path.basename(default_path),
            initialdir=os.path.dirname(default_path),
            defaultextension=".pdf",
            filetypes=[("PDF-Dateien", "*.pdf")],
        )
        if not output_path:
            return

        order = [row["original_index"] for row in self._rows]
        success = apply_page_order(self._active_path, output_path, order)
        if success:
            load_result_file(self._file_manager, output_path)
            messagebox.showinfo(t("app_title"), t("save_success"))
        else:
            messagebox.showerror(t("app_title"), t("error_generic"))

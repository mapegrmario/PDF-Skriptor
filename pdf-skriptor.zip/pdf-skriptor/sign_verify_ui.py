"""
sign_verify_ui.py
Unter-Werkzeug "Prüfen" des Digitale-Signatur-Moduls: waehlt eine
beliebige PDF-Datei aus und zeigt fuer jede enthaltene digitale
Signatur an, ob die Datei seither unveraendert ist und wer signiert
hat. Funktioniert auch fuer Dateien, die nicht mit PDF Skriptor
signiert wurden.
"""

import os
import tkinter.filedialog as filedialog
import customtkinter as ctk
from language import t
import theme
from pdf_sign_logic import verify_document


class SignVerifyTool(ctk.CTkFrame):
    """Prueft die digitalen Signaturen einer ausgewaehlten PDF-Datei."""

    def __init__(self, master, file_manager) -> None:
        super().__init__(master, fg_color="transparent")
        self._file_manager = file_manager
        self._build_ui()

    def _build_ui(self) -> None:
        hint = ctk.CTkLabel(
            self, text=t("sign_verify_hint"), font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED,
            wraplength=300, justify="left",
        )
        hint.pack(anchor="w", pady=(0, theme.PADDING_MEDIUM))

        choose_button = ctk.CTkButton(
            self, text=t("sign_verify_choose_file"), fg_color=theme.COLOR_ACCENT, hover_color=theme.COLOR_ACCENT_HOVER,
            corner_radius=theme.CORNER_RADIUS, command=self._handle_choose_and_verify,
        )
        choose_button.pack(fill="x", pady=(0, theme.PADDING_MEDIUM))

        self._results_container = ctk.CTkFrame(self, fg_color="transparent")
        self._results_container.pack(fill="both", expand=True)

    def _handle_choose_and_verify(self) -> None:
        path = filedialog.askopenfilename(filetypes=[("PDF-Dateien", "*.pdf")])
        if not path:
            return
        for child in self._results_container.winfo_children():
            child.destroy()

        file_label = ctk.CTkLabel(self._results_container, text=f"📄 {os.path.basename(path)}", font=theme.font_body(), text_color=theme.COLOR_TEXT)
        file_label.pack(anchor="w", pady=(0, theme.PADDING_SMALL))

        results = verify_document(path)
        if not results:
            ctk.CTkLabel(self._results_container, text=t("sign_verify_none_found"), font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED).pack(anchor="w")
            return

        for result in results:
            self._build_result_card(result)

    def _build_result_card(self, result: dict) -> None:
        card = ctk.CTkFrame(self._results_container, fg_color=theme.COLOR_BG_SECONDARY, corner_radius=theme.CORNER_RADIUS)
        card.pack(fill="x", pady=(0, theme.PADDING_SMALL))

        intact_color = theme.COLOR_SUCCESS if result["intact"] else theme.COLOR_ERROR
        intact_text = t("sign_verify_intact") if result["intact"] else t("sign_verify_tampered")
        ctk.CTkLabel(card, text=intact_text, font=theme.font_body(), text_color=intact_color, anchor="w").pack(anchor="w", padx=theme.PADDING_MEDIUM, pady=(theme.PADDING_SMALL, 2))

        signer = result.get("signer_cn") or "?"
        ctk.CTkLabel(card, text=t("sign_verify_signer").format(signer=signer), font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED, anchor="w", wraplength=280, justify="left").pack(anchor="w", padx=theme.PADDING_MEDIUM)

        trust_key = "sign_verify_not_trusted_hint" if not result["trusted"] else "sign_verify_trusted"
        ctk.CTkLabel(card, text=t(trust_key), font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED, anchor="w", wraplength=280, justify="left").pack(anchor="w", padx=theme.PADDING_MEDIUM, pady=(0, theme.PADDING_SMALL))

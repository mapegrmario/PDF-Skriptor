"""
settings_view.py
UI fuer den Einstellungen-Bereich: Sprache, Erscheinungsbild,
Standard-Ausgabeordner. Die eigentliche Speicherung uebernimmt settings.py.
"""

import tkinter.filedialog as filedialog
import customtkinter as ctk
from language import t, set_language, get_language
import settings as settings_store
import theme


class SettingsView(ctk.CTkFrame):
    """Ansicht zum Anpassen der Anwendungseinstellungen."""

    def __init__(self, master, on_language_change) -> None:
        super().__init__(master, fg_color=theme.COLOR_BG)
        self._on_language_change = on_language_change
        self._settings = settings_store.load_settings()
        self._output_dir_label: ctk.CTkLabel | None = None
        self._build_ui()

    def _build_ui(self) -> None:
        title = ctk.CTkLabel(self, text=t("settings_title"), font=theme.font_title(), text_color=theme.COLOR_TEXT)
        title.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(theme.PADDING_LARGE, theme.PADDING_MEDIUM))

        card = ctk.CTkFrame(self, fg_color=theme.COLOR_BG_SECONDARY, corner_radius=theme.CORNER_RADIUS)
        card.pack(fill="x", padx=theme.PADDING_LARGE, pady=theme.PADDING_SMALL)

        self._build_language_row(card)
        self._build_output_dir_row(card)

    def _build_language_row(self, card) -> None:
        row = ctk.CTkFrame(card, fg_color="transparent")
        row.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=theme.PADDING_MEDIUM)

        label = ctk.CTkLabel(row, text=t("settings_language"), font=theme.font_body(), text_color=theme.COLOR_TEXT)
        label.pack(side="left")

        selector = ctk.CTkSegmentedButton(
            row, values=["Deutsch", "English"], command=self._handle_language_selected,
        )
        selector.set("Deutsch" if get_language() == "de" else "English")
        selector.pack(side="right")

    def _build_output_dir_row(self, card) -> None:
        row = ctk.CTkFrame(card, fg_color="transparent")
        row.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=(0, theme.PADDING_MEDIUM))

        label = ctk.CTkLabel(row, text=t("settings_output_dir"), font=theme.font_body(), text_color=theme.COLOR_TEXT)
        label.pack(side="left")

        self._output_dir_label = ctk.CTkLabel(
            row, text=self._settings.get("output_dir", ""), font=theme.font_small(),
            text_color=theme.COLOR_TEXT_MUTED,
        )
        self._output_dir_label.pack(side="right", padx=(0, theme.PADDING_MEDIUM))

        choose_button = ctk.CTkButton(
            row, text="…", width=36, fg_color=theme.COLOR_ACCENT,
            hover_color=theme.COLOR_ACCENT_HOVER, command=self._choose_output_dir,
        )
        choose_button.pack(side="right")

    def _handle_language_selected(self, value: str) -> None:
        lang_code = "de" if value == "Deutsch" else "en"
        set_language(lang_code)
        settings_store.update_setting("language", lang_code)
        self._on_language_change()

    def _choose_output_dir(self) -> None:
        chosen = filedialog.askdirectory(initialdir=self._settings.get("output_dir", "~"))
        if chosen and self._output_dir_label is not None:
            self._output_dir_label.configure(text=chosen)
            settings_store.update_setting("output_dir", chosen)
            self._settings["output_dir"] = chosen

"""
logger_setup.py
Richtet zentrales Logging in fehler.log ein. Wird von allen Modulen
genutzt, um Fehler und wichtige Ereignisse nachvollziehbar zu machen.
"""

import logging
import os

LOG_FILENAME = "fehler.log"


def get_log_path() -> str:
    base_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_dir, LOG_FILENAME)


def setup_logger() -> logging.Logger:
    """Erstellt und konfiguriert den zentralen Logger der Anwendung."""
    logger = logging.getLogger("pdf_skriptor")
    logger.setLevel(logging.DEBUG)

    if logger.handlers:
        return logger

    file_handler = logging.FileHandler(get_log_path(), encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    return logger


def log_exception(context: str, exc: Exception) -> None:
    """Bequeme Hilfsfunktion, um Ausnahmen mit Kontext zu protokollieren."""
    logger = logging.getLogger("pdf_skriptor")
    logger.error("%s: %s", context, exc, exc_info=True)

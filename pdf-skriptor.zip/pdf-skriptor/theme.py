"""
theme.py
Zentrale Farb- und Stil-Definitionen fuer PDF Skriptor.
Helles Design ist Standard. Alle Module greifen auf diese Konstanten zu,
damit das Erscheinungsbild konsistent bleibt.
"""

import customtkinter as ctk

# Basis-Farbpalette (helles Theme als Default)
COLOR_BG = "#F5F6FA"
COLOR_BG_SECONDARY = "#FFFFFF"
COLOR_SIDEBAR = "#EDEFF5"
COLOR_ACCENT = "#2F6FED"
COLOR_ACCENT_HOVER = "#2559C0"
COLOR_ACCENT_SOFT = "#E4ECFF"
COLOR_TEXT = "#1B1E28"
COLOR_TEXT_MUTED = "#6B7080"
COLOR_SUCCESS = "#2FAE60"
COLOR_WARNING = "#E0A420"
COLOR_ERROR = "#E0453F"
COLOR_BORDER = "#DCDFE8"

# Typografie
FONT_FAMILY = "Roboto"
FONT_SIZE_TITLE = 20
FONT_SIZE_HEADING = 16
FONT_SIZE_BODY = 13
FONT_SIZE_SMALL = 11

# Abstaende / Radien fuer konsistentes Spacing
PADDING_SMALL = 6
PADDING_MEDIUM = 12
PADDING_LARGE = 20
CORNER_RADIUS = 10

# Micro-Interaction Timing (in ms), fuer sanfte Uebergaenge
HOVER_ANIMATION_MS = 120
FADE_ANIMATION_MS = 180


def apply_base_theme() -> None:
    """Setzt das globale CustomTkinter Erscheinungsbild (helles Design)."""
    ctk.set_appearance_mode("light")
    ctk.set_default_color_theme("blue")


def font_title() -> ctk.CTkFont:
    return ctk.CTkFont(family=FONT_FAMILY, size=FONT_SIZE_TITLE, weight="bold")


def font_heading() -> ctk.CTkFont:
    return ctk.CTkFont(family=FONT_FAMILY, size=FONT_SIZE_HEADING, weight="bold")


def font_body() -> ctk.CTkFont:
    return ctk.CTkFont(family=FONT_FAMILY, size=FONT_SIZE_BODY)


def font_small() -> ctk.CTkFont:
    return ctk.CTkFont(family=FONT_FAMILY, size=FONT_SIZE_SMALL)

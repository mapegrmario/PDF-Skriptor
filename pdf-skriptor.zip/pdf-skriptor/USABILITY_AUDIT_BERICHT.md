# PDF Skriptor – Usability-, Workflow- und QA-Bericht

**Rolle:** Senior UX/UI Designer, Usability Engineer, QA-Tester
**Prüfobjekt:** PDF Skriptor (Python/CustomTkinter, 18 Module)
**Methodik:** Installation und Bedienung in isolierter Linux-Umgebung (Xvfb +
simulierte Maus-/Tastatursteuerung, echte Testdateien), ergänzt um
Backend-Logiktests. Dieser Bericht konsolidiert die über mehrere Sitzungen
gesammelten Befunde nach den vier ursprünglich angefragten Dimensionen und
wurde in dieser Sitzung unabhängig nachverifiziert (siehe letzter Abschnitt).

**Gesamtstatus:** Alle unten aufgeführten Befunde sind behoben (5
Umsetzungsrunden, siehe `AENDERUNGEN.md`). In Runde 5 wurden bei den zuvor
noch offenen Live-Tests („Formulare ausfüllen", „Seiten neu ordnen") zwei
weitere, echte Fehler gefunden und direkt behoben; Redaction wurde geprüft
und bestätigt fehlerfrei.

---

## 1. Ersteindruck & Onboarding (First-Time User Experience)

| # | Bereich | Befund | Status / Lösung |
|---|---------|--------|------------------|
| 1.1 | Werkbank (Startzustand) | Leerer Bereich vor dem Laden einer Datei zeigte nur eine grosse, ungenutzte graue Fläche (Karten-Container füllte die reservierte Höhe nicht). | ✅ Behoben – echte Drop-Zone mit Icon + Text „PDF-Dateien hierher ziehen" (`workbench_view.py`), aktualisiert sich beim Sprachwechsel mit. |
| 1.2 | Programmstart | Blockierender Warnhinweis-Dialog (fehlende OCR-Systemtools) konnte vor der eigentlichen Oberfläche erscheinen. | ✅ Behoben – kein Dialog mehr vor dem ersten Bildschirm; fehlende Abhängigkeiten werden geloggt und dezent im „Über dieses Programm"-Tab angezeigt, betroffene Werkzeuge (OCR, Komprimieren) zeigen ihren Hinweis weiterhin direkt inline (`main.py`, `about_view.py`). |
| 1.3 | Kachelmenü / Bereich „Weitere" | Einstellungen/Hilfe/Über lagen so weit unten im Kachel-Scrollbereich, dass ca. 25 Mausrad-Bewegungen nötig waren, um sie zu erreichen. | ✅ Behoben – als drei eigene Icons direkt neben dem „☰ Menü"-Knopf platziert, aus der Scroll-Liste entfernt (`app_window.py`, `home_view.py`). |

**Zusätzlich verifiziert:** Neue Nutzer werden direkt auf der Startseite mit
Begrüssungstext und explizitem Hinweis „Ziehe oben in der Werkbank eine oder
mehrere PDF-Dateien hinein oder klicke dort auf 'Dateien auswählen'"
angeleitet – der Einstieg ist ohne Vorwissen verständlich.

---

## 2. Workflow- & Logik-Analyse (Kernfunktionen)

### 2.1 „Text bearbeiten"
**Befund:** Existierte nirgends als eigenes Werkzeug; das Anmerkungen-Modul
bot nur Freihand/Hervorheben/Stempel/Unterschrift/Radierer – für neue Nutzer
ohne Hinweis schwer zu erahnen, dass echte In-Place-Textbearbeitung bewusst
nicht vorgesehen ist (bestehende PDF-Inhalte layoutgetreu zu verändern, ist
technisch nur mit erheblichem Aufwand und Risiko möglich).
**Lösung:** Neues Werkzeug „Text platzieren" im Anmerkungen-Modul (Klick ins
Dokument → Dialog für Text/Schriftgrösse → Platzierung als echte
FreeText-Anmerkung). In Runde 3 verfeinert: Schriftgrösse wird live als Zahl
angezeigt, platzierte Textfelder lassen sich per Klick+Ziehen nachträglich
verschieben. ✅

### 2.2 „Zusammenfügen"
**Befund:** Keine Möglichkeit, die Dateireihenfolge direkt zu ändern – dafür
war ein Umweg über die Werkbank (Dateien entfernen und neu/anders laden)
nötig.
**Lösung:** Reihenfolge lässt sich jetzt per Drag & Drop direkt im
Zusammenfügen-Werkzeug ändern (`organize_merge_ui.py`, `merge_file_card.py`),
über die gemeinsame Dateiliste (`file_manager.reorder_files()`) konsistent
mit der Werkbank-Chip-Reihenfolge. ✅

### 2.3 „Seiten löschen"
**Befund:** Funktionierte nur über Texteingabe („1,3,5-7"), obwohl die App an
anderer Stelle bereits Seiten-Miniaturansichten anzeigt; zudem kein
Bestätigungsdialog vor dem eigentlichen Löschen.
**Lösung:** Visuelle Seitenauswahl per anklickbaren Miniaturen
(`delete_page_card.py`, `organize_delete_ui.py`) plus Bestätigungsdialog vor
dem Löschen. Getrennt davon existiert weiterhin das dedizierte Modul „Seiten
neu ordnen" für Drag-&-Drop-Umsortierung (bewusst eigenständig, da andere
Zielsetzung). ✅

### 2.4 „Formulare ausfüllen"
**Befund:** Interne, teils kryptische Feldnamen (aus dem PDF-Generator)
wurden immer als Beschriftung angezeigt, auch wenn das PDF selbst eine
sprechendere Bezeichnung mitliefert.
**Lösung:** Das `/TU`-Tooltip-/Alternativname-Attribut wird jetzt als
Feldbeschriftung genutzt, sofern im PDF vorhanden, mit Fallback auf den
technischen Namen (`forms_logic.py`). Klickpfad selbst ist bereits kurz:
Datei aktivieren → „Formulare" → Feld ausfüllen → „Speichern unter" (identisch
zu allen anderen Werkzeugen). ✅

**Nachtrag Runde 5 (live durchgeklickt):** Feldbeschriftungen und Klickpfad
wie beschrieben bestätigt. Dabei einen zweiten, echten Fehler gefunden:
Speichern stürzte mit `AttributeError: 'dict' object has no attribute
'get_object'` ab, sobald die PDF kein eigenes `/DR` (Default Resources) am
AcroForm besitzt – ein Grenzfall von pypdfs `update_page_form_field_values()`.
Behoben in `forms_logic.py` (`_ensure_default_resources()`); mit isoliertem
Python-Repro und erneut live über die App verifiziert. ✅

### 2.5 „Seiten neu ordnen" (Nachtrag Runde 5, live durchgeklickt)
Nicht Teil der ursprünglichen vier Kern-Workflows, aber auf Wunsch
nachgetestet. Der eigentliche Drag-&-Drop-Umsortiervorgang funktionierte
einwandfrei – neue Reihenfolge im UI und in der tatsächlich gespeicherten
Datei stimmen exakt überein. **Gefunden:** Der Button „Neue Reihenfolge
speichern" zeigte seinen Text links und rechts abgeschnitten (zwei
nebeneinander gepackte Buttons zu schmal für die deutsche Beschriftung in
der 380px-Seitenleiste). Erster Fix-Versuch (feste Breite) half nicht;
zweiter Versuch (Buttons untereinander statt nebeneinander) behebt es
robust unabhängig von Sprache/Textlänge (`reorder_ui.py`). ✅

### Weitere Konsistenzpunkte im Workflow
| Bereich | Befund | Status / Lösung |
|---------|--------|------------------|
| Fenster schliessen | Kein Warnhinweis bei ungesicherten Änderungen – betrifft insbesondere Anmerkungen/Redaction, die (anders als alle anderen Werkzeuge) erst per Extra-Klick auf „Speichern" persistiert werden. | ✅ Behoben – `WM_DELETE_WINDOW`-Handler prüft `has_unsaved_changes()` und fragt vor dem Schliessen nach (`app_window.py`, ergänzt in `annotate_ui.py`, `redact_ui.py`, `redact_manual_ui.py`). |

---

## 3. Effizienz & Klick-Wege (Clicks-to-Target)

| Bereich | Befund | Status / Lösung |
|---------|--------|------------------|
| Nach jeder Bearbeitung | Ergebnis (Drehen, Löschen, Zusammenfügen, Kopf-/Fusszeile, Wasserzeichen, PDF/A, Lesezeichen, Formulare, Anmerkungen, Signatur, OCR, Komprimieren u. a.) musste erst gespeichert und die neue Datei danach manuell über „Dateien auswählen" erneut geladen werden, um es zu sehen. | ✅ Behoben – `load_result_file()` (`file_list_sync.py`) lädt die frisch gespeicherte Datei automatisch in die Werkbank und aktiviert sie; Dokumentenansicht zeigt das Ergebnis sofort. Bewusste Ausnahme: Verschlüsseln (Ergebnis ist passwortgeschützt, automatisches Öffnen würde nur einen Fehler zeigen). |
| Einstellungen/Hilfe/Über | Siehe 1.3 – ca. 25 Mausrad-Bewegungen nötig. | ✅ Behoben, siehe oben. |
| Zusammenfügen-Reihenfolge | Siehe 2.2 – Umweg über die Werkbank nötig. | ✅ Behoben, siehe oben. |
| Rückkehr zur Übersicht | Aus jedem Werkzeug heraus. | Bereits vorhanden: „☰ Menü"-Knopf führt aus jedem Werkzeug direkt zur Kachel-Übersicht zurück. |

---

## 4. Fehleranfälligkeit & Konsistenz

| # | Bereich | Befund | Status / Lösung |
|---|---------|--------|------------------|
| – | Sprachumschaltung (Übersetzung) | **Grösster Einzelbefund:** Nach Umschalten auf Englisch übersetzten sich Titel/Hinweistexte korrekt, aber alle 21 Kachel-Beschreibungen blieben deutsch. Zusätzlich blieben u. a. Unterreiter bei „Organisieren", das komplette Redaction-Modul, die Ausrichtungs-Auswahl bei Kopf-/Fusszeile und die Qualitätsstufen der Pipeline fest auf Deutsch – ca. die Hälfte der Module betroffen. | ✅ Behoben – rund 90 neue Übersetzungsschlüssel in `language.py`; betroffene Dateien einzeln nachgezogen (`home_view.py`, `organize_ui.py`, `redact_ui.py`, `header_footer_ui.py`/`_logic.py`, `convert_ui.py`, `pipeline_*`, `compress_ui.py`, `forms_ui.py`, `metadata_ui.py`, `compare_ui.py`, `ocr_ui.py`, u. a.). In dieser Sitzung erneut live auf Deutsch **und** Englisch geprüft (Screenshot-Vergleich) – Übersetzung vollständig. |
| 4.2 | Kachelmenü nach Sprachwechsel | Reproduzierbarer Bug: Nach Sprachwechsel + Rückkehr zur Startseite sprang das Kachelmenü ganz nach unten und liess sich danach gar nicht mehr scrollen (auch nach 30 Mausrad-Bewegungen). Ursache: `<Enter>`/`<Leave>` feuern nicht zuverlässig, wenn eine Ansicht durch Sprachwechsel zerstört/neu aufgebaut wird statt durch Mausbewegung. | ✅ Behoben – zusätzliche Absicherung über `<Map>`/`<Unmap>`/`<Destroy>` in `scroll_helpers.py`. Eine dabei entstandene Regression (Scrollen blockierte danach *grundsätzlich*, weil `canvas.yview()` bei `CTkScrollableFrame` dauerhaft `(0.0, 1.0)` statt des echten Scroll-Zustands liefert) wurde ebenfalls erkannt und durch Rückbau der fehleranfälligen Rand-Vorabprüfung korrigiert. |
| 4.4 | Fenster schliessen | Siehe Abschnitt 2, Tabelle „Weitere Konsistenzpunkte". | ✅ Behoben. |

**Verhalten wie von Standard-Tools gewohnt:** Speichern-unter-Dialoge, Datei-
Drag-&-Drop und Tastaturkürzel (Zoom, Suche) folgen den unter Linux üblichen
Konventionen; kritische Aktionen (Löschen, Schliessen mit ungesicherten
Änderungen) sind jetzt jeweils mit Bestätigung abgesichert.

---

## Nebenbefund aus der Fehlerbehebung (nicht ursprünglich Teil des Audits)

Beim Verschieben platzierter Textfelder wurde ein echter, subtiler
PyMuPDF-Fallstrick gefunden: Anmerkungsobjekte halten nur eine **schwache**
Referenz auf ihre Seite. Die ursprüngliche Suchfunktion gab die gefundene
Anmerkung zurück, ohne dass die zugehörige Seite am Leben gehalten wurde –
jeder weitere Zugriff (z. B. beim Ziehen) konnte zum Absturz führen.
`find_text_annot_at_point()` gibt die Seite jetzt zusätzlich zurück und hält
sie als Instanzattribut während des gesamten Ziehvorgangs. Mit eigenem
Testskript sowie live in der GUI verifiziert. ✅

---

## Was in dieser Sitzung unabhängig nachverifiziert wurde

Diese Prüfung fand in einer frischen, isolierten Umgebung statt (separat vom
Verlauf, in dem die obigen Befunde ursprünglich gefunden und behoben wurden):

- `py_compile` über alle 75 Python-Dateien – fehlerfrei.
- App per eigener virtueller Umgebung (`--system-site-packages` wegen
  `python3-tk`) und Xvfb tatsächlich gestartet (nicht nur Code gelesen).
- Startbildschirm **auf Deutsch und auf Englisch** per Screenshot geprüft:
  kein Blockier-Dialog, echte Drop-Zone statt grauer Fläche, Einstellungen/
  Hilfe/Über als Icons, Kacheln alphabetisch sortiert
  („Anmerkungen/Annotations, Digitale Signatur/Digital Signature,
  Formulare/Forms …"), **alle** Kachel-Beschreibungen in beiden Sprachen
  vollständig übersetzt – damit sind die zwei ursprünglichen Hauptbefunde
  in beiden Sprachen visuell bestätigt.
- Im Code nachvollzogen: Zentrierungs-Logik (`_update_page_centering()`),
  Sortierfunktion (`sorted(tools, key=lambda item: t(item[2]))`),
  Signatur-Overlay-Mechanismus (`_pending_signatures` /
  `bake_pending_signatures()`), Löschen-Bestätigungsdialog
  (`messagebox.askyesno` in `organize_delete_ui.py`), Zusammenfügen-Drag-
  Reorder, `/TU`-Fallback in `forms_logic.py`, Schliessen-Schutz in
  `app_window.py`.
- `analyse.md` war seit dem letzten dort dokumentierten Stand (Nachtrag -27)
  nicht um diesen Audit-Zyklus ergänzt – als Nachtrag -28 nachgetragen, damit
  das fortlaufende Analyse-Log wieder vollständig ist.

**In dieser Sitzung noch nicht mit echter simulierter Maussteuerung
durchgeklickt** (nur Code-Ebene verifiziert): „Formulare ausfüllen",
„Seiten neu ordnen" End-to-End sowie Redaction. Als Runde 5 nachgeholt,
siehe unten.

Bis zu diesem Punkt wurden **keine neuen Fehler** gefunden.

---

## Runde 5 – die drei offenen Punkte live durchgeklickt

Mit Xvfb + `xdotool` (echte Maus-/Tastatursteuerung, kein Code-Lesen) und
drei selbst erzeugten Testdateien (Formular mit/ohne `/TU`-Attribut,
5-seitiges Dokument, Text mit eindeutigem Suchbegriff) nachgeholt.

**Formulare ausfüllen**: Feldbeschriftungen und Klickpfad wie in 2.4
beschrieben bestätigt. Dabei einen echten, reproduzierbaren Absturz
gefunden und behoben, siehe 2.4 – ausgelöst durch pypdf bei PDFs ohne
eigenes `/DR`.

**Seiten neu ordnen**: Drag-&-Drop-Umsortierung fehlerfrei (UI und
gespeicherte Datei stimmen überein). Dabei einen abgeschnittenen
Button-Text gefunden und behoben, siehe 2.5.

**Redaction** (nicht Teil der ursprünglichen vier Kern-Workflows, auf
Wunsch zusätzlich geprüft): Beide Modi getestet – Suche & Schwärzen sowie
Manuell markieren. Besonders wichtig war hier, die Werbeaussage der Kachel
("Entfernt Inhalte dauerhaft aus dem Dokument – kein reiner schwarzer
Balken") nicht nur optisch, sondern am tatsächlichen Dateiinhalt zu prüfen:
Per Textextraktion (`page.get_text()`) bestätigt, dass der geschwärzte
Bereich in beiden Modi wirklich nicht mehr auslesbar ist – nicht nur von
einem schwarzen Balken überdeckt –, während unbeteiligter Text exakt
erhalten bleibt. Keine funktionalen Fehler gefunden. Einzige Korrektur:
„1 Bereiche vorgemerkt" war falsch dekliniert (richtig: „1 Bereich") –
`redact_manual_ui.py` + `language.py`.

**Randnotiz zur eigenen Testmethodik:** Ein Teil der Testdurchläufe in
dieser Runde scheiterte zunächst daran, dass die Wartezeiten im eigenen
Testskript zwischen App-Start und erstem Klick zu knapp bemessen waren
(Werkbank zeigte dann "keine Datei ausgewählt") – mit großzügigeren
Wartezeiten reproduzierte sich das nicht mehr. Kein Befund an der App
selbst, der Vollständigkeit halber hier trotzdem notiert.

**Gesamtfazit nach Runde 5:** Zwei echte, reproduzierbare Fehler gefunden
und behoben (Formular-Speichern-Absturz, abgeschnittener Button-Text),
eine kleine Grammatik-Korrektur, keine offenen Punkte mehr aus dem
ursprünglichen Auftrag.

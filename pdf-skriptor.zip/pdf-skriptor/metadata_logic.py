"""
metadata_logic.py
Liest und schreibt PDF-Metadaten (Titel, Autor, Betreff, Stichwoerter)
einzeln oder als Batch-Operation ueber mehrere Dateien hinweg.
"""

from pypdf import PdfReader, PdfWriter
from logger_setup import log_exception

METADATA_FIELDS = ["/Title", "/Author", "/Subject", "/Keywords"]


def read_metadata(path: str) -> dict:
    """Liest die Metadaten einer PDF-Datei aus."""
    try:
        reader = PdfReader(path)
        meta = reader.metadata or {}
        return {field: meta.get(field, "") or "" for field in METADATA_FIELDS}
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Lesen der Metadaten", exc)
        return {field: "" for field in METADATA_FIELDS}


def write_metadata(path: str, output_path: str, values: dict) -> bool:
    """Schreibt neue Metadaten in eine Kopie der PDF-Datei."""
    try:
        reader = PdfReader(path)
        writer = PdfWriter()
        for page in reader.pages:
            writer.add_page(page)
        existing = dict(reader.metadata or {})
        existing.update({field: values.get(field, "") for field in METADATA_FIELDS})
        writer.add_metadata(existing)
        with open(output_path, "wb") as file:
            writer.write(file)
        return True
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Schreiben der Metadaten", exc)
        return False


def write_metadata_batch(paths: list[str], values: dict) -> int:
    """Schreibt dieselben Metadaten-Werte in mehrere Dateien (ueberschreibt Original)."""
    success_count = 0
    for path in paths:
        if write_metadata(path, path, values):
            success_count += 1
    return success_count

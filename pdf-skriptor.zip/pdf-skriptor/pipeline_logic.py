"""
pipeline_logic.py
Fuehrt eine Kette von Werkzeugen (Schritte) auf allen PDF-Dateien eines
Ordners aus - das zentrale Alleinstellungsmerkmal fuer wiederkehrende
Buero-Ablaeufe (z. B. "alle PDFs: komprimieren -> Passwort setzen").
"""

import os
import glob
from language import t
from logger_setup import log_exception
from organize_logic import rotate_pages
from compress_logic import compress_pdf
from security_logic import encrypt_pdf
from metadata_logic import write_metadata

# QA-Fix: Anzeigetexte laufen jetzt durch t() (siehe pipeline_step_row.py) -
# als Funktion statt Modul-Konstante, damit ein spaeterer Sprachwechsel
# (der alle Ansichten neu aufbaut) auch hier aktuelle Texte liefert.
def get_step_types() -> dict:
    return {
        "rotate": t("pipeline_step_rotate"),
        "compress": t("pipeline_step_compress"),
        "encrypt": t("pipeline_step_encrypt"),
        "metadata": t("pipeline_step_metadata"),
    }


def find_pdfs_in_folder(folder: str) -> list[str]:
    return sorted(glob.glob(os.path.join(folder, "*.pdf")))


def _run_step(step: dict, current_path: str, work_dir: str, index: int) -> tuple[bool, str]:
    """Fuehrt einen einzelnen Pipeline-Schritt aus und liefert den neuen Pfad."""
    step_type = step["type"]
    params = step.get("params", {})
    temp_output = os.path.join(work_dir, f"schritt_{index}_{os.path.basename(current_path)}")

    try:
        if step_type == "rotate":
            ok = rotate_pages(current_path, temp_output, params.get("degrees", 90))
        elif step_type == "compress":
            ok = compress_pdf(current_path, temp_output, params.get("quality", "mittel"))
        elif step_type == "encrypt":
            ok = encrypt_pdf(current_path, temp_output, params.get("password", ""), params.get("password", ""))
        elif step_type == "metadata":
            ok = write_metadata(current_path, temp_output, params.get("values", {}))
        else:
            return False, temp_output
        return ok, temp_output
    except Exception as exc:  # noqa: BLE001
        log_exception(f"Fehler in Pipeline-Schritt {step_type}", exc)
        return False, temp_output


def run_pipeline(input_folder: str, output_folder: str, steps: list[dict], work_dir: str) -> dict:
    """Wendet alle Schritte in Reihenfolge auf jede PDF-Datei im Ordner an."""
    files = find_pdfs_in_folder(input_folder)
    results = {"total": len(files), "success": 0, "failed": [], "output_files": []}

    os.makedirs(output_folder, exist_ok=True)

    for source_path in files:
        current_path = source_path
        step_ok = True
        for index, step in enumerate(steps):
            ok, new_path = _run_step(step, current_path, work_dir, index)
            if not ok:
                step_ok = False
                break
            current_path = new_path

        if step_ok:
            final_output = os.path.join(output_folder, os.path.basename(source_path))
            try:
                with open(current_path, "rb") as src, open(final_output, "wb") as dst:
                    dst.write(src.read())
                results["success"] += 1
                results["output_files"].append(final_output)
            except OSError as exc:
                log_exception("Fehler beim Kopieren des Pipeline-Ergebnisses", exc)
                results["failed"].append(os.path.basename(source_path))
        else:
            results["failed"].append(os.path.basename(source_path))

    return results

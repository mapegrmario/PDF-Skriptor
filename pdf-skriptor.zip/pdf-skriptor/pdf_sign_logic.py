"""
pdf_sign_logic.py
Signiert eine PDF-Datei kryptographisch (PKCS#7/CMS) mit einem
PKCS#12-Zertifikat via pyHanko und prueft vorhandene Signaturen auf
Unversehrtheit. Rein offline - keine Zeitstempel-/Sperrlisten-Abfragen
im Internet, damit die Anwendung ohne Netzwerkzugriff funktioniert und
keine Daten nach aussen gibt.
"""

import logging
from pyhanko.sign import signers
from pyhanko.pdf_utils.incremental_writer import IncrementalPdfFileWriter
from pyhanko.pdf_utils.reader import PdfFileReader
from pyhanko.sign.validation import validate_pdf_signature
from logger_setup import log_exception

# pyHanko protokolliert das erwartete "kein Vertrauensanker gefunden"
# bei selbstsignierten Zertifikaten sehr ausfuehrlich (inkl. Traceback);
# das ist kein Fehler unserer Anwendung, daher hier stummgeschaltet.
logging.getLogger("pyhanko_certvalidator").setLevel(logging.CRITICAL)
logging.getLogger("pyhanko").setLevel(logging.CRITICAL)


def sign_document(input_path: str, output_path: str, certificate_path: str, password: str, reason: str = "", location: str = "") -> bool:
    try:
        signer = signers.SimpleSigner.load_pkcs12(pfx_file=certificate_path, passphrase=password.encode("utf-8"))
        if signer is None:
            log_exception("Signatur fehlgeschlagen", Exception("Zertifikat oder Passwort ungültig"))
            return False
        with open(input_path, "rb") as infile:
            writer = IncrementalPdfFileWriter(infile)
            metadata = signers.PdfSignatureMetadata(field_name="Signatur1", reason=reason or None, location=location or None)
            pdf_signer = signers.PdfSigner(metadata, signer=signer)
            with open(output_path, "wb") as outfile:
                pdf_signer.sign_pdf(writer, output=outfile)
        return True
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim digitalen Signieren", exc)
        return False


def verify_document(path: str) -> list:
    """Liefert je gefundener Signatur ein Ergebnis-Dict: field_name,
    intact (Datei seit der Signatur unveraendert), valid
    (kryptographisch korrekt), trusted (CA-Kette anerkannt - bei
    selbstsignierten Zertifikaten immer False, das ist normal und kein
    Fehler), signer_cn (Name aus dem Zertifikat)."""
    results = []
    try:
        with open(path, "rb") as file:
            reader = PdfFileReader(file)
            for sig in reader.embedded_signatures:
                status = validate_pdf_signature(sig)
                signer_cn = None
                try:
                    signer_cn = status.signing_cert.subject.human_friendly
                except Exception:  # noqa: BLE001
                    pass
                results.append({
                    "field_name": sig.field_name, "intact": status.intact,
                    "valid": status.valid, "trusted": status.trusted, "signer_cn": signer_cn,
                })
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler bei der Signaturprüfung", exc)
    return results

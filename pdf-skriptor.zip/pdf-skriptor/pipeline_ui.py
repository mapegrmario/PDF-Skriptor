"""
pipeline_ui.py
UI fuer den Batch-Pipeline-Builder: Eingabe-/Ausgabeordner waehlen,
Werkzeugkette zusammenstellen und auf alle PDFs im Ordner anwenden.
"""

import os
import tempfile
import threading
import tkinter.filedialog as filedialog
from tkinter import messagebox
import customtkinter as ctk
from language import t
import settings as settings_store
import theme
from scroll_helpers import bind_mousewheel_scroll
from pipeline_logic import run_pipeline
from pipeline_step_row import PipelineStepRow


class PipelineView(ctk.CTkFrame):
    """Ansicht zum Erstellen und Ausführen einer Batch-Werkzeugkette."""

    def __init__(self, master, file_manager) -> None:
        super().__init__(master, fg_color=theme.COLOR_BG)
        self._file_manager = file_manager
        self._input_folder: str | None = None
        self._output_folder: str | None = None
        self._step_rows: list[PipelineStepRow] = []
        self._steps_container: ctk.CTkFrame | None = None
        self._build_ui()

    def _build_ui(self) -> None:
        title = ctk.CTkLabel(self, text=t("pipeline_title"), font=theme.font_title(), text_color=theme.COLOR_TEXT)
        title.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(theme.PADDING_LARGE, theme.PADDING_SMALL))

        subtitle = ctk.CTkLabel(
            self, text=t("pipeline_subtitle"),
            font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED,
        )
        subtitle.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        self._build_folder_rows()

        self._steps_container = ctk.CTkScrollableFrame(self, fg_color=theme.COLOR_BG_SECONDARY, corner_radius=theme.CORNER_RADIUS)
        self._steps_container.pack(fill="both", expand=True, padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_SMALL))
        bind_mousewheel_scroll(self._steps_container)

        add_step_button = ctk.CTkButton(
            self, text=t("pipeline_add_step"), fg_color="transparent", border_width=1, border_color=theme.COLOR_BORDER,
            text_color=theme.COLOR_TEXT, hover_color=theme.COLOR_ACCENT_SOFT, corner_radius=theme.CORNER_RADIUS,
            command=self._add_step,
        )
        add_step_button.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        self._status_label = ctk.CTkLabel(self, text="", font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED)
        self._status_label.pack(anchor="w", padx=theme.PADDING_LARGE)

        run_button = ctk.CTkButton(
            self, text=t("pipeline_run"), fg_color=theme.COLOR_ACCENT, hover_color=theme.COLOR_ACCENT_HOVER,
            corner_radius=theme.CORNER_RADIUS, command=self._handle_run,
        )
        run_button.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(theme.PADDING_SMALL, theme.PADDING_LARGE))

        self._add_step()

    def _build_folder_rows(self) -> None:
        row = ctk.CTkFrame(self, fg_color="transparent")
        row.pack(fill="x", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_SMALL))

        in_button = ctk.CTkButton(row, text=t("pipeline_choose_input"), command=self._choose_input_folder)
        in_button.pack(anchor="w")
        self._input_label = ctk.CTkLabel(
            row, text=t("pipeline_no_folder_chosen"), font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED,
            wraplength=300, justify="left",
        )
        self._input_label.pack(anchor="w", pady=(2, 0))

        row2 = ctk.CTkFrame(self, fg_color="transparent")
        row2.pack(fill="x", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        out_button = ctk.CTkButton(row2, text=t("pipeline_choose_output"), command=self._choose_output_folder)
        out_button.pack(anchor="w")
        self._output_label = ctk.CTkLabel(
            row2, text=t("pipeline_no_folder_chosen"), font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED,
            wraplength=300, justify="left",
        )
        self._output_label.pack(anchor="w", pady=(2, 0))

    def _choose_input_folder(self) -> None:
        settings = settings_store.load_settings()
        chosen = filedialog.askdirectory(initialdir=settings.get("output_dir", "~"))
        if chosen:
            self._input_folder = chosen
            self._input_label.configure(text=chosen)

    def _choose_output_folder(self) -> None:
        settings = settings_store.load_settings()
        chosen = filedialog.askdirectory(initialdir=settings.get("output_dir", "~"))
        if chosen:
            self._output_folder = chosen
            self._output_label.configure(text=chosen)

    def _add_step(self) -> None:
        row = PipelineStepRow(self._steps_container, on_remove=self._remove_step)
        row.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=theme.PADDING_SMALL)
        self._step_rows.append(row)

    def _remove_step(self, row: PipelineStepRow) -> None:
        if row in self._step_rows:
            self._step_rows.remove(row)
        row.destroy()

    def _handle_run(self) -> None:
        if not self._input_folder or not self._output_folder:
            messagebox.showinfo(t("app_title"), t("pipeline_need_folders"))
            return
        if not self._step_rows:
            messagebox.showinfo(t("app_title"), t("pipeline_need_step"))
            return

        steps = [row.get_step_config() for row in self._step_rows]
        self._status_label.configure(text=t("pipeline_running"))

        thread = threading.Thread(target=self._run_in_background, args=(steps,), daemon=True)
        thread.start()

    def _run_in_background(self, steps: list[dict]) -> None:
        with tempfile.TemporaryDirectory() as work_dir:
            results = run_pipeline(self._input_folder, self._output_folder, steps, work_dir)
        self.after(0, lambda: self._on_finished(results))

    def _on_finished(self, results: dict) -> None:
        text = t("pipeline_result").format(success=results["success"], total=results["total"])
        if results["failed"]:
            text += t("pipeline_result_failed").format(names=", ".join(results["failed"]))
        self._status_label.configure(text=text)
        messagebox.showinfo(t("app_title"), text)


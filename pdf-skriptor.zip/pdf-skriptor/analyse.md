# Analyse – PDF Skriptor (finaler Entwicklungsstand)

## -33. Nachtrag: Runde 9 – Seitenbereich beim Drucken + A4-Anpassung

Zwei vom Nutzer gemeldete/gewuenschte Ergaenzungen zum Drucken-Werkzeug.

**A4-Anpassung** (Ursache fuer "das Gedruckte ist sehr klein"): `lp` ohne
weitere Optionen druckt die PDF-Seite in ihrer Originalgroesse, ohne sie
an das tatsaechlich eingelegte Papier anzupassen. `print_logic.py`
uebergibt jetzt `-o fit-to-page -o media=a4` (per Web-Recherche
bestaetigte Standard-CUPS-Optionen fuer automatische Skalierung auf ein
festes Papierformat).

**Seitenbereich**: `-P <Seitenliste>` ist die offizielle `lp`-Option fuer
Seitenauswahl (z. B. `-P 1,3-5,16`). Neuer Umschalter "Alle Seiten"/
"Seitenbereich" in `print_ui.py`, zeigt bei Bedarf ein Eingabefeld mit
Hinweis auf die tatsaechliche Seitenzahl der aktiven Datei
(`fitz.open(path).page_count`) und validiert das Format vor dem Drucken
(`is_valid_page_range()` in `print_logic.py`) - leer oder ungueltig loest
eine klare Fehlermeldung statt eines fehlerhaften Druckauftrags aus.

**Verifikation**: Mit Fake-`lp`/`lpstat`-Skripten der tatsaechliche Aufruf
geprueft - bei Seitenbereich "1,3-4" exakt `-n 1 -o fit-to-page -o
media=a4 -d <Drucker> -P 1,3-4 <Datei>`; ungueltige Eingabe ("abc") fuehrt
zu einer Fehlermeldung und keinem Druckaufruf; Umschalten zwischen den
Modi blendet das Eingabefeld korrekt ein/aus; Hinweistext zeigt korrekt
"Seiten 1-5" bei einer 5-seitigen Testdatei.

Alle 77 Dateien kompilieren weiterhin fehlerfrei.

## -32. Nachtrag: Runde 8 – lpstat-Locale-Bug ("kein Drucker angezeigt")

Vom Nutzer gemeldet: Drucken-Werkzeug zeigt "Kein Drucker eingerichtet",
obwohl auf seinem System (Ubuntu, treiberlose CUPS-Unterstuetzung) ein
Drucker installiert ist. Per Web-Recherche bestaetigt: `lpstat` uebersetzt
seine Ausgabe abhaengig von der System-Locale (dokumentiertes
CUPS-Verhalten, u. a. apple/cups#1447) - auf einem deutschsprachigen
System beginnt die Zeile z. B. mit "Drucker" statt "printer",
wodurch `list_printers()`s Wort-Parsing leer blieb.

**Fix**: `print_logic.py` setzt `LC_ALL=C` und `LANGUAGE=C` gezielt fuer
die `lpstat`/`lp`-Unterprozessaufrufe (nicht fuer die App selbst) - damit
liefert CUPS immer die stabile, unlokalisierte Ausgabe zum Parsen,
unabhaengig von der Systemsprache des Nutzers. Zusaetzlich: leeres
Ergebnis von `lpstat -p` wird jetzt mit Rueckgabewert und Roh-Ausgabe in
fehler.log protokolliert, um kuenftige Faelle schneller einzugrenzen.

**Verifikation**: Fake-`lpstat`/`lp`-Skripte gebaut, die - wie ein echtes
deutschsprachiges Ubuntu - nur ohne erzwungene C-Locale deutsch
lokalisiert antworten; App mit `LANG=de_DE.UTF-8`/`LC_ALL=de_DE.UTF-8`
gestartet (exaktes gemeldetes Szenario). Drucker wird jetzt korrekt
erkannt und im Dropdown angezeigt.

Alle 77 Dateien kompilieren weiterhin fehlerfrei.

## -31. Nachtrag: Runde 7 – Schriftauswahl bei Text platzieren + neues Drucken-Werkzeug

Zwei neue Funktionen auf Wunsch ergänzt.

**Schriftauswahl** (Anmerkungen → Text platzieren): PyMuPDFs
`add_freetext_annot()` unterstuetzt Basis-14-Schriften nativ ueber den
`fontname`-Parameter - kein Embedding, keine neue Abhaengigkeit. Dropdown
(Helvetica/Times/Courier) in `text_tool_dialog.py`, durchgereicht durch
`annotate_interaction.py` zu `annotate_logic.add_text()`. Live verifiziert
inkl. Byte-Ebene: gespeicherte Annotation enthaelt `/DA: 0 0 0 rg /Cour
14.0 Tf` nach Auswahl von Courier.

**Neues Werkzeug „Drucken"**: `print_logic.py` (Drucker/Standarddrucker
via `lpstat`, Druckauftrag via `lp` - der auf allen sechs
Zieldistributionen vorhandene CUPS-Klientenweg, funktioniert identisch bei
treiberlosen IPP-Everywhere-Warteschlangen) und `print_ui.py`
(Druckerauswahl, Kopien-Stepper, Drucken-Button). Vollstaendig in Runde 7
integriert: Kachel in `home_view.py`, Icon in `generate_icons.py`,
Navigation in `app_window.py`, Hilfe in `help_view.py`,
Abhaengigkeitspruefung fuer `lp` in `install_check.py` (analog Ghostscript/
OCRmyPDF), zuletzt verwendeter Drucker in `settings.py`.

Mangels echtem Drucker in der Testumgebung wurden `lp`/`lpstat` durch
Skripte mit realistischer CUPS-Ausgabe ersetzt (zwei simulierte Drucker) -
damit end-to-end verifiziert: Auflistung, Standarddrucker-Vorauswahl,
Umschalten zwischen Druckern wirkt korrekt auf den tatsaechlichen Aufruf
(`-n <Kopien> -d <Drucker> <Datei>`), Kopien-Stepper, Erfolgsmeldung,
Drucker-Persistenz. Ohne Drucker: sauberer Hinweistext statt Absturz,
Drucken-Button korrekt deaktiviert. Auf Deutsch und Englisch geprueft,
inkl. korrekter alphabetischer Kachel-Einsortierung in beiden Sprachen.

Alle 77 Dateien kompilieren weiterhin fehlerfrei.

## -30. Nachtrag: Runde 6 – Koordinaten-Regression aus Runde 4 behoben

Vom Nutzer gemeldet: Beim Markieren/Einfügen unter Anmerkungen springt die
Anmerkung nach dem Loslassen der Maustaste nach rechts an eine andere
Stelle. Live reproduziert (Raster-Testdatei, Screenshot während des Ziehens
vs. direkt danach - sichtbarer horizontaler Sprung bestätigt) und auf den
Code zurückgeführt: `_update_page_centering()` aus Runde 4 (Nachtrag -28)
verschiebt das gerenderte Seitenbild um `(offset_x, offset_y)`, sobald die
Seite kleiner als der sichtbare Bereich ist. `document_view.canvas_x()`/
`canvas_y()` - die zentrale Umrechnung von Bildschirm- in
Canvas-Koordinaten, von JEDEM Anmerkungs- und Redaction-Werkzeug für die
PDF-Positionsberechnung genutzt - zog diesen Versatz nicht ab. Klassischer
"sieht waehrend der Aktion richtig aus, ist es aber nicht"-Bug: die
Vorschau beim Ziehen zeichnet direkt mit der (falschen) Canvas-Koordinate
auf die Canvas, was optisch stimmt; erst die tatsaechlich gespeicherte
PDF-Koordinate war falsch, sichtbar erst beim Neu-Rendern nach dem
Loslassen.

**Fix**: `canvas_x()`/`canvas_y()` ziehen den Versatz jetzt ab; neue
Methode `page_offset()` liefert ihn fuer die Gegenrichtung (Werkzeuge, die
waehrend einer Aktion direkt auf die Canvas zeichnen, brauchen dafuer die
echte Bildschirmposition und muessen ihn wieder addieren). Betroffen und
angepasst: `annotate_interaction.py` (Freihand-Vorschau, Rechteck-Vorschau,
Unterschrift-Overlay) und - eigenstaendig beim Durchgehen aller
canvas_x()/canvas_y()-Aufrufer gefunden - `redact_manual_ui.py` (identisches
Muster bei der manuellen Schwaerzung; in Runde 5 nur durch Zufall nicht
aufgefallen, weil die dortige Testdatei keine Zentrierung ausgeloest hat).
Mit vier verschiedenen Werkzeugen live verifiziert (Freihand, Hervorhebung,
Text platzieren, manuelle Schwaerzung), jeweils Vorschau- und
Endzustand-Screenshot pixelgenau deckungsgleich.

**Nebenbefund, ebenfalls behoben**: Die sechs Unterwerkzeug-Reiter bei
Anmerkungen waren als einzelne 6er-Zeile in der 380px-Seitenleiste zu schmal
- Beschriftungen abgeschnitten/unleserlich, reproduzierbar in jedem
Screenshot dieser Sitzung, unabhaengig vom eigentlichen Koordinaten-Bug.
`annotate_ui.py`: zwei Zeilen zu je drei Werkzeugen; da CTkSegmentedButton
pro Instanz nur eine eigene Auswahl fuehrt, leert `_handle_tool_selected()`
jetzt die jeweils andere Zeile. Auf Deutsch und Englisch verifiziert.

Alle 75 Dateien kompilieren weiterhin fehlerfrei.

## -29. Nachtrag: Runde 5 – Formulare, Seiten neu ordnen, Redaction live getestet

Fortsetzung von Nachtrag -28: die drei Kern-Workflows, die dort nur auf
Code-Ebene verifiziert waren, jetzt mit echter simulierter Maussteuerung
(Xvfb + xdotool) und selbst erzeugten Testdateien durchgeklickt.

**Formulare ausfüllen**: Speichern stürzte ab, sobald das AcroForm der PDF
kein eigenes `/DR` besitzt (`AttributeError: 'dict' object has no attribute
'get_object'` in pypdfs `update_page_form_field_values()`). Fix in
`forms_logic.py` (`_ensure_default_resources()`), mit isoliertem Python-
Repro und live über die App doppelt verifiziert.

**Seiten neu ordnen**: Button „Neue Reihenfolge speichern" schnitt seinen
Text links und rechts ab (zwei `fill="x", expand=True`-Buttons nebeneinander
zu schmal für die deutsche Beschriftung in der 380px-Seitenleiste). Ein
erster Fix-Versuch (feste `width=`) half nicht, siehe Code-Kommentar in
`reorder_ui.py`; der zweite (Buttons untereinander statt nebeneinander)
behebt es robust. Der Drag-&-Drop-Umsortiervorgang selbst war bereits davor
fehlerfrei (UI **und** gespeicherte Datei stimmen überein).

**Redaction**: Keine funktionalen Fehler. Besonders geprüft und bestätigt,
was die Kachel-Beschreibung verspricht ("kein reiner schwarzer Balken"):
in beiden Modi (Suche & Schwärzen sowie Manuell markieren) ist der
geschwärzte Text per `page.get_text()` tatsächlich nicht mehr extrahierbar,
nicht nur visuell überdeckt, während unbeteiligter Text exakt erhalten
bleibt. Einzige Korrektur: falsche Deklination "1 Bereiche vorgemerkt" →
neuer Schlüssel `redact_manual_pending_one` für den Singular.

**Nebenbei bemerkt**: Ein Teil der Testfehlschläge während dieser Runde
(Werkbank zeigte "Keine Datei ausgewählt" nach vermeintlich erfolgreichem
Laden) lag an zu knapp bemessenen Wartezeiten im eigenen Testskript
zwischen App-Start und erstem Klick, nicht an der App selbst - mit längeren
Wartezeiten reproduzierte sich das nicht erneut.

Alle 75 Dateien kompilieren weiterhin fehlerfrei.

## -28. Nachtrag: Unabhängiger Usability-/Workflow-Audit + vollständiger Bericht (4 Runden)

Neuer, unabhängiger Auftrag (Rolle: Senior UX/UI Designer, Usability Engineer,
QA-Tester): Ersteindruck/Onboarding, die vier Kern-Workflows (Text bearbeiten,
Seiten löschen/umsortieren, Zusammenfügen, Formulare ausfüllen),
Klickwege/Effizienz sowie Fehleranfälligkeit/Konsistenz systematisch prüfen,
strukturierten Bericht mit Fundstelle + Verbesserungsvorschlag liefern, danach
alle Befunde beheben (Reihenfolge selbst gewählt).

**Vorgehen**: App in isolierter Linux-Umgebung installiert und per Xvfb +
simulierter Maus-/Tastatursteuerung durchgeklickt (nicht nur Code gelesen),
inkl. echter Testdateien.

**Die zwei Hauptbefunde**: (1) `language.py` – rund 90 fehlende
Übersetzungsschlüssel, u. a. alle 21 Kachel-Beschreibungen, Redaction-Modul,
Kopf-/Fußzeile-Ausrichtung, Pipeline-Qualitätsstufen; (2) `scroll_helpers.py`
– Kachelmenü liess sich nach einem Sprachwechsel nicht mehr scrollen
(`<Enter>`/`<Leave>` feuert nicht zuverlässig bei Ansicht-Neuaufbau statt
Mausbewegung; jetzt zusätzlich über `<Map>`/`<Unmap>`/`<Destroy>` abgesichert).

**Runde 1 (Haupt-Fixes, vollständige Datei-Liste siehe AENDERUNGEN.md)**:
Übersetzung vervollständigt; Scroll-Bug behoben; „Weitere"
(Einstellungen/Hilfe/Über) als Icons neben „☰ Menü" statt unten im
Scroll-Menü (Befund 1.3); Werkbank-Leerzustand zeigt echte Drop-Zone statt
toter Fläche (Befund 1.1); kein blockierender Start-Dialog mehr, fehlende
Systemtools stattdessen dezent im Über-Tab (Befund 1.2); neues „Text
platzieren"-Werkzeug im Anmerkungen-Modul schliesst die Lücke „Text
bearbeiten existiert nirgends"; Zusammenfügen: Dateireihenfolge jetzt per
Drag & Drop direkt änderbar statt Umweg über die Werkbank; Seiten löschen:
visuelle Miniatur-Auswahl statt reiner Texteingabe + Bestätigungsdialog vor
dem Löschen; Formulare: `/TU`-Tooltip-Attribut als Feldbeschriftung, falls im
PDF vorhanden (Befund 2.4); Schliessen-Schutz bei ungesicherten Anmerkungen
(Befund 4.4, `app_window.py` `_handle_close_request()`).

**Runde 2**: `load_result_file()` in `file_list_sync.py` – Ergebnis nach
jeder Bearbeitung (Drehen, Löschen, Zusammenfügen, Kopf-/Fusszeile,
Wasserzeichen, PDF/A, Lesezeichen, Formulare, Anmerkungen, Signatur, OCR,
Komprimieren u. a.) wird automatisch in die Werkbank geladen und aktiv,
statt manuell erneut über „Dateien auswählen" geladen werden zu müssen –
reiner Klickweg-/Effizienz-Fix. Bewusste Ausnahme: Verschlüsseln (Ergebnis
wäre ohne Passwort ohnehin nicht direkt öffenbar).

**Runde 3**: Text-Werkzeug verfeinert – Schriftgrösse live als Zahl neben dem
Regler; platzierte Textfelder per Klick+Ziehen verschiebbar. Dabei einen
echten PyMuPDF-Bug behoben: `find_text_annot_at_point()` hielt keine starke
Referenz auf die Seite der gefundenen Anmerkung (nur schwache Referenz),
wodurch jeder weitere Zugriff beim Ziehen abstürzte – die Seite wird jetzt
als Instanzattribut während des gesamten Ziehvorgangs gehalten.

**Runde 4**: Dokument wird zentriert dargestellt, wenn kleiner als der
sichtbare Bereich (`_update_page_centering()` in `document_view.py`, an
`<Configure>` gebunden, zusätzlich nach jedem Rendern aufgerufen); Kacheln
sortieren jetzt alphabetisch nach dem übersetzten Titel je Kategorie
(`sorted(tools, key=lambda item: t(item[2]))` in `home_view.py`);
Unterschrift ist bis zum Speichern jetzt eine eigene, frei verschieb- und
mit dem Radierer löschbare Overlay-Liste statt direkt unveränderlich in die
Seite gebrannt (`annotate_interaction.py`, `_pending_signatures`,
`bake_pending_signatures()` schreibt erst beim Speichern dauerhaft).

**Unabhängige Nachverifikation (diese Sitzung, neue Umgebung)**: `py_compile`
über alle 75 Python-Dateien fehlerfrei; App per venv (`--system-site-packages`
wegen `python3-tk`) + Xvfb live gestartet, Startbildschirm auf Deutsch UND
Englisch per Screenshot geprüft (kein Blockier-Dialog, echte Drop-Zone,
Einstellungen/Hilfe/Über als Icons, Kacheln alphabetisch sortiert und alle
Kachel-Beschreibungen vollständig übersetzt – die beiden Hauptbefunde damit
in beiden Sprachen visuell bestätigt). Kernfixes aus Runde 1 und 4 zusätzlich
im Code nachvollzogen: Zentrierungs-Logik, Sortierfunktion,
Signatur-Overlay-Mechanismus, Löschen-Bestätigungsdialog,
Zusammenfügen-Drag-Reorder, `/TU`-Fallback in `forms_logic.py`,
Schliessen-Schutz in `app_window.py`. Keine neuen Fehler gefunden. Der beim
Auftrag angekündigte, aber bis dahin nicht als eigenes Dokument
festgehaltene strukturierte Bericht (gegliedert nach den vier ursprünglich
angefragten Dimensionen) wurde bei dieser Gelegenheit nachträglich
zusammengestellt und dem Nutzer separat übergeben; dieser Nachtrag hier
verlinkt/ergänzt ihn nur stichwortartig für das fortlaufende Analyse-Log.

## -27. Nachtrag: Per Maus verschiebbare Trenner (Werkbank / Vorschau / Anzeigefläche)

Neue Funktion (Nutzeranfrage): Werkbank, Seiten-Vorschaustreifen und die
grosse Dokumentenansicht lassen sich jetzt per Maus gegeneinander in der
Hoehe verschieben. Die eingestellten Hoehen werden dauerhaft in
settings.json gemerkt (Annahme, da nicht explizit gefordert, aber
konsistent mit Sprache/Ausgabeordner - im Antworttext an den Nutzer
transparent gemacht).

**Umsetzung**: Zwei `tk.PanedWindow` (orient="vertical"), verschachtelt:
- Aeusseres PanedWindow in `app_window.py` (`_outer_paned`, ersetzt die
  bisherige feste Grid-Aufteilung von `left_frame`): Pane 1 = Werkbank
  (`stretch="never"`, Starthoehe aus `settings["workbench_pane_height"]`),
  Pane 2 = die gesamte `DocumentView` (`stretch="always"`, uebernimmt
  jede zusaetzliche Fensterhoehe beim Vergroessern).
- Inneres PanedWindow in `document_view.py` (`_inner_paned`, zwischen
  Datei-Titel-Zeile und der bisherigen `nav_row` mit Blaettern/Zoom, die
  aussen vor bleibt): Pane 1 = Vorschaustreifen (nur vorhanden, wenn
  sichtbar - siehe unten), Pane 2 = `_canvas_frame` mit der eigentlichen
  Seitenansicht.

Beide binden `<ButtonRelease-1>` auf sich selbst (nicht auf ihre
Kind-Widgets - ein Klick INNERHALB von Werkbank/Vorschau/Anzeigeflaeche
loest das nicht aus, nur ein Loslassen auf dem Trenner selbst) und
schreiben danach die aktuelle Pane-Hoehe in settings.json.

**Vorschaustreifen-Sichtbarkeit auf add()/forget() umgestellt**: Die in
-26 eingefuehrte pack()/pack_forget()-Logik (mit `before=` zur
Positionsverankerung) wurde 1:1 auf die PanedWindow-Aequivalente
`_inner_paned.add(..., before=self._canvas_frame)` /
`_inner_paned.forget(...)` uebertragen; ein eigenes Flag
`_preview_strip_visible` ersetzt die Pruefung ueber `panes()`
(String-Vergleich der Tk-Pfade waere fehleranfaelliger gewesen).

**Debugging-Notiz fuer kuenftige Aenderungen an dieser Stelle**: Beim
Testen liess sich der innere Trenner zunaechst scheinbar gar nicht
ziehen (weder per simuliertem Mausklick noch programmatisch per
`sash_place()`) - das stellte sich NICHT als Bug heraus, sondern als
korrektes Verhalten: Bei kleiner Fenstergroesse war `_canvas_frame`
bereits an seiner `minsize=200` angekommen, sodass fuer ein Vergroessern
des Vorschaustreifens schlicht kein Platz mehr da war. Mit ausreichend
grossem Fenster funktioniert das Ziehen (per Maus UND programmatisch)
zuverlaessig in beide Richtungen. Wichtig fuer's naechste Mal: bei
"Trenner reagiert nicht"-Symptomen zuerst pruefen, ob die
Nachbar-Pane schon an ihrer minsize haengt, bevor an der
Ereignisbehandlung gesucht wird.

**Test**: Beide Trenner per simuliertem echten Mausklick gezogen
(Werkbank +80px, Vorschaustreifen +60px und -30px), jeweils Hoehe
und gespeicherter settings.json-Wert geprueft; Neustart mit zuvor
gespeicherter Werkbank-Hoehe bestaetigt korrekt uebernommen. Kompletter
GUI-Regressionslauf sowie der dedizierte Vorschaustreifen-Sichtbarkeitstest
(kein Dokument / normal / korrupt / Dateiwechsel / anderes Modul) aus
-26 erneut ausgefuehrt: unveraendert 0 Abstuerze, Sichtbarkeitslogik
funktioniert identisch zu vorher.

## -26. Nachtrag: Seiten-Vorschaustreifen zwischen Werkbank und Anzeigefläche

Neue Funktion (Nutzeranfrage): zwischen der Werkbank (Datei-Chips) und
der grossen Einzelseiten-Ansicht zeigt ein neuer horizontaler Streifen
eine kleine Miniatur pro Seite der aktiven Datei. Ein Klick auf eine
Miniatur springt zu dieser Seite in der grossen Ansicht; die
Miniatur der aktuell angezeigten Seite ist farblich hervorgehoben.
Bewusst NICHT per Drag & Drop umsortierbar - dafür gibt es bereits das
dedizierte Modul "Seiten neu ordnen".

**Neue Datei**: `page_preview_strip.py` (`PagePreviewStrip`, CTkFrame
mit horizontaler CTkScrollableFrame). Nutzt die bereits vorhandene
`render_thumbnails()` aus `reorder_logic.py` (dort um einen optionalen
`width`-Parameter erweitert, Standardwert unveraendert, daher fuer
`reorder_ui.py` kein Verhaltensunterschied) - 48px Miniaturbreite statt
der dortigen 90px, damit der Streifen kompakt bleibt (Kartenhoehe
110px, Streifen-Sichtbereich 130px hoch).

**Einbindung in `document_view.py`**: Instanz wird zwischen Datei-
Titel-Zeile und der Canvas-Anzeigeflaeche erzeugt, aber absichtlich
NICHT sofort gepackt. `_load_document()` ruft `load(path)` auf
(liefert `True`/`False` zurueck, ob Miniaturen vorhanden sind) und
packt/entpackt den Streifen selbst mit `before=self._canvas_frame` -
damit bleibt seine Position auch nach mehrfachem Ein-/Ausblenden
(korrupte Datei, kein Dokument) zuverlaessig zwischen Werkbank und
Anzeigeflaeche verankert, statt bei erneutem `pack()` ans Ende der
Pack-Reihenfolge (unterhalb der Anzeigeflaeche) zu rutschen.
`_render_current_page()` ruft nach jedem Seitenwechsel
`set_current_page()` auf, um nur die Hervorhebung zu aktualisieren
(kein erneutes Rendern aller Miniaturen bei jedem Blaettern). Bei
korrupter/nicht lesbarer aktiver Datei bleibt der Streifen ausgeblendet
(`render_thumbnails()` liefert dafuer ohnehin eine leere Liste).
Miniaturen werden nur beim Wechsel der aktiven Datei neu erzeugt,
nicht bei jedem `refresh()` (z. B. nach einer Anmerkung) - das haette
bei haeufigen kleinen Interaktionen unnoetig oft die komplette Datei
neu vom Datentraeger gerendert.

**`scroll_helpers.py` um Orientierung erweitert**: `bind_mousewheel_scroll()`
akzeptiert jetzt optional `orientation="horizontal"` (Standard weiterhin
`"vertical"`, alle zehn bestehenden Aufrufstellen unveraendert). Beim
Testen zunaechst faelschlich als Bug interpretiert, dass horizontales
Scrollen nicht reagiert - tatsaechliche Ursache war ein Fehler in der
eigenen Testmethode (ein einzelner `time.sleep()` gefolgt von nur
einem `update()`-Aufruf reicht nicht aus, um eine Kette
selbst-nachplanender `canvas.after()`-Ticks vollstaendig abzuarbeiten;
mit wiederholtem `update()` in kurzen Abstaenden - wie es eine echte
laufende mainloop ohnehin tut - funktioniert es korrekt). Kein
Code-Fehler, nur eine Erinnerung fuer kuenftige Xvfb-Tests dieser Art.

**Test**: Sichtbarkeit (kein Dokument / normales Dokument / korrupte
Datei / Dateiwechsel), Klick-Navigation auf mehrere Miniaturen,
Hervorhebung nach Vor-/Zurueck-Navigation, horizontales Scrollen bei
14 Seiten inkl. Klick auf eine erst nach dem Scrollen sichtbare
Miniatur, Anzeige im Modul "Organisieren" (document_view.py ist eine
einzige, ueber alle 21 Module hinweg geteilte Instanz) - alles wie
erwartet. Kompletter GUI-Regressionslauf aus -24/-25 erneut
ausgefuehrt: weiterhin 0 Abstuerze.

## -25. Nachtrag: Korrektur einer Regression aus -24 (Kachelmenü scrollte gar nicht mehr)

Die in -24 ergänzte Momentum-Begrenzung am Scroll-Rand (kein weiteres
Scroll-Momentum mehr aufbauen, wenn `canvas.yview()` bereits `end>=1.0`
bzw. `start<=0.0` meldet) hat das Scrollen im Kachelmenü und den
weiteren neun über `scroll_helpers.py` laufenden Ansichten komplett
lahmgelegt, sofort nach dem Einspielen gemeldet.

**Ursache**: `canvas.yview()` liefert bei der von CTkScrollableFrame
intern verwalteten Canvas nachweislich keinen aussagekräftigen Wert -
`canvas.cget("scrollregion")` bleibt dauerhaft leer, `yview()` bleibt
dauerhaft bei `(0.0, 1.0)` stehen, unabhängig vom tatsächlichen
Scroll-Zustand (per gezieltem Test verifiziert: auch nach echtem
`yview_scroll()` und nach 30 Durchläufen `update()` + Wartezeit
unverändert). Da `(0.0, 1.0)` rechnerisch immer BEIDE Randbedingungen
gleichzeitig erfüllt, wurde dadurch jede einzelne Mausrad-Bewegung
fälschlich als "bereits am Rand" erkannt und blockiert, bevor überhaupt
Momentum aufgebaut werden konnte. In `document_view.py` tritt dasselbe
Problem NICHT auf: dort wird eine eigene, klassische `tk.Canvas`
verwendet, deren `scrollregion` beim Rendern jeder Seite explizit
selbst gesetzt wird (`self._canvas.configure(scrollregion=...)`) -
`yview()` liefert dort nachweislich korrekte, sich mit dem
Scroll-Zustand ändernde Werte. Der Fehler betraf also ausschließlich
die CTkScrollableFrame-Fälle, nicht die Dokumentenvorschau.

**Behoben**: Die Rand-Vorabprüfung in `scroll_helpers.py` vollständig
entfernt; Mausrad-Momentum baut sich wie vor -24 wieder uneingeschränkt
auf, die zeitdelta-basierte Ausklingbewegung (die eigentliche Antwort
auf das Ruckel-Problem) bleibt erhalten. Die ursprünglich gemeldete
"Mauszeiger reagiert nach Überscrollen nicht mehr"-Beobachtung bleibt
damit vorerst ohne gezielten Gegenfix - ein zuverlässiger Weg, den
tatsächlichen Scroll-Zustand einer CTkScrollableFrame-Canvas
abzufragen, wurde in dieser Sitzung nicht gefunden. `document_view.py`
war von dieser Rücknahme nicht betroffen und wurde unverändert
gelassen (eigener Test bestätigt dort funktionierendes `yview()` und
korrektes Rand-Verhalten).

**Test**: Gezielter Regressionstest (Kachel-Position vor/nach
einzelnen und mehreren Mausrad-Kerben, Scrollen in beide Richtungen,
40x Überscrollen ohne Hängenbleiben, Klick nach Überscrollen weiterhin
funktionsfähig) sowie der komplette GUI-Regressionslauf aus -24
erneut ausgeführt - beides unauffällig, 0 Abstürze.

## -24. Nachtrag: Unabhängiger QA-Testdurchlauf + Kachelmenü-Nacharbeit

Unabhängiger Testdurchlauf (Xvfb, echte Maus-/Tastatursimulation per
xdotool, Backend-Logiktests mit eigens erzeugten Test-PDFs) sowie
erneut vom Nutzer gemeldete Probleme am Kachelmenü. Keine kritischen
Fehler, aber mehrere reale Funde - im Folgenden nach Bereich sortiert.

**Gemeldeter Fehler 1 (Kachelmenü, erneut nach -23)**: Scrollen fühlte
sich weiterhin ruckartig an; die farbige Umrandung der Kacheln sitzt an
den Ecken nicht ganz sauber; nach zu weitem Scrollen reagiert der
Mauszeiger auf den Kacheln nicht mehr zuverlässig.

**Ursache Ruckeln**: Die in -23 eingeführte Ease-out-Animation nahm pro
Tick eine feste Dauer von 12ms an. Tatsächlich vergeht zwischen zwei
`canvas.after()`-Ticks bei Systemlast (Neuzeichnen vieler Widgets,
Compositor) nicht immer exakt diese Zeit - ein verspäteter Tick wurde
bisher trotzdem nur um den festen 32%-Schritt bewegt, wodurch die
Bewegung an genau dieser Stelle sichtbar stockt. In der eigenen
Xvfb-Testumgebung (kein Compositor, keine Bildwiederholrate-Grenze)
war das nicht reproduzierbar - die Ursache liegt in der Zeitannahme,
nicht in einem sichtbaren Einzelfehler.

**Ursache Ecken**: Der Rahmeneffekt entsteht durch zwei UNABHÄNGIG
gezeichnete abgerundete Rechtecke (Rahmen-Frame mit `corner_radius+1`,
Button mit `corner_radius`, 1px Versatz). CustomTkinters
`draw_engine.__calc_optimal_corner_radius()` rundet den tatsächlich
gezeichneten Radius abhängig von der Bildschirmskalierung auf eigene
Zwischenschritte (0,5er-Schritte bei "circle_shapes"). Bei
Skalierungsfaktoren ungleich 1,0 (z. B. 125%/150% Bildschirmskalierung)
runden beide Widgets unabhängig voneinander leicht unterschiedlich,
wodurch der nominell 1px breite Rahmen an der gekrümmten Ecke nicht
mehr exakt konzentrisch ist - in der eigenen (unskalierten)
Testumgebung nicht sichtbar, rechnerisch aber nachvollzogen.

**Ursache Überscrollen**: Jede Mausrad-Kerbe erhöhte den intern
gepufferten Ziel-Rollweg (`pending["amount"]`) unabhängig davon, ob am
Scroll-Rand bereits Schluss war. Bei schnellem Weiterscrollen nach dem
Ende sammelte sich so unsichtbare "Scroll-Schuld" an, die erst
abgebaut werden musste, bevor ein Richtungswechsel oder eine
Klick-Interaktion wieder wie erwartet wirkte. Eine Reproduktion des
exakt gemeldeten Effekts gelang in der eigenen headless-Testumgebung
trotz mehrerer Anläufe nicht zuverlässig (CustomTkinters
Scrollregion-Aufbau verhält sich bei rein skriptgesteuertem `update()`
ohne echte laufende mainloop nachweislich anders als bei echter
interaktiver Nutzung) - der Fix behebt aber den eindeutig im Code
vorhandenen Mechanismus unabhängig davon.

**Behoben**: `scroll_helpers.py` sowie die separate Scroll-Logik in
`document_view.py` auf einen zeitdelta-basierten Abklingfaktor
umgestellt (`1 - (1-EASE)^(vergangene_ms/TICK_MS)`) - mathematisch
äquivalent zur bisherigen Fixschritt-Version bei exakter Tick-Dauer,
gleicht einen verspäteten Tick aber automatisch aus. Tick-Intervall von
12ms auf 16ms angehoben (näher an 60Hz, weniger überflüssige
Zeichenoperationen). Rahmen-Versatz in `home_view.py` von 1px auf 2px
vergrößert (`_BORDER_GAP`), um unabhängiges Runden bei jeder
Bildschirmskalierung sicher zu überdecken. Mausrad-Handler in beiden
Scroll-Modulen bauen an einem bereits erreichten Scroll-Rand kein
weiteres Momentum in dieselbe Richtung mehr auf.

**Weiterer QA-Fund**: Bei einer beschädigten/nicht lesbaren aktiven
Datei protokollierte `document_view.py` den Fehler zwar korrekt nach
`fehler.log`, zeigte in der zentralen Dokumentenansicht aber weiterhin
den Text "Keine Datei ausgewählt" - identisch zum Zustand ganz ohne
Datei. **Behoben**: Neues Flag `_load_error`; die zentrale Ansicht
zeigt jetzt "⚠ Datei konnte nicht geöffnet werden – möglicherweise
beschädigt oder kein gültiges PDF." und behält den Dateinamen in der
Kopfzeile bei (neuer Sprachschlüssel `preview_load_error`). Einzelne
Werkzeug-Panels (z. B. Lesezeichen) zeigen bei ungültiger Datei
weiterhin ihren eigenen neutralen Leerzustand - die zentrale, immer
sichtbare Anzeige wurde als wirksamster Punkt zuerst behoben.

**Weiterer QA-Fund**: `ocrmypdf` (System, per apt) und ein davon
unabhängig installiertes `pikepdf` können sich im Environment in die
Quere kommen (`ImportError: cannot import name 'PdfMatrix'`) - ein auch
außerhalb dieses Projekts bekanntes, wiederkehrendes Problem der
ocrmypdf/pikepdf-Versionskombination. Mit ausschließlich den durch
`install.sh` bzw. den Paketmanager konsistent installierten Paketen
(ohne fremde globale pip-Installation) trat der Fehler in einem
gezielten Gegentest NICHT auf. **Behoben (zusätzliche Absicherung)**:
`ocrmypdf` zusätzlich in `requirements.txt` aufgenommen; `ocr_logic.py`
ruft jetzt bevorzugt `sys.executable -m ocrmypdf` auf, falls im
eigenen venv installiert - dann stammen ocrmypdf und pikepdf garantiert
aus derselben, zueinander passenden Installation, unabhängig davon,
was sonst noch systemweit installiert ist. Fällt auf ein systemweit
per PATH gefundenes `ocrmypdf` zurück, falls nicht im venv vorhanden.

**Weitere kleinere QA-Funde, alle behoben**:
- `split_pdf()` legte den Zielordner nicht an, falls er fehlte -
  `os.makedirs(output_dir, exist_ok=True)` ergänzt.
- `appearance_mode` war in `settings.py` als Standardwert hinterlegt,
  aber nirgends in der UI änderbar und von `theme.py` ignoriert (dort
  fest auf "light" gesetzt) - als totes/irreführendes Feld entfernt.
- Standardwert für den Ausgabeordner (`~/Dokumente`) existiert nicht
  auf jedem System (andere Sprachumgebung, frisches Konto) -
  `_default_output_dir()` versucht `Dokumente`, dann `Documents`, dann
  das Home-Verzeichnis selbst (kein automatisches Anlegen).
- Die Drittanbieter-Lizenzliste im "Über"-Tab war fest auf Deutsch
  verdrahtet und blieb es auch bei Sprache Englisch - Lizenzwörter
  ("Lizenz"/"oder"/"externes Systemprogramm") jetzt über `t()`
  übersetzt, per Screenshot-Vergleich in beiden Sprachen verifiziert.
- `import fitz` erzeugte bei jedem Start eine Deprecation-Warnung - in
  allen 12 betroffenen Dateien auf `import pymupdf as fitz` umgestellt
  (identisches Verhalten, keine Warnung mehr).
- `requirements.txt` hatte nur Mindestversionen ohne Obergrenze -
  Obergrenzen anhand der tatsächlich getesteten Versionen ergänzt.

**Test**: Kompletter GUI-Regressionslauf (alle 21 Module, mit und ohne
geladene Datei, Sprachumschaltung, echter Kachel-Klick, Fenstergrößen)
nach allen Änderungen erneut ausgeführt - unveraendert 0 Abstürze,
Klick- und Sprachtest weiterhin erfolgreich. `split_pdf` mit fehlendem
Zielordner, `settings.py`-Fallback und der OCR-Fix zusätzlich gezielt
gegengetestet (inkl. Wiederholung des OCR-Laufs bei weiterhin
vorhandenem, ursprünglich konfliktverursachendem globalem pikepdf).

## -23. Nachtrag: Korrektur – eckiger weißer Fleck beim Hover + sanftes Scrollen

**Gemeldeter Fehler 1 (mit Screenshot)**: Beim Überfahren einer
Menü-Kachel mit der Maus erschien ein eckiges, deckendes weißes
Rechteck rund um Icon und Text - während der restliche Button korrekt
zur helleren Hover-Farbe wechselte. Sichtbar nur im Hover-Zustand, im
Ruhezustand unsichtbar (deshalb bei den bisherigen Ruhezustand-
Screenshots in Nachtrag -19/-20 nicht aufgefallen).

**Ursache**: Icon-Label, Text-Rahmen und die beiden Text-Label lagen
ohne eigenes, aktiv verwaltetes `fg_color` auf dem Button - ihr
Hintergrund war entweder unbestimmt oder statisch auf die
Ruhe-Hintergrundfarbe fixiert. Der eingebaute `hover_color`-Mechanismus
von `CTkButton` färbt aber ausschliesslich die Button-Fläche selbst
um; die darüber liegenden Kind-Widgets (Icon, Text) wissen nichts vom
Hover-Zustand des Elternteils und behalten ihre alte Farbe - dadurch
der sichtbare Farbbruch mit eckigen Kanten genau an den
Kind-Widget-Grenzen.

**Behoben**: Eingebauter Hover-Mechanismus des `CTkButton` deaktiviert
(`hover=False`), stattdessen eine eigene, über Icon, Text-Rahmen UND
beide Text-Label synchron laufende Hover-Färbung (`set_hovered()`),
gebunden an `<Enter>`/`<Leave>` auf allen inneren rohen tkinter-Widgets
(`_canvas`/`_label`) von Button UND Kind-Elementen - dasselbe Muster
wie bei der Klick-Weiterleitung in Nachtrag -19, hier für Hover-
Ereignisse statt Klicks angewendet (auch `<Enter>`/`<Leave>` direkt auf
`CTkButton`/`CTkLabel` gebunden feuert nicht zuverlässig, nur auf den
inneren `_canvas` bestätigt).

**Gemeldeter Fehler 2**: Scrollen mit dem Mausrad fühlte sich
ruckartig/hakelig an.

**Ursache**: Ohne explizites `yscrollincrement` scrollt eine Tk-Canvas
pro Mausrad-Kerbe um eine intern uneinheitlich bemessene "Einheit" -
ein einzelner harter Sprung statt einer fließenden Bewegung.

**Behoben**: `scroll_helpers.py` (zentral für 11 Ansichten inkl. der
Menu-Kacheln) sowie die separate Scroll-Logik der Dokumentenansicht
(`document_view.py`) auf eine sanft auslaufende Gleitbewegung
umgestellt: `yscrollincrement=1` für feine Kontrolle, jede
Mausrad-Kerbe addiert eine Zieldistanz zu einem Restwert, der in
~12ms-Schritten um jeweils ~32% abgebaut wird (Ease-out) - mehrere
kleine, abnehmende Teilschritte statt eines Sprungs. Nachfolgende
Kerben während einer laufenden Bewegung verlängern die Gleitstrecke
nahtlos. In der Dokumentenansicht bewusst getrennt von der
(unverändert sofortigen) Strg+Mausrad-Zoomfunktion - eine ausklingende
Zoom-Animation wäre eher verwirrend als hilfreich.

**Tests**: `py_compile`. Fehler 1 mit einem echten, simulierten Hover
(`card._canvas.event_generate("<Enter>")`) unter Xvfb reproduziert und
nach der Korrektur per Screenshot bestätigt: kein Farbbruch mehr,
gesamte Kachel färbt sich einheitlich um; zusätzlich der Ruhezustand
erneut gegengeprüft. Für Fehler 2 zunächst die Ease-out-Logik
isoliert an einer `tk.Canvas` mit fest gesetzter `scrollregion`
nachgebaut und bestätigt (11 Teilschritte mit sauber abnehmender
Größe: 42/28/19/13/9/6/4/3/2/1 Pixel). Danach zusätzlich versucht,
denselben Ablauf über die echte `HomeView`-Instanz unter Xvfb zu
bestätigen - dabei aufgefallen, dass `CTkScrollableFrame` seine
`scrollregion` in dieser speziellen, sehr kurzlebigen Testumgebung
(auch mit nachträglich installiertem `fluxbox`-Fenstermanager) nicht
rechtzeitig selbst setzt, obwohl die zugrunde liegende Inhaltsgröße
bereits korrekt berechnet vorlag (373×1936px, per `bbox("all")`
bestätigt) - ein Timing-Merkmal der Original-CustomTkinter-Bibliothek,
nicht der eigenen Änderung. Nach einmaligem manuellem Nachziehen der
`scrollregion` lief der volle Ablauf über die echte `HomeView` und
bestätigte 12 unterschiedliche, sauber ausklingende
Zwischenpositionen (0.022 → 0.057 → 0.065 → 0.067, dann Stillstand)
statt eines einzelnen Sprungs.

## -22. Nachtrag: Icons in eigenen Unterordner verschoben

**Umgesetzt**: Auf Wunsch liegen die 21 generierten Menü-Icons jetzt
in einem eigenen Unterordner `icons/` statt einzeln im Hauptordner -
eine bewusste Ausnahme von der sonst durchgehend flachen
Ordnerstruktur (siehe Coding-Richtlinie „alles im Hauptordner, ohne
Unterordner"), die hier auf ausdrücklichen Wunsch für reine
Bild-Ressourcen gemacht wurde. `avatar.png` bleibt bewusst im
Hauptordner (war nicht Teil der Anfrage, andere Referenzstelle in
`about_view.py`).

**Geändert**: `generate_icons.py` schreibt jetzt nach
`icons/icon_<modul>.png` (Ordner wird bei Bedarf automatisch
angelegt). `home_view.py` läd die Modul-Icons entsprechend über
`os.path.join("icons", f"icon_{module_key}.png")`.

**Tests**: `py_compile`. `generate_icons.py` isoliert in einem
Test-Verzeichnis ausgeführt - erzeugt zuverlässig alle 21 Dateien
unter `icons/`. Unter Xvfb mit echter `HomeView`-Instanz geprüft:
weiterhin alle 22 Bilder (1 Avatar + 21 Icons) erfolgreich geladen;
zusätzlich gezielt bestätigt, dass der alte Pfad ohne Unterordner
jetzt korrekt `None` liefert (Datei dort nicht mehr vorhanden) und der
neue Pfad mit Unterordner erfolgreich lädt. Abschließend erneuter
visueller Screenshot - Icons und Rahmen sehen unverändert korrekt aus.

## -21. Nachtrag: Zoom für die Dokumentenansicht

**Umgesetzt**: Die zentrale Dokumentenansicht (`document_view.py`) war
bisher fest auf einen einzigen Render-Zoom (130 %) fixiert - jetzt
stufenlos zoombar zwischen 40 % und 400 %. Drei Bedienwege: „−"/„+"-
Knöpfe neben der Seitennavigation, Strg+Mausrad direkt über der Seite,
und ein Klick auf die Prozentanzeige setzt auf 100 % zurück. Die
Scroll-Position bleibt beim Zoomen ungefähr erhalten (Anteilswert vor
dem Neu-Rendern gemerkt, danach wiederhergestellt), damit man nicht
bei jedem Klick an den Seitenanfang zurückspringt. Ein neu geladenes
Dokument startet immer wieder bei 100 %. Da Werkzeuge wie Anmerkungen,
Suche und Lesezeichen bereits durchgehend `get_zoom()` nutzen (nie den
alten Modul-Konstanten `_RENDER_ZOOM` direkt), funktionieren
Freihand-Zeichnen, Trefferhervorhebung usw. bei jeder Zoomstufe
automatisch korrekt weiter - keine Anpassung in anderen Dateien nötig.

**Architektur**: Neue Instanzvariable `_zoom_level` (Faktor,
1.0 = 100 %); `get_zoom()` liefert weiterhin den EFFEKTIVEN Zoom
(`_RENDER_ZOOM * _zoom_level`) als einzige Quelle der Wahrheit -
unveränderte Verhalten für alle bestehenden Aufrufer. Navigationszeile
umgebaut: Seiten-Navigation und Zoom-Regler jetzt in zwei getrennten
Unter-Frames links/rechts statt einer einzelnen Reihe mit `expand`.

**Wichtiger Fund - derselbe CustomTkinter-Bug wie in Nachtrag -19,
diesmal direkt beim Implementieren erkannt und sofort behoben**: Der
Klick auf die Prozentanzeige zum Zurücksetzen funktionierte zunächst
nicht, weil `<Button-1>` direkt auf ein `CTkLabel` gebunden in dieser
CustomTkinter-Version nicht feuert - nur die intern genutzten rohen
tkinter-Widgets (`_label`, `_canvas`) empfangen den Klick tatsächlich
(siehe ausführliche Erklärung in Nachtrag -19). Zur Sicherheit den
Rest der Codebasis erneut nach diesem Muster durchsucht: keine weiteren
betroffenen Stellen gefunden.

**Tests**: `py_compile`. Unter Xvfb mit echtem `FileManager` und
`DocumentView`: Zoomstufe und Beschriftung nach Zoom-In/-Out/-Reset
kontrolliert, Unter-/Obergrenze durch viele aufeinanderfolgende Klicks
erzwungen und bestätigt (exakt 40 % bzw. 400 %, kein Ueber-/
Unterschreiten), Klick auf die Prozentanzeige (über das korrekte
innere `_label`-Widget, nicht das äußere `CTkLabel` - siehe oben)
setzt zuverlässig zurück. Strg+Mausrad simuliert: zoomt korrekt in
beide Richtungen; zur Abgrenzung zusätzlich bestätigt, dass normales
Scrollen (ohne Strg) den Zoom unverändert lässt. Abschliessend ein
echter Screenshot mit auf 132 % gezoomtem Testdokument - Zoom-Regler,
Prozentanzeige und die dadurch automatisch erscheinende horizontale
Bildlaufleiste sehen wie vorgesehen aus.

README.md um einen Hinweis zur Zoom-Bedienung ergänzt.

## -20. Nachtrag: Korrektur – Kachel-Rahmen nur zur Hälfte sichtbar

**Gemeldeter Fehler**: Der in Nachtrag -19 eingeführte farbige
Kachel-Rahmen war in der Praxis nur teilweise sichtbar (grob die
linke Hälfte bzw. je nach Kachel unterschiedlich stark abgeschnitten).

**Ursachenanalyse**: Zwei voneinander unabhängige Effekte, beide nur
mit einem echten Screenshot unter Xvfb sichtbar (im reinen Code lesen
nicht erkennbar):
1. Der ursprüngliche Ansatz nutzte `border_width`/`border_color`
   direkt auf dem `CTkButton`. Die darüber liegenden Icon-/Text-Widgets
   sind zwar als `fg_color="transparent"` deklariert, CustomTkinter
   interpretiert das aber nicht als echte Transparenz, sondern malt
   eine deckende Fläche in der (flachen) Hintergrundfarbe des
   Elternteils - ohne den Rahmen-Strich nachzubilden. Dadurch wurde der
   Rahmen dort übermalt, wo die Text-Spalte lag.
2. Nach Umstellung auf einen separaten, farbigen Rahmen-Frame HINTER
   dem eigentlichen Button (1px Abstand, klassischer "Padding-Rahmen"-
   Trick) trat ein zweiter, unabhängiger Fehler zutage: `CTkButton`
   zeichnet seine abgerundete Fläche anhand des eigenen `width`-
   Konfigurationswerts (Standard: 140px) und aktualisiert diesen Wert
   NICHT automatisch, nur weil `pack(fill="both", expand=True)` das
   Widget breiter zieht. Die Klickfläche (`winfo_width()`) wuchs zwar
   korrekt auf die volle Kachelbreite, die sichtbar gezeichnete Form
   blieb aber bei 140px stehen - der Rahmen-Frame dahinter schien
   dadurch rechts als grosser, unpassender Farbblock durch. Mit
   `print(card.cget("width"))` direkt in der laufenden Instanz
   bestätigt: 140 vor, korrekte Breite nach manueller
   `configure(width=...)`.

**Behoben**: Farbiger Rahmen kommt jetzt von einem separaten
`CTkFrame` in der Werkzeugfarbe, der um 1px größer ist als der
eigentliche Button und dahinter liegt (`border_frame` → `card` mit
`padx=1, pady=1`). Zusätzlich neue Methode `_sync_card_widths()` in
`home_view.py`, die für jede Kachel die tatsächliche Breite des
Rahmen-Frames nachträgt (`card.configure(width=...)`) - einmalig kurz
nach dem ersten Aufbau (`self.after(50, ...)`) sowie bei jeder
Größenänderung über ein `<Configure>`-Binding auf die
Scroll-Fläche, damit ein späteres Vergrößern/Verkleinern des
Anwendungsfensters den Rahmen nicht erneut verschiebt.

**Tests**: Fehler zunächst mit einem echten Screenshot unter Xvfb
reproduziert - dabei ist aufgefallen, dass die Standard-Testumgebung
mangels `~/.fonts/Roboto-*.ttf` auf eine grob vereinfachte
Schrift-Darstellung ("circle_shapes") zurückfällt, die das Problem
verschleiert hätte; deshalb für diesen Test gezielt die echte
Roboto-Schriftart in ein Test-Home-Verzeichnis kopiert, um realistische
Textmaße wie beim Nutzer zu erhalten. Ursache 1 (Übermalen durch
"transparente" Flächen) durch gezielten Vergleichstest bestätigt.
Ursache 2 (hängender `width`-Konfigurationswert) durch direktes
Auslesen von `card.cget("width")` in der laufenden Instanz vor/nach
der Korrektur nachgewiesen (140 → korrekte Breite). Nach der
vollständigen Korrektur alle 21 Kacheln erneut per Screenshot
kontrolliert (in drei Ausschnitten, um auch weit unten liegende
Kacheln wie "Über dieses Programm" zu erfassen) - durchgehend
vollständiger, korrekt positionierter Rahmen ohne Farbblock-Reste.

## -19. Nachtrag: Menü-Kacheln mit farbigem Rahmen und 3D-Icons (Icon links, Text rechts)

**Anlass**: Wunsch nach einem dünnen farbigen Rahmen um jede
Menü-Kachel sowie einem passenden farbigen 3D-Icon je Funktion, mit
Icon links und Text rechts (statt bisher Emoji + Text übereinander in
einem einzigen Textblock).

**Umgesetzt**: 21 eigene "3D-Badge"-Icons erzeugt (abgerundetes
Farbverlaufs-Quadrat, weicher Schlagschatten, Glanzlicht oben, feiner
dunkler Rand, einfacher weißer Glyph je Werkzeug - Stil angelehnt an
macOS-App-Icons). Da keine Bildgenerierungs-Skill in dieser Umgebung
zur Verfügung stand und das Herunterladen fremder Icon-Sets
Lizenzfragen für mitgeliefertes Material aufgeworfen hätte, wurden die
Icons stattdessen rein programmatisch mit Pillow gezeichnet - keine
neue Abhängigkeit (Pillow ist bereits vorhanden), keine
Lizenzunsicherheit.

**Architektur**: `icon_style.py` (87 Zeilen: Farbverlauf, abgerundete
Maske, Schatten, Glanzlicht, Rahmen - wiederverwendbare Zeichenbasis)
und `generate_icons.py` (274 Zeilen: 21 einzelne Glyph-Zeichenfunktionen
plus Zuordnung Modul → Farbe/Glyph). Beide bewusst deutlich über der
100-Zeilen-Richtlinie: reine Build-Werkzeuge (wie ein Asset-Compiler),
nicht Teil des Laufzeit-Modulgraphen der Anwendung - vergleichbar mit
einer Grafik-Ressource, die einmalig erzeugt statt bei jedem Programmstart
ausgefuehrt wird. `python3 generate_icons.py` erzeugt beim Aufruf 21
PNG-Dateien (`icon_<modul>.png`) direkt im Hauptordner, genau wie
`avatar.png`. `home_view.py` um eine Farbe pro Werkzeug ergänzt (muss
manuell mit der `ICONS`-Zuordnung in `generate_icons.py`
übereinstimmen - dort kommentiert) und das Kachel-Layout umgebaut:
Icon links (44×44px, `_load_square_image()`), Titel/Beschreibung
rechts, `border_width=1`/`border_color=<Werkzeugfarbe>` auf dem
`CTkButton` für den dünnen farbigen Rahmen. Fällt eine Icon-Datei
fehlen (z. B. `generate_icons.py` nie ausgeführt), springt die Kachel
automatisch auf das alte Emoji zurück, statt abzustürzen.

**Wichtiger Fund während der Tests - echter, bisher unbemerkter Bug**:
Ein `<Button-1>`-Bind direkt auf ein `CTkLabel` oder einen
transparenten `CTkFrame` von CustomTkinter feuert NICHT - nur die
intern genutzten rohen tkinter-Widgets (`_label`, `_canvas`) empfangen
Mausereignisse tatsächlich. Das wurde durch einen gezielten Vergleichstest
mit reinem `tkinter` (dort funktioniert direktes Binden auf Frame/Label
einwandfrei) klar von einem CustomTkinter-spezifischen Verhalten
unterschieden. Der ursprüngliche Code (vor diesem Nachtrag) legte einen
vollflächigen transparenten `CTkFrame` über die gesamte Kachel und band
`<Button-1>` direkt auf Frame/Label - dadurch wurde vermutlich der
Klick auf große Teile der Kachel bisher tot abgefangen (weder Frame
noch das darunterliegende `CTkButton` reagierten). Behoben durch
Verzicht auf den vollflächigen Overlay-Frame (Icon/Text-Frame liegen
jetzt direkt auf dem Button, der Rest der Kachel bleibt der Button
selbst und funktioniert über sein eigenes `command=`) sowie durch
Binden auf `label._label` UND `label._canvas` statt auf das
`CTkLabel` selbst.

**Tests**: `py_compile` für alle geänderten/neuen Dateien. Alle 21
Icons einzeln als Kontaktbogen visuell im Bild-Betrachter geprüft,
mehrere Glyphen (Tag, Wassertropfen, Ebenen-Symbol, Kopf-/Fußzeile,
Kompress-Pfeile) nach der ersten Prüfung gezielt nachgebessert. Danach
die komplette Startseite unter Xvfb mit `python3-tk` gestartet und per
`import`/ImageMagick als echter Screenshot exportiert (nicht nur
Code gelesen) - zweimal geprüft: einmal die ersten sichtbaren Kacheln,
einmal mit stark vergrößertem Fenster die komplette Liste aller 21
Kacheln inkl. der Abschnitte "Besondere Funktionen" und "Weitere" -
keine Textabschneidung, keine Überlappung, Rahmenfarben stimmen mit
den Icon-Farben überein. Zusätzlich der oben beschriebene Klick-Bug
gefunden UND die Behebung verifiziert: `card.invoke()` (Klick auf den
Button selbst), Klick auf `_label` und Klick auf `_canvas` von Icon,
Titel und Beschreibung lösen jetzt alle zuverlässig die Navigation aus.

Kein neuer Eintrag in README.md/help_view.py nötig, da es sich um eine
reine Layout-/Stil-Änderung ohne neue Funktion handelt.

## -18. Nachtrag: Schritt 9 der Roadmap – Digitale kryptographische Signatur (Abschluss der Firefox-Roadmap)

**Umgesetzt**: Neues, achtzehntes Modul "Digitale Signatur" - der von
Anfang an als aufwendigster Punkt markierte letzte Baustein der
Firefox-Vergleichs-Roadmap (siehe Nachtrag -10). Im Unterschied zum
bereits vorhandenen visuellen Unterschriften-Stempel im Anmerkungen-
Modul erzeugt dieses Modul eine echte kryptographische PKCS#7-Signatur
(handschriftliches Bild vs. digitale Signatur - zur Abgrenzung bewusst
unterschiedlich benannt: "Anmerkungen → Unterschrift" bzw. "Digitale
Signatur"). Dreiteiliger Aufbau nach demselben Router-Muster wie das
Organisieren-Modul (`organize_ui.py`):
- **Zertifikat**: neues, zehn Jahre gültiges selbstsigniertes
  X.509-Zertifikat (RSA 2048) erzeugen (Name/E-Mail/Organisation/
  Passwort) oder eine vorhandene .p12/.pfx-Datei auswählen (z. B. ein
  echtes, von einer Stelle ausgegebenes Zertifikat). Das Passwort wird
  nirgendwo gespeichert - nur die dadurch bereits verschlüsselte
  .p12-Datei selbst, analog zum bestehenden Muster in `settings.py`
  und `signature_logic.py`.
- **Signieren**: aktive Datei mit dem aktiven Zertifikat signieren
  (Grund/Ort optional), Passwort wird bei jedem Vorgang neu eingegeben.
- **Prüfen**: beliebige PDF-Datei auswählen (auch nicht mit PDF
  Skriptor signierte) und prüfen, ob sie seit der Signatur unverändert
  ist, wer signiert hat, und ob die Zertifikatskette anerkannt ist.

**Neue Abhängigkeit**: `pyHanko` + `pyhanko-certvalidator` (MIT-Lizenz)
für das eigentliche Signieren/Prüfen sowie `cryptography`
(Apache-2.0/BSD-3-Clause) für die Zertifikatserzeugung - zu
`requirements.txt` hinzugefügt (wird automatisch über
`install.sh`/`pip install -r requirements.txt` mitinstalliert, keine
manuelle Zusatzinstallation nötig). Beide Lizenzen in `README.md` und
im "Über dieses Programm"-Tab (`about_view.py`) ergänzt.

**Wichtige Entscheidung - rein offline**: Es werden bewusst keine
Zeitstempel- oder Sperrlisten-Server im Internet kontaktiert (kein
RFC-3161-Zeitstempeldienst, keine OCSP/CRL-Abfrage), damit die
Anwendung ohne Netzwerkzugriff funktioniert und keine Daten nach außen
gibt - konsistent mit dem sonst durchgehend lokalen Charakter von PDF
Skriptor. Konsequenz: Bei einem selbstsignierten Zertifikat (der
Normalfall ohne eigene Unternehmens-PKI) meldet die Prüfung immer
"nicht in einer anerkannten Vertrauenskette" - das ist kein Fehler,
sondern der erwartete, in der UI auch so erklärte Zustand. Die
kryptographisch wichtigste Eigenschaft - ob die Datei seit der
Signatur unverändert ist - funktioniert unabhängig davon zuverlässig.

**Architektur**: `cert_logic.py` (121 Zeilen: Zertifikatserzeugung/
-verwaltung, keine UI), `pdf_sign_logic.py` (65 Zeilen: Signieren/
Prüfen via pyHanko, keine UI), `sign_cert_ui.py` (98 Zeilen),
`sign_document_ui.py` (104 Zeilen), `sign_verify_ui.py` (72 Zeilen) als
die drei Unter-Werkzeuge, sowie `sign_module_ui.py` (67 Zeilen) als
dünner Router - anders als beim bisherigen `organize_ui.py`-Vorbild
diesmal mit korrekt übersetzten Reiter-Beschriftungen für DE/EN
(nicht wie dort fest auf Deutsch codiert). Einbindung in
`app_window.py` und neue Kachel in `home_view.py`. Alle Texte in
`language.py` für DE und EN ergänzt - Sync-Check bestätigt
identische Schlüsselmenge (148 Schlüssel je Sprache, mit Abstand die
umfangreichste Ergänzung der gesamten Roadmap).

**Tests**: Da es hier um kryptographische Korrektheit geht, wurde
besonders gründlich getestet:
- pyHanko + cryptography testweise systemweit installiert, um echte
  End-to-End-Signaturen zu erzeugen statt nur den Code zu lesen
- Zertifikatserzeugung, Signieren und Prüfen als reine Logik-Kette
  getestet: `intact=True`/`valid=True`/`trusted=False` bei einem
  frisch signierten Dokument (trusted=False korrekt, da selbstsigniert)
- **Manipulationserkennung gezielt getestet**: ein einzelnes Byte in
  der signierten Datei nach der Signatur verändert - Prüfung meldet
  daraufhin zuverlässig `intact=False`
- Falsches Passwort beim Signieren führt korrekt zu `False` statt
  eines Absturzes
- Vollständiger GUI-Test unter Xvfb mit echtem `FileManager`:
  Passwort-Mismatch bei der Zertifikatserzeugung (Fehlermeldung),
  danach korrekte Erzeugung, Statusanzeige im Zertifikat- UND im
  Signieren-Tab, tatsächliches Signieren mit Grund/Ort, Passwortfeld
  wird nach dem Signieren geleert
- Prüf-Werkzeug mit drei Fällen getestet: unveränderte signierte
  Datei (✓ unverändert), gezielt manipulierte Kopie (✗ verändert!),
  komplett unsignierte Datei (Hinweis "keine Signatur enthalten") -
  alle drei Textausgaben stimmen exakt mit dem erwarteten Ergebnis
  überein; Widget-Struktur zusätzlich auf Duplikate geprüft (keine
  gefunden - die doppelte Text-Ausgabe im ersten Testlauf war nur die
  interne Label-Verschachtelung von CustomTkinter, kein Bug)

`analyse.sh` bewusst NICHT um eine pyHanko/cryptography-Prüfung
erweitert: das Skript prüft bislang ausschließlich externe
System-Programme (Tesseract, Ghostscript), nicht einzelne
Python-Pakete - deren Verfügbarkeit stellt bereits
`pip install -r requirements.txt` in `install.sh` sicher.

README.md, help_view.py (DE+EN) und about_view.py entsprechend ergänzt.

**Damit ist die gesamte, in Nachtrag -10 begonnene Firefox-Vergleichs-
Roadmap (9 Schritte) sowie die in Nachtrag -11 daraus abgeleitete
Büro-Funktionen-Roadmap vollständig abgeschlossen.**

## -17. Nachtrag: Schritt 8 der Roadmap – Seiten per Drag & Drop neu anordnen

**Umgesetzt**: Neues, siebzehntes Modul "Seiten neu ordnen" - die
umfangreichste UI-Ergänzung der gesamten Firefox-Roadmap. Alle Seiten
der aktiven Datei werden als Vorschaukarten in einer scrollbaren Liste
dargestellt; per Maus gezogen "hüpft" eine Karte beim Überqueren der
Mitte einer Nachbarkarte an deren Position - ein bewusst einfaches,
robustes Muster (kein Ghost-Image, kein Toplevel-Fenster), das ohne
zusätzliche GUI-Bibliothek auskommt, da tkinter kein natives
Drag-&-Drop für Widgets mitbringt. Zusätzlich ein
"Ursprüngliche Reihenfolge"-Knopf zum Zurücksetzen ohne das Modul zu
verlassen. War bisher durch keines der bestehenden Organisieren-
Unterwerkzeuge abgedeckt, die ausschließlich textbasierte
Seitenzahl-Eingabe nutzen (z. B. "1,3,5-7") - dieses Modul ist die
einzige visuelle Seitenverwaltung der Anwendung.

**Architektur**: `reorder_logic.py` (55 Zeilen: Vorschaubild-Erzeugung
via PyMuPDF-Pixmap, Umsortierung via `document.select(order)`, keine
UI), `reorder_card.py` (57 Zeilen: eine einzelne ziehbare Karte, meldet
Drag-Ereignisse nach oben, kennt ihre eigene Listenposition nicht) und
`reorder_ui.py` (166 Zeilen: Liste verwalten, Ziel-Position anhand der
Bildschirm-Y-Koordinate der Nachbarkarten bestimmen, Speichern/
Zurücksetzen - liegt aus denselben Gründen über der
100-Zeilen-Richtlinie wie die anderen Panel-Dateien mit Zeichen- und
Interaktionslogik). Einbindung in `app_window.py` und neue Kachel in
`home_view.py`. Alle Texte in `language.py` für DE und EN ergänzt -
Sync-Check bestätigt identische Schlüsselmenge (113 Schlüssel je
Sprache).

**Tests**: `py_compile` für alle geänderten/neuen Dateien.
Funktionaler Test der Logik mit echtem PyMuPDF-Dokument: Vorschaubilder
in korrekter Größe/Reihenfolge erzeugt, `apply_page_order()` mit
umgekehrter Reihenfolge getestet - Textinhalt jeder Ausgabeseite per
Extraktion bestätigt exakte Übereinstimmung mit der erwarteten neuen
Reihenfolge. GUI-Test unter Xvfb mit echtem `FileManager`: fünf Karten
geladen, eine Karte schrittweise über drei Nachbarkarten hinweg
"gezogen" (simulierte Zeigerkoordinaten anhand der tatsächlichen
Bildschirmposition jeder Karte nach jedem Repack ermittelt) - die
Reihenfolge ändert sich nach jedem Überqueren exakt wie erwartet.
Zusätzlich vollständiger Speicher-Test (umgekehrte Reihenfolge
gespeichert, Ergebnisdatei per Textextraktion gegengeprüft) und
"Ursprüngliche Reihenfolge"-Knopf getestet (stellt Original-Reihenfolge
zuverlässig wieder her).

README.md und help_view.py (DE+EN) entsprechend ergänzt.

## -16. Nachtrag: Schritt 7 der Roadmap – Volltextsuche im Dokument

**Umgesetzt**: Neues, sechzehntes Modul "Suche" - Volltextsuche über
das gesamte aktive Dokument (wie Strg+F im Firefox-PDF-Betrachter).
Alle Treffer werden auf ihrer jeweiligen Seite farbig markiert (gelb),
der aktuelle Treffer zusätzlich hervorgehoben (orange); "Weiter"/
"Zurück" springt zwischen den Treffern, auch über Seitengrenzen
hinweg, inklusive automatischem Scrollen zur Trefferposition. Reine
Navigationshilfe - es wird nichts in der Datei verändert oder
gespeichert, daher kein Speichern-Dialog wie bei den anderen neuen
Modulen.

**Architektur**: `search_logic.py` (30 Zeilen, reine Suche über
PyMuPDF `page.search_for()`, keine UI) und `search_ui.py` (157 Zeilen,
Panel mit Eingabefeld, Navigation, Zähler und Overlay-Zeichnung -
liegt aus denselben Gründen über der 100-Zeilen-Richtlinie wie die
anderen Panel-Dateien mit Navigation UND Zeichenlogik). Statt einer
neuen Erweiterung von `document_view.py` wird der bereits für das
manuelle Redaction-Modul vorhandene `set_overlay_callback()`-
Mechanismus wiederverwendet (Konsistenz mit bestehendem Muster statt
neuer API). Einbindung in `app_window.py` und neue Kachel in
`home_view.py`. Alle Texte in `language.py` für DE und EN ergänzt -
Sync-Check bestätigt identische Schlüsselmenge (109 Schlüssel je
Sprache).

**Tests**: `py_compile` für alle geänderten/neuen Dateien.
Funktionaler Test der Logik mit echtem PyMuPDF-Dokument über zwei
Seiten: korrekte Trefferzahl und -position, Groß-/Kleinschreibung wird
nicht unterschieden, leere Suche und Suche ohne Treffer liefern
korrekt leere Listen. GUI-Test unter Xvfb mit echtem `FileManager` und
echter `DocumentView`: vollständige Navigation über drei Treffer auf
zwei Seiten inklusive Seitenwechsel, Umlauf in beide Richtungen
("Weiter" vom letzten zum ersten Treffer, "Zurück" vom ersten zum
letzten), Zählertext bei jedem Schritt kontrolliert, Reset bei leerer
Suche, Hinweistext bei fehlendem Treffer. Zusätzlich der Canvas-Inhalt
nach einer Suche als Bild exportiert und visuell im Bild-Betrachter
geprüft: aktiver Treffer klar sichtbar orange, weiterer Treffer gelb -
farblich wie vorgesehen unterscheidbar.

README.md und help_view.py (DE+EN) entsprechend ergaenzt.

## -15. Nachtrag: Schritt 6 der Roadmap – PDF/A-Konvertierung (Langzeitarchivierung)

**Umgesetzt**: Neues, fünfzehntes Modul "PDF/A-Archivierung". Ein
Klick wandelt die aktive Datei nach PDF/A-2b (ISO 19005-2) um -
Standard für die dauerhafte, z. B. GoBD-konforme Archivierung (siehe
Marktanalyse in Nachtrag -11). Bewusst ohne Auswahl weiterer
Konformitätsstufen (1a/1b/2a/2u/3...) - PDF/A-2b ist der in der Praxis
am meisten empfohlene Kompromiss, zusätzliche Optionen hätten hier nur
unnötig verwirrt.

**Wichtige technische Entscheidung**: Keine neue Abhängigkeit und
kein mitgeliefertes Drittanbieter-Farbprofil nötig. Ghostscript bringt
sein eigenes `PDFA_def.ps` (Vorlage für die pdfmark-Anweisungen, die
den ISO-Standard erfüllen) sowie ein sRGB-ICC-Profil bereits selbst mit
(`/usr/share/ghostscript/<version>/lib/PDFA_def.ps` bzw.
`/usr/share/color/icc/ghostscript/srgb.icc` auf Debian/Ubuntu-Basis -
`pdfa_logic.py` sucht beide Pfade zur Laufzeit). Da Ghostscript
ohnehin bereits Pflicht-Abhängigkeit ist (Komprimierung), entstehen
dadurch keine zusätzlichen Systemvoraussetzungen. Die Vorlage wird zur
Laufzeit in eine temporäre Kopie geschrieben, in der Profilpfad und
Dokumenttitel eingesetzt werden (Titel wird für PostScript-Sonderzeichen
`\` und `()` escaped, damit auch Dateinamen mit Klammern nicht die
Konvertierung brechen).

**Architektur**: `pdfa_logic.py` (75 Zeilen: Verfügbarkeitsprüfung,
Vorlagen-/Profilsuche, Ghostscript-Aufruf, keine UI) und `pdfa_ui.py`
(87 Zeilen: ein Panel mit Erklärtext und einem Knopf; zeigt bei
fehlenden Voraussetzungen einen Warnhinweis statt der Bedienelemente -
gleiches Muster wie `compress_ui.py` bei fehlendem Ghostscript).
Einbindung in `app_window.py` und neue Kachel in `home_view.py`. Alle
Texte in `language.py` für DE und EN ergänzt - Sync-Check bestätigt
identische Schlüsselmenge (102 Schlüssel je Sprache). README.md-Hinweis
zur Ghostscript-Abhängigkeit um die PDF/A-Nutzung ergänzt.

**Tests**: Da PDF/A-Konformität eine überprüfbare, objektive Eigenschaft
ist, wurde diesmal nicht nur "läuft ohne Fehler" getestet, sondern die
tatsächliche Konformität der Ausgabedatei kontrolliert:
- Ghostscript testweise im Entwicklungscontainer installiert (`apt
  install ghostscript`, Version 10.02.1), um wirklich zu konvertieren
  statt nur den Aufbau des Kommandos zu lesen
- Erfolgreiche Konvertierung eines Testdokuments; Text bleibt lesbar
- XMP-Metadaten der Ausgabedatei geprüft: enthalten exakt
  `pdfaid:part='2'` und `pdfaid:conformance='B'` - die Datei meldet sich
  also tatsächlich als PDF/A-2b, nicht nur "PDF mit ähnlichen Flags"
- Katalog-Objekt der Ausgabedatei geprüft: `/OutputIntents` ist
  strukturell verankert (nicht nur in den Metadaten erwähnt) - damit
  erfüllt die Datei eine der zentralen PDF/A-Anforderungen wirklich
- Robustheitstest mit Sonderzeichen im Dateinamen ("Rechnung
  (Kopie).pdf") - Konvertierung und Titel-Escaping funktionieren korrekt
- GUI-Test unter Xvfb mit echtem `FileManager`: erfolgreicher
  Speicherlauf (PDF/A-Kennzeichnung im Ergebnis erneut bestätigt) sowie
  der Warnhinweis-Pfad bei simulierter Nichtverfügbarkeit (kein Absturz,
  keine Bedienelemente werden aufgebaut)

## -14. Nachtrag: Schritt 5 der Roadmap – Wasserzeichen über das gesamte Dokument

**Umgesetzt**: Neues, vierzehntes Modul "Wasserzeichen". Diagonaler,
halbtransparenter Text (frei wählbare Farbe aus einer 4er-Palette,
Schriftgröße, Transparenz in %, Drehwinkel in Grad) wird auf jede Seite
der aktiven Datei angewendet - Standard-Funktion in allen verglichenen
Programmen (siehe Marktanalyse in Nachtrag -11), bisher nicht
abgedeckt. Technisch über PyMuPDF `page.insert_text()` mit
`morph=(pivot, rotationsmatrix)` gelöst, da `insert_textbox()` nur
90°-Schritte erlaubt, freie Drehwinkel aber ausdrücklich gewünscht
waren. Wie bei den anderen neuen Modulen: Speichern-unter-Dialog statt
Überschreiben des Originals.

**Architektur**: `watermark_logic.py` (45 Zeilen, reine Platzierung/
Rotation, keine UI) und `watermark_ui.py` (127 Zeilen, Panel mit
Text-Feld, Farb-Paletten-Auswahl und drei Schiebereglern). Einbindung
in `app_window.py` und neue Kachel in `home_view.py`. Alle Texte in
`language.py` für DE und EN ergänzt - Sync-Check bestätigt identische
Schlüsselmenge (98 Schlüssel je Sprache).

**Tests**: `py_compile` für alle geänderten/neuen Dateien. Funktionaler
Test der Logik mit echtem PyMuPDF-Dokument: Text auf jeder Seite
vorhanden, per Pixel-Stichprobenzählung (jeder 5. Pixel) bestätigt,
dass tatsächlich nicht-weiße Bildpunkte im erwarteten Umfang
entstehen. Anschließend die gerenderte Seite als PNG visuell mit dem
Bild-Betrachter geprüft (Ergebnis: sauber lesbares, diagonal
gedrehtes, transparentes "ENTWURF"). GUI-Test unter Xvfb mit echtem
`FileManager`: Hinweis bei leerem Text, erfolgreicher Speicherlauf.
Zusätzlich ein zweiter visueller Test **über die tatsächlichen
UI-Regler** (Farbauswahl Rot, 30°-Drehwinkel, angepasste Schriftgröße/
Transparenz) - das gerenderte Ergebnis zeigt exakt die über die
Bedienelemente gewählten Werte.

**Zwischenfall während der Tests**: Ein GUI-Testlauf blieb hängen, weil
`messagebox.showinfo` beim Speichern nicht gemockt war und dadurch ein
reales, unbedienbares Dialogfenster unter Xvfb öffnete. Nach Abbruch
wurden hängende Prozesse bereinigt und der Test mit korrekt gemocktem
`messagebox` wiederholt - lief danach sauber durch. Kein Code-Fehler,
sondern ein Fehler in der Testvorbereitung; für künftige GUI-Tests
festgehalten: `messagebox.showinfo`/`showerror` immer vor dem ersten
Aufruf mocken.

README.md und help_view.py (DE+EN) entsprechend ergänzt.

## -13. Nachtrag: Schritt 4 der Roadmap – Kopf-/Fußzeile mit automatischer Seitennummerierung

**Umgesetzt**: Neues, dreizehntes Modul "Kopf-/Fußzeile". Freier Text
mit Platzhaltern (`{seite}`, `{seiten}`, `{datum}`, `{aktenzeichen}`)
für Kopf- und/oder Fußzeile, je mit eigener Ausrichtung (links/mitte/
rechts) und gemeinsamer Schriftgröße, wird auf jede Seite der aktiven
Datei angewendet. Optional: fortlaufende Aktenzeichen-Nummerierung
(Präfix, Startwert, Stellenzahl mit führenden Nullen) - Standard-
Büroaufgabe bei Verträgen/Rechnungen/Schriftsätzen, die in keinem der
bisherigen Module abgedeckt war (siehe Marktanalyse in Nachtrag -11).
Wie bei Anmerkungen/Lesezeichen wird beim Speichern eine neue Datei
angelegt statt das Original zu überschreiben.

**Architektur**: `header_footer_logic.py` (73 Zeilen, reine
Platzhalter-Ersetzung und Platzierung über PyMuPDF
`page.insert_textbox()`, keine UI) und `header_footer_ui.py`
(151 Zeilen, Panel mit zwei Text-Zeilen samt Ausrichtung, Schriftgrößen-
Regler und einblendbarem Aktenzeichen-Bereich - liegt aus denselben
Gründen leicht über der 100-Zeilen-Richtlinie wie die anderen Panel-
Dateien mit mehreren zusammenhängenden Eingabefeldern). Einbindung in
`app_window.py` und neue Kachel in `home_view.py`. Alle Texte in
`language.py` für DE und EN ergänzt - Sync-Check bestätigt identische
Schlüsselmenge in beiden Sprachen (89 Schlüssel).

**Tests**: `py_compile` für alle geänderten/neuen Dateien. Funktionaler
Test der Logik mit echtem PyMuPDF-Dokument: Platzhalter korrekt
ersetzt, Aktenzeichen fortlaufend mit Präfix/Polsterung über mehrere
Seiten (Textextraktion der Ergebnisdatei bestätigt exakten Wortlaut je
Seite). Zusätzlich vollstaendiger GUI-Test unter Xvfb mit echtem
`FileManager`: Hinweis bei leerer Eingabe, erfolgreiches Speichern mit
Kopf-/Fußzeile und Aktenzeichen (Ergebnis erneut per Textextraktion
gegengeprüft), sowie Fehlermeldung bei nicht-numerischer
Aktenzeichen-Startnummer.

README.md und help_view.py (DE+EN) entsprechend ergänzt.

## -12. Nachtrag: Schritt 3 der Roadmap – Lesezeichen/Inhaltsverzeichnis-Editor

**Umgesetzt**: Neues, zwölftes Modul "Lesezeichen". Zeigt das
vorhandene Inhaltsverzeichnis der aktiven Datei als bearbeitbare Liste
(Ebene, Titel, Zielseite), erlaubt Hinzufügen/Löschen von Einträgen und
springt per Klick auf 🔎 direkt zur Zielseite in der gemeinsamen
Dokumentenansicht. Seitenzahlen werden vor dem Speichern gegen die
tatsächliche Seitenzahl der Datei validiert; beim Speichern eines
leeren Eintrags-Satzes fragt eine Sicherheitsabfrage nach, bevor ein
vorhandenes Inhaltsverzeichnis gelöscht wird. Wie beim Anmerkungen- und
Redaction-Modul wird beim Speichern eine neue Datei angelegt statt das
Original zu überschreiben (Speichern-unter-Dialog).

**Architektur**: `outline_logic.py` (49 Zeilen, reines Lesen/Schreiben
über PyMuPDF `get_toc()`/`set_toc()`, keine UI), `outline_row.py`
(70 Zeilen, eine einzelne Editor-Zeile als eigene Komponente) und
`outline_ui.py` (150 Zeilen, Panel-Aufbau, Laden/Speichern/Validierung
- liegt aus denselben Gründen wie die Anmerkungen-Dateien leicht über
der 100-Zeilen-Richtlinie: zusammenhängende Lade-/Speicherlogik für
eine dynamische Liste). `document_view.py` um `set_page_index()`
ergänzt (kleine, wiederverwendbare Navigations-Methode, 0-basiert).
Einbindung in `app_window.py` (neuer Modul-Eintrag) und `home_view.py`
(neue Kachel). Alle neuen Texte in `language.py` für DE und EN
ergänzt - programmatisch geprüft, dass beide Sprachen exakt dieselbe
Schlüsselmenge enthalten (77 Schlüssel).

**Tests**: `py_compile` für alle geänderten/neuen Dateien. Da eine
Listen-UI mit dynamischen Zeilen, Callbacks und einem Datei-Dialog
zu fehleranfällig ist, um sie nur per Code-Lesen zu verifizieren, wurde
zusätzlich `python3-tk` nachinstalliert und die komplette Ansicht unter
Xvfb (virtuelle Anzeige) mit einer echten `customtkinter`-Instanz
durchgespielt:
- `OutlineRow` isoliert: Werte auslesen, Sprung-Callback, Löschen-Callback
- `OutlineView` mit echtem `FileManager` und echter `DocumentView`:
  TOC einer leeren Datei laden (keine Zeilen), Eintrag über die aktuell
  sichtbare Seite hinzufügen, Sprung zu einer Zielseite (bestätigt über
  `document_view.get_page_index()`), Validierungsfehler bei einer
  Seitenzahl außerhalb des gültigen Bereichs
- Vollständiger Speicher-Round-Trip: zwei Einträge anlegen, speichern
  (Dialog gemockt), gespeicherte Datei mit `outline_logic.read_outline()`
  gegenprüfen, anschließend dieselbe Datei in einer zweiten, frischen
  `OutlineView`-Instanz erneut öffnen - Einträge kommen unverändert
  zurück

README.md, help_view.py (DE+EN) und home_view.py entsprechend ergänzt.

## -11. Nachtrag: Internetrecherche vergleichbarer PDF-Programme + Schritt 2 der Roadmap: Unterschrift zeichnen & speichern

**Anlass**: Wunsch nach einer Marktanalyse vergleichbarer PDF-Programme
(Adobe Acrobat, Foxit PDF Editor, PDF-XChange Editor, Nitro, Master PDF
Editor, Qoppa PDF Studio, Okular), um sinnvolle Ergänzungen für
anspruchsvollere Büroaufgaben zu finden – ausdrücklich ohne unnötigen
Funktions-Wildwuchs.

**Ergebnis der Recherche – empfohlen und in die Roadmap aufgenommen**:
Lesezeichen/Inhaltsverzeichnis-Editor, Kopf-/Fußzeile mit automatischer
Seitennummerierung (optional Aktenzeichen-Nummerierung), Wasserzeichen
über das gesamte Dokument, PDF/A-Konvertierung (Langzeitarchivierung,
z. B. GoBD-konforme Rechnungsablage; nutzt das bereits vorhandene
Ghostscript), sowie – auf ausdrücklichen Wunsch trotz höheren Aufwands –
eine echte kryptographische digitale Signatur (mit Zertifikat, nicht
nur visueller Stempel).

**Bewusst verworfen**: Text direkt im PDF bearbeiten (in-place) – selbst
Premium-Tools haben damit Probleme mit Schriftart-Matching und
Layout-Verschiebung, hohes Risiko für kaputte Dokumente im Verhältnis
zum Nutzen. Messwerkzeuge – Ingenieur-/CAD-Zielgruppe, kein
Büroalltags-Werkzeug. Dateianhänge verwalten und
JavaScript/aktive Inhalte – Nischenfunktion bzw. Sicherheitsrisiko ohne
echten Büro-Nutzen.

**Neue Gesamt-Reihenfolge** (offene Firefox-Punkte und neue
Büro-Funktionen gemeinsam sortiert, nach Abhängigkeit/Komplexität):
1. ~~Radierer + Stiftfarbe/-stärke~~ (siehe Nachtrag -10)
2. Unterschrift zeichnen & als Stempel speichern (dieser Nachtrag)
3. Lesezeichen/Inhaltsverzeichnis-Editor
4. Kopf-/Fußzeile mit automatischer Seitennummerierung
5. Wasserzeichen über gesamtes Dokument
6. PDF/A-Konvertierung
7. Volltextsuche im Dokument
8. Seiten per Drag & Drop neu anordnen
9. Digitale kryptographische Signatur (Zertifikat)

**Umgesetzt (dieser Nachtrag)**: Fünftes Werkzeug "Unterschrift" im
Anmerkungen-Modul. Erster Klick ohne gespeicherte Unterschrift öffnet
ein modales Zeichenfenster (`signature_pad.py`, Maus-Freihandzeichnung
auf `tkinter.Canvas`); beim Bestätigen wird daraus über Pillow ein
transparentes PNG gerendert (`signature_logic.py`) und dauerhaft unter
`~/.config/pdf-skriptor/signatur.png` gespeichert – genau wie die
übrigen Einstellungen in `settings.py`. Danach fügt jeder Klick im
Dokument die gespeicherte Unterschrift als Bild ein
(`page.insert_image`), ohne erneutes Zeichnen. Ein Button "Unterschrift
(neu) zeichnen" erlaubt jederzeit eine Ersetzung.

**Architektur**: Keine neue Abhängigkeit – Pillow und PyMuPDF sind
bereits Teil von `requirements.txt`. Zwei neue Dateien:
`signature_logic.py` (70 Zeilen, reines Rendering/Speichern/Einfügen,
kein UI, gut isoliert testbar) und `signature_pad.py` (95 Zeilen,
Zeichen-Dialog). `annotate_interaction.py` um den Fall "signature"
erweitert (140 Zeilen); `annotate_ui.py` um Werkzeug-Eintrag und
Neu-zeichnen-Button ergänzt (173 Zeilen). Beide liegen weiterhin über
der "idealerweise 100 Zeilen"-Vorgabe aus demselben Grund wie in
Nachtrag -10 (zusammenhängende Maus-/Zeichenlogik).

**Tests**: `py_compile` für alle geänderten/neuen Dateien. Funktionaler
Test mit echtem PyMuPDF-Dokument und Pillow: Striche rendern (Bildgröße
korrekt), Datei speichern, `load_signature_path()` liefert vorher
`None`/danach den Pfad, `insert_signature()` fügt tatsächlich ein Bild
in die Zielseite ein (`page.get_images()` bestätigt).

README.md, help_view.py (DE+EN) und home_view.py entsprechend ergänzt.

## -10. Nachtrag: Firefox-PDF-Editor als Vorbild – Schritt 1: Radierer + Stiftfarbe/-stärke

**Anlass**: Wunsch, den Funktionsumfang mit dem in Firefox eingebauten
PDF-Editor (pdf.js) abzugleichen. Ergebnis des Abgleichs: Firefox bietet
zusätzlich (1) Radierer für einzelne Anmerkungen, (2) frei wählbare
Stift-Farbe/-Stärke statt fester Werte, (3) Unterschrift zeichnen &
wiederverwenden, (4) Volltextsuche mit Trefferhervorhebung, (5) Seiten
per Drag & Drop neu anordnen. In Rücksprache priorisiert: alle fünf,
in dieser Reihenfolge (aufeinander aufbauend – (1)+(2) zuerst, da sie
dieselben Dateien betreffen und die Grundlage für (3) bilden).

**Umgesetzt (dieser Nachtrag)**: Radierer-Werkzeug (Klick auf eine
vorhandene Anmerkung entfernt genau diese – Suche über
`page.annots()` + `rect.contains(punkt)`, dann `page.delete_annot()`)
sowie frei wählbare Stift-Farbe (5er-Palette) und -Stärke (Schieberegler
1–8) für Freihand/Hervorhebung statt der bisher fest codierten Werte.

**Architektur**: `annotate_ui.py` war mit den neuen Bedienelementen auf
237 Zeilen gewachsen – zur Einhaltung der 100-Zeilen-Vorgabe in drei
Dateien aufgeteilt: `annotate_ui.py` (152 Zeilen, nur Panel-Aufbau),
`annotate_interaction.py` (neu, 121 Zeilen, sämtliche Maus-Interaktion
auf der Dokumentenansicht – Zeichnen/Hervorheben/Stempeln/Radieren),
`annotate_style.py` (neu, 71 Zeilen, Farb-/Stärke-Auswahl-Widget,
bewusst wiederverwendbar für die geplante Unterschriftenfunktion).
`annotate_logic.py` um `delete_annot_at_point()` erweitert und
`add_ink_stroke()` um einen `width`-Parameter ergänzt.

Zusätzlich Werkzeugnamen ("Freihand", "Hervorhebung", "Stempel",
"Radierer") und alle neuen Hinweistexte in `language.py` für DE/EN
ergänzt – vorher waren die Werkzeugnamen im Segmented-Button fest auf
Deutsch codiert und wurden bei Sprachwechsel nicht übersetzt; das ist
mit dieser Änderung miterledigt.

**Tests**: `py_compile` für alle vier geänderten/neuen Dateien.
Funktionaler Test der neuen Logik mit echtem PyMuPDF-Dokument (Strich
mit Farbe/Stärke hinzufügen, Hervorhebung per Klick-Punkt gezielt
entfernen, Klick ins Leere liefert korrekt "nichts gefunden"). Zusätzlich
`AnnotationInteraction` isoliert mit Fake-Dokumentenansicht durchgespielt
(Zeichnen → Speichern → Radieren → Anmerkung tatsächlich weg).

**Ausblick**: Als Nächstes gemäß Priorisierung: Unterschrift zeichnen &
als Stempel speichern (Schritt 2), Volltextsuche im Dokument (Schritt 3),
Seiten per Drag & Drop neu anordnen (Schritt 4).

## -9. Nachtrag: Menü-Scroll repariert, Menü-Knopf-Position, Panel bis zum oberen Rand

**Gemeldete Fehler**: (1) Im Kachel-Menü funktionierte das Scrollen
nicht mehr. (2) Der Menü-Knopf saß zu weit von dem Bereich entfernt,
den er steuert. (3) Das Menü sollte sich bis zum oberen Fensterrand
erstrecken.

**Ursache (1) - systemweites Problem, nicht nur im Menü**: Sieben
Ansichten (`home_view.py`, `about_view.py`, `compare_ui.py`,
`forms_ui.py`, `help_view.py`, `pipeline_ui.py`,
`redact_search_ui.py`) banden ihr Mausrad-Scrollen noch ueber das
alte, unzuverlaessige Muster: eine **dauerhafte** `bind_all()`-Bindung
direkt beim Erstellen der Ansicht. Da `bind_all()` global fuer die
gesamte Anwendung gilt, ueberschreibt die zuletzt aufgerufene Ansicht
automatisch die Bindung aller zuvor besuchten Ansichten - danach
scrollt nur noch die zuletzt besuchte Ansicht, alle anderen (auch
wenn sie erneut sichtbar sind) nicht mehr. `workbench_view.py` und
`document_view.py` hatten dieses Problem in einem frueheren Durchgang
bereits durch ein `<Enter>`/`<Leave>`-Muster geloest (Bindung nur
aktiv, waehrend die Maus tatsaechlich ueber dem Bereich ist); die
uebrigen sieben Ansichten hatten dieses Muster noch nicht.

**Fix**: Neues gemeinsames Hilfsmodul `scroll_helpers.py` mit
`bind_mousewheel_scroll()`, das dieses zuverlaessige Muster kapselt.
Alle sieben betroffenen Ansichten nutzen jetzt diese gemeinsame
Funktion statt einer eigenen (fehlerhaften) Kopie - behebt nicht nur
das gemeldete Menü-Problem, sondern dieselbe latente Fehlerklasse in
der gesamten Anwendung auf einen Schlag.

**Fix (2) und (3) - gemeinsam geloest durch Layout-Umbau**: Die rechte
Spalte (Menü/Werkzeug-Bereich) erstreckt sich jetzt ueber die
**gesamte Fensterhoehe** als eigene, von der Werkbank unabhaengige
Spalte - nicht mehr erst unterhalb der Werkbank beginnend. Der
"☰ Menü"-Knopf sitzt jetzt direkt am oberen Rand dieser Spalte, in
unmittelbarer Naehe zu dem Bereich, den er oeffnet - vorher steckte er
stattdessen weit entfernt oben links in der Werkbank. Neues Layout in
`app_window.py`: Werkbank + Dokumentenansicht bilden zusammen die
linke/mittlere Spalte (untereinander gestapelt), waehrend die rechte
Spalte (Menü-Knopf-Kopfzeile + Werkzeug-Inhalt) als eigenstaendige,
vollhohe Spalte danaben liegt. `workbench_view.py` dadurch wieder
etwas einfacher (kein `on_menu`-Parameter/Knopf mehr noetig).

**Verifiziert**: Nicht nur "kein Fehler", sondern die tatsaechliche
Scrollposition (`canvas.yview()`) wurde vor und nach einem simulierten
Mausrad-Ereignis verglichen - sowohl direkt nach dem Start als auch
(entscheidend) **nachdem** mehrere andere Ansichten besucht wurden,
die frueher die globale Bindung uebernommen und das Menü-Scrollen
damit lahmgelegt haetten. Zusaetzlich vollstaendiger Regressionstest
aller 15 Module, Anmerkungen-Werkzeug und Sprachwechsel weiterhin
erfolgreich. Per Screenshot visuell bestaetigt: rechte Spalte beginnt
jetzt buendig am oberen Fensterrand, Menü-Knopf sitzt direkt darueber.

## -8. Nachtrag: Zwei Menüs zu einem vereinheitlicht

**Wunsch**: Die linke Icon-Seitenleiste und das rechte Kachel-Menü der
Startseite empfanden sich als zwei getrennte Navigationen. Alle Ziele
der linken Leiste sollten ins rechte Kachel-Menü wandern, die Werkbank
verkleinert werden, damit das rechte Menü mehr vertikalen Platz
bekommt, und die linke Leiste danach entfernt werden.

**Umsetzung**:
- `sidebar_nav.py` **gelöscht** - keine Referenzen mehr vorhanden.
- `home_view.py`: neue dritte Kachel-Sektion "Weitere" mit
  Einstellungen, Hilfe und Über-dieses-Programm - damit sind
  ausnahmslos alle vorherigen Ziele der linken Leiste über das
  Kachel-Menü erreichbar.
- `workbench_view.py` deutlich kompakter gestaltet: Chip-Bereich zeigt
  jetzt eine statt zwei Zeilen (Höhe 46px statt 100px), kleinere
  Abstände und Chip-Höhe (32px statt 36px) - dadurch bleibt für die
  Dokumentenansicht/Werkzeug-Spalte darunter mehr Platz.
- Neuer **"☰ Menü"-Knopf** in der Werkbank (immer sichtbar, links vom
  Dateien-Status) ersetzt die Navigationsfunktion der frueheren linken
  Leiste - ein Klick fuehrt von ueberall zur Kachel-Uebersicht
  zurueck, unabhaengig davon, welches Werkzeug gerade aktiv ist.
- `app_window.py`: Spalte 0 (Sidebar) entfernt, Fensterlayout beginnt
  jetzt direkt mit dem Inhaltsbereich; `WorkbenchView` erhaelt einen
  neuen `on_menu`-Callback (`lambda: self.show_module("home")`).

**Verifiziert**: Fenster besitzt nachweislich kein Sidebar-Attribut
mehr; alle 15 vorherigen Navigationsziele (inkl. der neu
hinzugekommenen Einstellungen/Hilfe/Über-Kacheln) weiterhin über das
Kachel-Menü erreichbar, Dokumentenansicht bleibt dabei unveraendert
sichtbar; der neue Menü-Knopf fuehrt von einem beliebigen Werkzeug
(getestet mit Sicherheit) zuverlaessig zur Startseite zurueck;
Anmerkungen-Werkzeug funktioniert nach dem Umbau unveraendert direkt
auf der Dokumentenansicht; Sprachwechsel uebersetzt auch den neuen
Menü-Knopf korrekt.

## -7. Nachtrag: OCR erzeugte leeres Dokument + Prüfung von analyse.sh

**Gemeldeter Fehler**: Beim "Durchsuchbar machen" (OCR) war das
erzeugte Dokument leer.

**Untersuchung**: Mehrere realistische Szenarien gezielt nachgebaut und
geprüft, ob die sichtbare Seite (nicht nur der erkannte Text) im
Ergebnis erhalten bleibt: ein scan-ähnliches Bild-PDF, ein PDF mit
echtem Vektortext, sowie ein dreiseitiges Scan-Dokument - in allen drei
Fällen blieb der sichtbare Inhalt korrekt erhalten. Die ocrmypdf-
Verarbeitung selbst funktioniert also grundsätzlich korrekt; das
Problem lässt sich ohne die exakte Datei des Nutzers nicht 1:1
nachstellen.

**Wahrscheinlichste Ursache und Fix**: Der bisherige Timeout von
5 Minuten war fest und unabhängig von der Seitenzahl - bei größeren
oder mehrseitigen Scans (wahrscheinliches reales Szenario, siehe
"Gescanntes Dokument.pdf" aus einem früheren `analyse.sh`-Lauf) kann
die Verarbeitung länger dauern. Wird der Prozess durch den Timeout
mitten im Schreiben abgebrochen, bleibt eine leere oder unvollständige
Datei auf der Festplatte zurück - `ocrmypdf` selbst hatte in diesem
Fall aber keinen Rückgabecode ungleich 0 gemeldet, weshalb die
Anwendung fälschlich "Erfolg" anzeigte.

Behoben in `ocr_logic.py`:
- **Skalierender Timeout**: 5 Minuten Grundzeit plus 1 Minute pro Seite
  der Eingabedatei, statt eines festen Werts.
- **Ergebnis-Validierung nach dem Lauf**: Auch bei Rückgabecode 0 wird
  jetzt geprüft, ob die Ausgabedatei existiert, nicht nahezu leer ist,
  sich als PDF öffnen lässt und mindestens so viele Seiten wie das
  Original hat. Schlägt das fehl, wird die unvollständige Datei
  entfernt (damit keine leere Datei liegen bleibt) und ein konkreter,
  verständlicher Fehler zurückgegeben statt eines stillen
  Fehlschlags.
- `ocr_ui.py` zeigt jetzt die konkrete Fehlermeldung an statt eines
  generischen Textes.

**Verifiziert**:
- Keine Regression: alle drei zuvor erfolgreichen Testfälle (Scan-Bild,
  Vektortext, dreiseitiges Dokument) funktionieren nach der Änderung
  weiterhin fehlerfrei.
- Fehlerfall gezielt nachgebaut (ocrmypdf-Aufruf simuliert, der
  Rückgabecode 0 liefert, aber eine 0-Byte-Datei hinterlässt) - von der
  Validierung korrekt erkannt, mit klarer Meldung, und die fehlerhafte
  Datei wurde automatisch entfernt.
- Zweiter Fehlerfall nachgebaut (Ausgabedatei mit nur 1 von 3 erwarteten
  Seiten, simuliert einen mitten im Schreiben abgebrochenen Vorgang) -
  ebenfalls korrekt erkannt und gemeldet.

**Prüfung von `analyse.sh`**: Die Kernprüfungen (Systemabhängigkeiten
inkl. `tkinterdnd2`, Einstellungen, Ausgabedateien, Fehler-Log) sind
weiterhin aktuell, keine strukturellen Anpassungen nötig - das
Einstellungs-Schema (`language`, `appearance_mode`, `output_dir`,
`last_used_module`) hat sich nicht geändert. Ergänzt wurde eine neue
**Speicherplatz-Prüfung** (freier Platz in `/tmp` und im
Ausgabeordner), da knapper Speicher in `/tmp` - wo `ocrmypdf` seine
Zwischendateien ablegt - eine weitere plausible Ursache für genau
diese Art von stillem OCR-Fehlschlag ist und dem Nutzer beim
Selbst-Diagnostizieren hilft.

## -6. Nachtrag: Dokumentenansicht scrollbar gemacht

**Gemeldeter Fehler**: Nach dem Layout-Umbau ließ sich das Dokument in
der zentralen Ansicht nicht scrollen.

**Ursache**: Die Canvas wurde bei jedem Rendern per
`canvas.config(width=..., height=...)` exakt auf die Pixelgröße der
gerenderten Seite gezwungen. Bei Seiten, die größer als der
verfügbare Platz waren (kleineres Fenster, hoher Zoom, große
Papierformate), wuchs die Canvas dadurch über den sichtbaren Bereich
hinaus - ohne jede Scroll-Möglichkeit blieb der Rest der Seite
schlicht unerreichbar.

**Fix**: Die Canvas-Widgetgröße richtet sich jetzt nach dem
verfügbaren Platz (Grid-Layout), während nur die `scrollregion`
unabhängig davon auf die tatsächliche Seitengröße gesetzt wird. Dazu
echte `tk.Scrollbar`-Leisten (vertikal und horizontal) ergänzt, sowie
Mausrad-Scrollen (Umschalt-Taste für horizontal) nach demselben
Enter/Leave-Muster wie beim Werkbank-Fix.

**Wichtige Folgekorrektur**: Da die Ansicht jetzt tatsächlich gescrollt
werden kann, waren die bisherigen Klick-Koordinaten in Anmerkungen und
Redaction (manuell) nicht mehr korrekt - `event.x`/`event.y` liefern
nur die bildschirmrelative Position innerhalb des sichtbaren
Canvas-Ausschnitts, nicht die tatsächliche Position im
Gesamtdokument. `document_view.py` bietet dafür jetzt
`canvas_x()`/`canvas_y()` (nutzen intern `canvas.canvasx()`/
`canvas.canvasy()`), die beide interaktiven Werkzeuge jetzt statt der
rohen Ereignis-Koordinaten verwenden.

**Verifiziert**:
- Mit einer eigens erstellten übergroßen Testseite (1200×1600pt):
  `scrollregion` (1560×2080px bei Zoom 1.3) tatsächlich größer als die
  Canvas-Widgetgröße bestätigt; Mausrad-Scroll veränderte die
  Scrollposition nachweislich.
- Koordinaten-Korrektur bewiesen, nicht nur behauptet: derselbe
  Bildschirm-Klick (50, 50) wurde einmal ohne und einmal mit
  Scroll-Versatz ausgeführt und ergab wie erwartet unterschiedliche
  PDF-Koordinaten (Differenz entsprach exakt dem Scroll-Versatz
  geteilt durch den Zoomfaktor) - sowohl für Anmerkungen (Freihand)
  als auch für Redaction (manuell markierter Bereich).
- Vollständiger Regressionstest aller 15 Module nach der Änderung
  weiterhin erfolgreich.

## -5. Nachtrag: Komplettes GUI-Redesign nach Schreibprogramm-Vorbild

**Wunsch**: Der bisherige Aufbau (Werkzeug-Inhalt nimmt die Hauptflaeche
ein, separate schmale Vorschau-Spalte rechts) sollte durch ein Konzept
wie bei einem Schreibprogramm ersetzt werden: Das Dokument bleibt
permanent sichtbar, egal welche Funktion aufgerufen wird. Die separate
Vorschau entfaellt dadurch.

**Umsetzung - grundlegend neue Architektur**:

- **`document_view.py`** (ersetzt `preview_pane.py`): Die permanente,
  zentrale Dokumentenansicht. Liegt als direktes Geschwister-Widget
  neben der Werkzeug-Seitenleiste, nicht innerhalb des
  Werkzeug-Containers - dadurch bleibt sie beim Werkzeugwechsel
  physisch unberuehrt, statt neu aufgebaut oder ausgeblendet zu
  werden. Bietet zusaetzlich eine Schnittstelle fuer interaktive
  Werkzeuge: `get_document()`, `get_page_index()`, `get_zoom()`,
  `get_canvas()`, `bind_canvas()`/`unbind_canvas()`,
  `set_overlay_callback()`/`clear_overlay_callback()`, `refresh()`.
- **Neues Seitenverhaeltnis**: Sidebar (schmal, links) │ Dokumentenansicht
  (zentral, nimmt den meisten Platz) │ Werkzeug-Seitenleiste (rechts,
  fest 380px breit, entspricht dem fruaeheren "module_container").
  Fenstermindestbreite unveraendert bei 1280px.
- **Anmerkungen und Redaction (manuell) zeichnen jetzt direkt auf der
  gemeinsamen Dokumentenansicht** statt eine eigene, doppelte
  Seitendarstellung mitzubringen. Sie binden ihre Maus-Handler nur,
  waehrend sie aktiv sind, und loesen sie beim Wechsel zu einem
  anderen Werkzeug wieder - siehe Lifecycle-Abschnitt unten.
- **Alle uebrigen Einzeldatei-Werkzeuge** (Organisieren, Metadaten,
  Komprimieren, Sicherheit, Formulare, OCR, Redaction-Suche,
  Konvertierung) blieben in ihrer Kernlogik unveraendert, wurden aber
  auf die neue, schmalere 380px-Spalte angepasst (siehe
  "Breitenanpassungen" unten).
- **Startseite** (`home_view.py`) auf einspaltiges Kachel-Layout mit
  kleinerem Avatar umgestellt, da sie jetzt ebenfalls in der schmalen
  Seitenleiste erscheint statt die Hauptflaeche einzunehmen.

**Wichtiger Bug waehrend der Entwicklung gefunden und behoben -
Lifecycle-Problem bei interaktiven Werkzeugen**: Der erste Ansatz band
`<Map>`/`<Unmap>`-Tk-Ereignisse an Anmerkungen/Redaction-manuell, um zu
erkennen, wann sie sichtbar/unsichtbar werden. Das schlug fehl: Custom
Tkinter-Widgets (Buttons, Segmented Buttons) zeichnen sich intern ueber
eigene Canvas-Elemente, deren Map-Ereignisse durch Tks
Bindtag-Mechanismus auch beim Eltern-Widget ankommen koennen - jedoch
mit `event.widget`, das auf das interne Kind-Element zeigt, nicht auf
das eigentliche Werkzeug-Panel. Ein Identitaets- wie auch ein
Pfad-Vergleich (`event.widget is self` / `str(event.widget) ==
str(self)`) halfen nicht zuverlaessig weiter.

**Fix**: Statt auf Tk-Ereignisse zu vertrauen, ruft `app_window.py`
(bzw. `redact_ui.py` fuer den internen Modus-Wechsel innerhalb von
Redaction) jetzt explizite `on_shown()`/`on_hidden()`-Methoden direkt
auf - deterministisch und unabhaengig von Tk-internen
Bindtag-Details. `RedactView` leitet diese Aufrufe an das jeweils
aktive Unter-Werkzeug weiter, damit auch ein Wechsel zwischen den
zwei Redaction-Modi (nicht nur zwischen Top-Level-Werkzeugen) die
Dokumentenansicht sauber bindet/loest.

**Verifiziert**:
- Alle 15 Module vor UND nach dem Laden einer Datei durchgeklickt -
  die Dokumentenansicht zeigte durchgehend denselben Dateinamen, ohne
  sich je zu veraendern.
- Ein echter Freihand-Strich wurde per synthetischem
  `<ButtonPress-1>`/`<B1-Motion>`/`<ButtonRelease-1>` direkt auf der
  Dokumentenansicht-Canvas erzeugt, waehrend das Anmerkungen-Werkzeug
  aktiv war - die Anmerkung wurde korrekt registriert.
- Derselbe Ablauf fuer einen Redaction-Bereich (manueller Modus) -
  korrekt vorgemerkt.
- Nach Wechsel zu einem anderen Werkzeug war die Canvas-Bindung
  nachweislich wieder geloest (`canvas.bind(...) == ''`), auch wenn
  vorher zwischen den beiden Redaction-Untermodi gewechselt wurde.
- Wechsel der aktiven Datei aktualisiert die Dokumentenansicht
  weiterhin korrekt; Sprachwechsel baut Werkbank und Dokumentenansicht
  korrekt neu auf (`retranslate()`).
- Per Screenshot visuell geprueft: Metadaten-, Vergleichs- und
  Startseiten-Panel in der neuen 380px-Spalte, Dokumentenansicht im
  Zentrum.

**Breitenanpassungen fuer die schmalere 380px-Werkzeugspalte**:
- `wraplength`-Werte in Hilfe, Ueber, Komprimieren, OCR,
  Organisieren/Zusammenfuegen und Vergleich von 560-600px auf 300px
  reduziert.
- `about_view.py`: Avatar ueber statt neben dem Titeltext, verkleinert
  auf 64×64px; Zeilen-Label-Breite von 90 auf 70px reduziert.
- `security_ui.py`: Die beiden Rechte-Checkboxen stehen jetzt
  untereinander statt nebeneinander; Passwort-Label ueber statt neben
  dem Eingabefeld.
- `forms_ui.py`: Formularfeld-Name steht jetzt ueber statt neben dem
  Eingabefeld (feste 180px-Spalte haette bei langen PDF-Feldnamen zu
  wenig Platz fuer die Eingabe gelassen).
- `pipeline_ui.py`: Ordner-Auswahlbutton steht jetzt ueber statt neben
  dem (ggf. langen) Pfadtext, der jetzt umbrechen kann.
- `compare_ui.py`: "Datei A"/"Datei B"-Auswahl steht jetzt
  untereinander statt nebeneinander mit Pfeil-Symbol dazwischen.

## -4. Nachtrag: Werkbank-Scrollen tatsächlich repariert + klareres Layout

**Gemeldeter Fehler**: Die im vorherigen Durchgang eingebaute
Scrollfunktion der Werkbank-Chips funktionierte in der Praxis nicht.

**Ursache**: Der vorherige Fix band das Mausrad-Ereignis einzeln an
jeden Chip (`CTkFrame`/`CTkButton`). CustomTkinter-Buttons zeichnen
sich intern über eine eigene Canvas/Label-Struktur - eine direkte
`.bind("<MouseWheel>", ...)`-Bindung auf das äußere Widget-Objekt
erreicht diese innere Struktur nicht zuverlässig, wodurch das
Mausrad-Ereignis nie bei unserem Handler ankam.

**Fix**: Umgestellt auf das dafür uebliche, robuste Muster:
`<Enter>`/`<Leave>`-Bindungen auf den Chip-Bereich selbst setzen bei
Betreten eine **globale** Mausrad-Bindung (`bind_all`) und entfernen
sie beim Verlassen wieder. Da Enter/Leave-Ereignisse beim Wechsel
zwischen Kind-Widgets innerhalb desselben Containers nicht erneut
ausgelöst werden, genügt eine Bindung auf den äußeren Container - das
Scrollen funktioniert dann zuverlässig, egal über welchem
Kind-Widget (Chip-Name, "×"-Button, Zwischenraum) sich die Maus
befindet.

**Verifiziert** (nicht nur "kein Fehler", sondern tatsächliche
Wirkung): Ein echtes `<MouseWheel>`-Ereignis wurde gezielt auf einem
tief verschachtelten Chip-Button (11. von 15 Dateien) erzeugt und die
Scrollposition (`canvas.yview()`) davor/danach verglichen - sie
änderte sich nachweislich (`0.0` → `0.13`). Zusätzlich geprüft: bei
wenigen Dateien, die vollständig in den sichtbaren Bereich passen,
bleibt die Ansicht korrekt unverändert (kein unnötiges Scrollen).

**Übersichtlicher gestaltet**: Der Chip-Bereich sitzt jetzt in einer
klar umrandeten Karte (heller Hintergrund, dezenter Rahmen), die ihn
optisch von der Werkbank-Kopfzeile abhebt. Die sichtbare Höhe zeigt
exakt zwei vollständige Zeilen (keine halb abgeschnittene dritte
Zeile mehr), zusätzliche Zeilen sind über den sichtbaren
Scrollbalken oder das Mausrad erreichbar. Chip-Abstand leicht
vergrößert (8px → 10px) für mehr Luft zwischen den Elementen.

## -3. Nachtrag: Werkbank-Scrollfix + echtes Drag & Drop

**Gemeldeter Fehler 1**: Die Ansicht der geladenen Dateien (Werkbank)
war bei vielen Dateien unten abgeschnitten.

**Ursache**: Die Chips lagen in einer einzeiligen, horizontal
scrollenden Leiste mit fester Höhe. Bei mehr Dateien, als in eine
Zeile passten, wurde die Zeile zwar horizontal länger, aber es gab
keine Möglichkeit, vertikal zu scrollen - überzählige Chips waren
schlicht nicht erreichbar.

**Fix**: `workbench_view.py` wurde auf ein umbrechendes Raster
umgebaut. Die Spaltenzahl wird aus der verfügbaren Fensterbreite
berechnet (reagiert auch auf Fenstergrößenänderung über ein
`<Configure>`-Binding) und passt sich automatisch an. Der sichtbare
Bereich ist auf ca. zwei bis drei Zeilen begrenzt; weitere Zeilen sind
per Mausrad oder Scrollbalken erreichbar. Lange Dateinamen werden auf
22 Zeichen gekürzt (mit "…"), damit die Chips eine einheitliche Breite
behalten. Die Mausrad-Bindung erfolgt gezielt auf die Werkbank-Chips
selbst (nicht global via `bind_all`), damit sie nicht von anderen
Ansichten (Hilfe, Formulare, ...), die ihrerseits Mausrad-Bindungen
setzen, überschrieben wird.

Verifiziert mit 15 Testdateien (lange Dateinamen): Raster mit
korrekter Spaltenzahl (3 bei 1280px, 5 bei 1600px Fensterbreite),
Kürzung funktioniert, Scrollen per Mausrad ohne Fehler, per Screenshot
visuell geprüft.

**Gemeldeter Fehler 2**: Die (in der Hilfe erwähnte) Drag & Drop-
Funktion hat nicht funktioniert.

**Ursache**: Drag & Drop war tatsächlich nie implementiert - nur in
Hilfetexten erwähnt und ein ungenutzter Übersetzungsschlüssel
(`drop_files_hint`) vorhanden. CustomTkinter/tkinter bieten von Haus
aus kein systemweites Drag & Drop für Dateien aus dem Dateimanager.

**Fix**: Bibliothek `tkinterdnd2` ergänzt (`requirements.txt`).
`app_window.py` kombiniert jetzt `ctk.CTk` mit
`TkinterDnD.DnDWrapper` (mit automatischem Fallback ohne Absturz,
falls `tkinterdnd2` auf einem System nicht verfügbar sein sollte). Das
gesamte Fenster ist als Ablageziel registriert - PDF-Dateien können
von einem beliebigen Dateimanager aus irgendwo im Fenster fallengelassen
werden, nicht nur exakt auf der Werkbank. Nicht-PDF-Dateien werden
automatisch ignoriert; werden welche ignoriert, informiert ein
Hinweis-Dialog über die Anzahl. Werkbank-Leerzustand und Hilfetexte
wurden an die jetzt tatsächlich funktionierende Funktion angepasst
(vorher stand der Hinweis fälschlich nur bei "Organisieren", gilt aber
für die ganze App).

Verifiziert: Einzeldatei-Drop, Mehrfach-Drop inklusive Dateiname mit
Leerzeichen (Tcl-Klammer-Syntax korrekt geparst über
`self.tk.splitlist()`), gemischter Drop mit einer Nicht-PDF-Datei
(korrekt ignoriert samt Hinweis-Dialog), sowie ein expliziter
Fallback-Test **ohne** installiertes `tkinterdnd2` - die App startet
weiterhin fehlerfrei, nur ohne Drag & Drop. Zusätzlich End-to-End über
das echte `install.sh` getestet (installiert `tkinterdnd2` automatisch
mit) und mit `run.sh` gestartet.

## -2. Nachtrag: Startseite/Dashboard mit Avatar und Begrüßung

**Wunsch**: Eine Art Startseite/Dashboard mit Avatar und kurzen Infos zum
Programmzweck als Begrüßung.

**Umsetzung**: Neue Datei `home_view.py`, als erster Navigationspunkt
("🏠 Start"/"Home") in der Seitenleiste eingehängt und als
Standardansicht beim Programmstart gesetzt (vorher: Organisieren).
Enthält:
- Kopfbereich mit Avatar-Bild (dasselbe wie im "Über"-Tab) und
  Begrüßungstext samt kurzer Erklärung, wofür PDF Skriptor da ist
- Hinweis-Kachel ("Datei oben in der Werkbank hineinziehen, um
  loszulegen")
- Zwei Reihen anklickbarer Schnellzugriffs-Kacheln, gegliedert wie im
  README in "Für den Büroalltag" und "Besondere Funktionen" - ein
  Klick auf eine Kachel springt direkt zum jeweiligen Werkzeug
  (nutzt denselben `show_module()`-Mechanismus wie die Seitenleiste)
- Alle Texte über neue Übersetzungsschlüssel (`nav_home`,
  `home_greeting`, `home_intro`, `home_office_heading`,
  `home_unique_heading`, `home_quick_start`) in Deutsch und Englisch

Verifiziert: App startet auf der Startseite, Kachel-Klick navigiert
korrekt zum Zielmodul, Rücksprung über die Seitenleiste funktioniert,
Sprachwechsel baut die Startseite korrekt neu auf, alle 15
Navigationspunkte (inkl. Startseite) bleiben stabil ansteuerbar. Ein
Screenshot der laufenden Anwendung (per Xvfb + ImageMagick) wurde zur
visuellen Kontrolle des Layouts angefertigt.

## -1. Nachtrag: Persistente Vorschau + Werkbank-Umbau + OCR-Fix

**Wunsch**: Unabhängig davon, welches Werkzeug in der Seitenleiste gewählt
ist, soll rechts immer die PDF-Datei sichtbar sein. Übersichtlichkeit und
schneller Arbeitsablauf standen im Vordergrund; eine Änderung der
Menüführung war ausdrücklich erlaubt.

**Umsetzung - neues Bedienkonzept**:
- **Gemeinsame "aktive Datei"** (`file_manager.py`): Statt dass jedes
  Werkzeug eine eigene Datei-Auswahl (Dropdown) mitbringt, gibt es jetzt
  genau eine aktive Datei für die gesamte Sitzung. Wird eine neue Datei
  geladen, wird sie automatisch aktiv, wenn noch keine gewählt war; wird
  die aktive Datei entfernt, springt die Auswahl automatisch auf die
  nächste verbleibende Datei (oder auf "keine").
- **Werkbank als Datei-Chips** (`workbench_view.py`, komplett neu
  aufgebaut): Alle geladenen Dateien erscheinen als anklickbare,
  horizontal scrollbare "Chips" mit Namen und eigenem "×"-Button zum
  gezielten Entfernen einzelner Dateien. Ein Klick auf einen Chip macht
  die Datei sofort zur aktiven Datei - farblich hervorgehoben.
- **Persistente Vorschau** (`preview_pane.py`, neu): Feste rechte Spalte
  im Hauptfenster, die immer die aktuelle Seite der aktiven Datei zeigt
  (mit Vor-/Zurück-Seitennavigation). Liegt außerhalb des
  Modul-Containers und wird beim Werkzeugwechsel nie neu aufgebaut oder
  ausgeblendet - genau das war der Kern der Anforderung.
- Alle Einzeldatei-Werkzeuge (Organisieren/Trennen/Drehen/Löschen,
  Metadaten, Komprimieren, Sicherheit, Formulare, OCR, Redaction beide
  Modi, Konvertierung, Anmerkungen) wurden von einem eigenen
  Datei-Dropdown auf die gemeinsame aktive Datei umgestellt - erkennbar
  an einer schlichten "📄 Dateiname"-Anzeige statt eines Dropdowns.
  Organisieren/Zusammenfügen bleibt unverändert, da es bewusst mit allen
  geladenen Dateien zugleich arbeitet. Vergleich behält seine zwei
  Dropdowns, da es grundsätzlich zwei Dateien gleichzeitig benötigt.
- Neues Hilfsmodul `file_list_sync.sync_active_file()` kapselt das
  An-/Abmelden bei Aenderungen der aktiven Datei (inkl. sofortigem
  initialem Aufruf beim Erstellen einer Ansicht), analog zum
  bestehenden `sync_file_selector`/`sync_refresh_callback`-Muster.
- Fenstergröße von 1000×680 auf 1280×720 erhöht, um Platz für die neue
  Vorschau-Spalte zu schaffen.

**Verifiziert**: Vollständiger Testlauf - alle 14 Module vor dem Laden
öffnen, Dateien laden, aktive Datei wechseln (Chip-Klick simuliert über
`file_manager.set_active_file()` und direkten Button-`invoke()`),
prüfen dass Vorschau und alle Modul-Labels synchron bleiben, einzelne
Datei über den Chip-"×"-Button entfernen, alle Dateien leeren
(Vorschau zeigt korrekt "Keine Datei ausgewählt"), erneut laden,
Sprachwechsel (Werkbank- und Vorschau-Texte werden korrekt über neue
`retranslate()`-Methoden aktualisiert) - alles erfolgreich.

**Zusätzlich behoben (aus dem mitgeschickten `analyse.sh --full-log`
sichtbaren Fehler)**: `ocrmypdf` brach bei sehr großformatigen/hoch
aufgelösten Scans mit `PIL.Image.DecompressionBombError` ab (Pillows
Standard-Sicherheitsgrenze von 500 Megapixeln). Behoben durch
`--max-image-mpixels 2000` in `ocr_logic.py`. Mit einer eigens
erstellten ~508-Megapixel-Testdatei reproduziert und verifiziert: Der
ursprüngliche Fehler tritt danach nicht mehr auf (bestätigt über
Systemlog). Zusätzlich liefert `run_ocr()` jetzt eine verständliche
Meldung, falls ein OCR-Lauf ohne Fehlertext abbricht (z. B. bei
Speichermangel durch extrem große Bilder).

## 0. Nachtrag: Bugfix "Dateien werden nicht angezeigt" + Ergänzungen

**Gemeldeter Fehler**: Frisch über die Werkbank geladene PDF-Dateien
erschienen in bereits geöffneten Modul-Ansichten (Organisieren,
Metadaten, Komprimieren usw.) nicht in der Datei-Auswahl.

**Ursache**: Jede Modul-Ansicht baute ihre Datei-Auswahlliste nur beim
ersten Öffnen aus `file_manager.get_files()` auf und aktualisierte sie
danach nie wieder - unabhängig davon, ob später neue Dateien geladen
wurden. Reproduziert und verifiziert im Testlauf: Werkbank zeigte "2
Dateien geladen", das Organisieren-Modul weiterhin "Keine Dateien
geladen".

**Fix**: Neues Hilfsmodul `file_list_sync.py` mit `sync_file_selector()`
(für Dropdown-Module) und `sync_refresh_callback()` (für die
Datei-Listenansicht im Zusammenfügen-Werkzeug). Beide registrieren
einen Listener bei der gemeinsamen `file_manager`-Instanz und melden
sich automatisch ab, sobald das zugehörige Widget zerstört wird (über
ein `<Destroy>`-Event-Binding) - dadurch bleiben Datei-Auswahllisten in
allen 13 betroffenen Modul-Dateien synchron, auch wenn die Ansicht vor
dem Laden der Dateien bereits geöffnet war. `file_manager.py` wurde um
`unregister_listener()` ergänzt.

**Zweiter, beim Testen gefundener Folgefehler**: Wurde die bisher
gewählte Datei entfernt (z. B. durch "Liste leeren"), blieb
`_selected_path` in den Modulen intern auf dem alten, nicht mehr
gültigen Pfad stehen, obwohl das Dropdown korrekt "Keine Dateien
geladen" anzeigte. Behoben durch ein `else: self._selected_path = None`
an der jeweiligen Datei-Auswahl-Logik in allen betroffenen Modulen,
inklusive Leerung der zugehörigen Info-Anzeigen (z. B. Seitenzahl in
Organisieren/Löschen und Organisieren/Trennen).

**Verifiziert**: Kompletter Zyklus (alle Module vor dem Laden öffnen →
Dateien laden → prüfen, dass alle Selektoren aktualisiert sind → Liste
leeren → prüfen, dass `_selected_path` überall `None` ist und keine
Abstürze auftreten → erneut laden → prüfen, dass wieder alles korrekt
funktioniert) für alle 11 Module erfolgreich durchlaufen.

**Neu ergänzt**:
- `analyse.sh` - Diagnose-Script nach Vorlage (Systemabhängigkeiten,
  Python-Umgebung, Einstellungen, Ausgabedateien, Fehler-Log)
- `run.sh` - selbstlokalisierendes Start-Skript für den Startmenü-Eintrag
- `pdf-skriptor.desktop` - Startmenü-Eintrag-Vorlage, wird von
  `install.sh` mit dem tatsächlichen Installationspfad befüllt und nach
  `~/.local/share/applications/` kopiert
- `install.sh` legt zusätzlich `fehler.log` an und macht `run.sh` sowie
  `analyse.sh` ausführbar
- Robustheits-Fix in `install.sh`: ein fehlschlagendes `apt update`
  (z. B. durch ein defektes Drittanbieter-Repository) bricht die
  Installation nicht mehr vollständig ab, da die eigentliche
  Paketinstallation meist trotzdem funktioniert
- Robustheits-Fix in `analyse.sh`: die Versionsprüfung der
  Systemwerkzeuge erkennt jetzt korrekt, wenn ein Werkzeug zwar
  installiert ist, sein Aufruf aber fehlschlägt (z. B. durch eine
  defekte Abhängigkeit), statt fälschlich ein grünes Häkchen zu zeigen

## 1. Zielsetzung

PDF Skriptor soll sich bewusst von Standard-Tools (PDF Arranger, PDFtk,
Master PDF Editor) abheben und Funktionen bündeln, die im
Linux-Büroalltag laut Nutzerforen (Reddit r/linux, AskUbuntu,
LinuxQuestions) am häufigsten fehlen.

## 2. Vollständiger Funktionsumfang

| Modul | Backend-Bibliothek | Kategorie |
|---|---|---|
| Organisieren (Merge/Split/Rotate/Delete) | pypdf | Büroalltag |
| Formulare (AcroForm ausfüllen) | pypdf | Büroalltag |
| Metadaten (Einzel + Batch) | pypdf | Büroalltag |
| Komprimierung (mit Größenvergleich) | Ghostscript (Subprozess) | Büroalltag |
| Sicherheit (Passwort + Rechte) | pikepdf/qpdf | Büroalltag |
| Anmerkungen (Freihand/Highlight/Stempel) | PyMuPDF | Büroalltag |
| OCR (durchsuchbare PDFs) | ocrmypdf/Tesseract (Subprozess) | Alleinstellung |
| Vergleich (Text-Diff je Seite) | PyMuPDF + difflib | Alleinstellung |
| Redaction (Suche + manuell, echtes Entfernen) | PyMuPDF | Alleinstellung |
| Konvertierung (Markdown/Text + Tabellenerkennung) | PyMuPDF | Alleinstellung |
| Batch-Pipeline (Werkzeugketten auf Ordnerebene) | kombiniert obige Module | Alleinstellung |

Alle elf Module sind vollständig implementiert und funktionsfähig.

## 3. Architektur-Entscheidungen

- **Trennung UI/Logik**: Jedes Modul besteht aus `_logic.py` (reine,
  GUI-unabhängige Funktionen) und `_ui.py`. Dadurch ließen sich alle
  Backend-Funktionen isoliert mit echten Test-PDFs prüfen, bevor die
  Oberfläche entstand.
- **Aufteilung großer Module**: Organisieren (4 Unter-Werkzeuge) und
  Redaction (2 Modi) sind in eigene UI-Dateien mit schlankem Container
  aufgeteilt, damit keine Datei unübersichtlich groß wird.
  Pipeline-Schritte sind als eigene Komponente (`pipeline_step_row.py`)
  ausgelagert, damit sie sich beliebig oft in der Kette wiederholen
  lässt.
- **Gemeinsame Werkbank**: Alle Module greifen auf dieselbe Dateiliste
  (`file_manager.py`) zu.
- **Alles im selben Fenster**: Modul-Ansichten werden im selben Fenster
  ein-/ausgeblendet. Einzige Ausnahme sind native Dateisystem-Dialoge
  (Öffnen/Speichern/Ordner wählen) – Standard bei jeder Desktop-Anwendung.
- **Hintergrund-Threads für lange Vorgänge**: OCR und Batch-Pipeline
  laufen in einem Hintergrund-Thread mit Fortschrittsanzeige, damit die
  GUI während mehrminütiger Vorgänge nicht einfriert.
- **Seitenansicht per PyMuPDF-Rendering**: Redaction (manueller Modus)
  und Anmerkungen rendern die PDF-Seite als Bild auf einem
  `tkinter.Canvas` und rechnen Mauskoordinaten in PDF-Punkte zurück
  (Zoomfaktor 1.3).

## 4. Abweichung von der 100-Zeilen-Vorgabe

Ein Teil der Dateien liegt über der „idealerweise 100 Zeilen"-Vorgabe
(z. B. `document_view.py` mit 264, `annotate_interaction.py` mit 121
Zeilen). Grund: Canvas-basierte Zeichenwerkzeuge (Redaction manuell,
Anmerkungen) benötigen Mausereignis-Handling, Seiten-Rendering und
Speicherlogik in einem zusammenhängenden Ablauf; eine weitere
Aufteilung hätte den Lesefluss zwischen zusammengehörigen Vorgängen
(z. B. Drag-Start → Drag-Ende → Koordinatenumrechnung) eher erschwert
als erleichtert. `annotate_ui.py` wurde im Zuge der Radierer-Erweiterung
bereits von 237 auf 152 Zeilen aufgeteilt (siehe Nachtrag -10).

## 5. Durchgeführte Tests

**Syntax**: Alle 34 Python-Dateien mit `py_compile` geprüft.

**GUI (headless via Xvfb)**:
- Hauptfenster aufgebaut, alle 14 Navigationspunkte angesteuert
- Organisieren: alle 4 Unter-Werkzeuge durchgeklickt
- Redaction: beide Modi (Suche/Manuell) durchgeklickt
- Pipeline: Schritt hinzugefügt, Werkzeugtyp gewechselt, Konfiguration
  korrekt ausgelesen
- Sprachwechsel DE→EN: Fenster wird korrekt neu aufgebaut, alle Module
  bleiben danach stabil ansteuerbar (ein dabei gefundener Bug –
  veraltete Widget-Referenz nach Sprachwechsel – wurde behoben und
  erneut verifiziert)

**Backend-Funktionstests mit echten Test-PDFs**:
- Organisieren: Merge (2×5→10 Seiten), Split (5→5 Dateien), Rotate,
  Delete (5→3 Seiten) ✅
- Formulare: Testformular mit AcroForm-Textfeld erstellt, ausgelesen,
  ausgefüllt, Wert nach dem Speichern korrekt verifiziert ✅
- Metadaten: Schreiben/Lesen von Titel und Autor ✅
- Komprimierung: alle drei Qualitätsstufen über Ghostscript ✅
- Sicherheit: Verschlüsselung + Erkennung des Passwortschutzes ✅
- Anmerkungen: Freihand-Tinte, Hervorhebung und Text-Stempel erzeugt,
  gespeichert und Anzahl der Annotationen nach dem Speichern verifiziert ✅
- OCR: Bild-PDF ohne Textebene → nach OCR durchsuchbarer Text
  vorhanden (Testsatz korrekt erkannt) ✅
- Vergleich: zwei unterschiedliche Vertragstexte verglichen, Zeilen
  korrekt als hinzugefügt/entfernt markiert ✅
- Redaction: Suchbegriff gefunden und dauerhaft aus dem Text entfernt
  (verifiziert durch erneute Textextraktion nach dem Speichern) ✅
- Konvertierung: Text- und Markdown-Export inkl. einer testweise
  gezeichneten Tabelle korrekt als Markdown-Tabelle erkannt ✅
- Batch-Pipeline: 3 Test-PDFs durch eine Kette aus Drehen + Komprimieren
  geschickt, alle 3 erfolgreich im Ausgabeordner erzeugt ✅

Zwei während der Entwicklung gefundene und behobene Fehler:
1. `add_freetext_annot` akzeptierte in der installierten PyMuPDF-Version
   keinen `border_color`-Parameter ohne `rich_text=True` – durch
   `set_border()` ersetzt.
2. Sprachwechsel zur Laufzeit versuchte, ein bereits zerstörtes Widget
   per `grid_forget()` zu entfernen – behoben, indem die Referenz auf
   die aktive Ansicht vor dem Neuaufbau geleert wird.

## 6. Bekannte Einschränkungen / mögliche Erweiterungen

- Die Metadaten-Batch-Funktion überschreibt Originaldateien direkt
  (mit Warnhinweis in der Checkbox-Beschriftung).
- Anmerkungen und manuelle Redaction bieten aktuell keine
  Undo-Funktion für einzelne Striche/Bereiche innerhalb einer Sitzung
  (nur „alle Vormerkungen leeren" bei Redaction).
- Die Batch-Pipeline unterstützt aktuell die Schritte Drehen,
  Komprimieren, Passwort setzen und Metadaten (Autor). Weitere
  Schritttypen (z. B. OCR, Redaction) lassen sich nach demselben Muster
  in `pipeline_logic.py` und `pipeline_step_row.py` ergänzen.
- Falls auf einem System sowohl ein global per pip installiertes
  `pikepdf` als auch das apt-Paket `ocrmypdf` vorhanden sind, kann es
  zu Versionskonflikten kommen (in der Entwicklungsumgebung
  beobachtet und dort durch Bereinigung der doppelten Installation
  gelöst). Für Endnutzer, die ausschließlich über `install.sh` bzw.
  den Paketmanager installieren, tritt dieser Konflikt nicht auf.

## 7. Systemabhängigkeiten außerhalb von pip

- **Ghostscript** (`gs`) – für Komprimierung
- **ocrmypdf** + **Tesseract** (Sprachpakete Deutsch/Englisch) – für OCR
- **python3-tk** – für die grafische Oberfläche selbst

Alle drei werden von `install_check.py` beim Start geprüft und bei
Bedarf mit distributionsspezifischem Installationsbefehl angezeigt.
`install.sh` installiert alle drei automatisch auf den unterstützten
Distributionen.

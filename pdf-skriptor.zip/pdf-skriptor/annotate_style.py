"""
annotate_style.py
Kleines, eigenstaendiges Werkzeug-Widget zur Auswahl von Stiftfarbe und
Strichstaerke fuer das Anmerkungen-Modul. Bewusst als eigene Datei
ausgelagert, damit annotate_ui.py uebersichtlich bleibt und die
Stiloptionen bei Bedarf auch von anderen Werkzeugen (z. B. Signatur)
wiederverwendet werden koennen.
"""

import customtkinter as ctk
from language import t
import theme

# Kleine, klar unterscheidbare Farbpalette (Anzeige-Hex, PyMuPDF-RGB 0..1)
_PALETTE = [
    ("#E01A1A", (0.88, 0.10, 0.10)),
    ("#1B1E28", (0.11, 0.12, 0.16)),
    ("#2F6FED", (0.18, 0.44, 0.93)),
    ("#2FAE60", (0.18, 0.68, 0.38)),
    ("#E0A420", (0.88, 0.64, 0.13)),
]


class StylePicker(ctk.CTkFrame):
    """Zeigt Farb-Swatches und einen Staerke-Regler an und haelt die
    aktuelle Auswahl vor. Wird nur bei Werkzeugen eingeblendet, die eine
    Strichfarbe/-staerke benoetigen (Freihand, Hervorhebung)."""

    def __init__(self, master) -> None:
        super().__init__(master, fg_color="transparent")
        self._selected_color = _PALETTE[0][1]
        self._swatch_buttons: list[ctk.CTkButton] = []
        self._build_ui()

    def _build_ui(self) -> None:
        color_label = ctk.CTkLabel(
            self, text=t("annotate_color_label"), font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED,
        )
        color_label.pack(anchor="w")

        swatch_row = ctk.CTkFrame(self, fg_color="transparent")
        swatch_row.pack(anchor="w", pady=(2, theme.PADDING_SMALL))
        for hex_color, rgb in _PALETTE:
            button = ctk.CTkButton(
                swatch_row, text="", width=26, height=26, corner_radius=13,
                fg_color=hex_color, hover_color=hex_color, border_width=2,
                border_color=theme.COLOR_ACCENT if rgb == self._selected_color else hex_color,
                command=lambda c=rgb, b_hex=hex_color: self._select_color(c),
            )
            button.pack(side="left", padx=(0, 6))
            self._swatch_buttons.append(button)

        width_label = ctk.CTkLabel(
            self, text=t("annotate_width_label"), font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED,
        )
        width_label.pack(anchor="w")

        self._width_slider = ctk.CTkSlider(self, from_=1, to=8, number_of_steps=7, width=180)
        self._width_slider.set(2)
        self._width_slider.pack(anchor="w", pady=(2, theme.PADDING_SMALL))

    def _select_color(self, rgb: tuple[float, float, float]) -> None:
        self._selected_color = rgb
        for button, (hex_color, palette_rgb) in zip(self._swatch_buttons, _PALETTE):
            button.configure(border_color=theme.COLOR_ACCENT if palette_rgb == rgb else hex_color)

    def get_color(self) -> tuple[float, float, float]:
        return self._selected_color

    def get_width(self) -> float:
        return float(self._width_slider.get())

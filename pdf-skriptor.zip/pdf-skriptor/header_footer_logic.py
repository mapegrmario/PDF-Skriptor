"""
header_footer_logic.py
Fuegt eine Kopf- und/oder Fusszeile mit Platzhaltern auf jede Seite
einer PDF-Datei ein - Standard-Buero-Aufgabe (Seitennummerierung,
Aktenzeichen), die in keinem der bisherigen Module abgedeckt ist.

Unterstuetzte Platzhalter in Kopf-/Fusszeilen-Text:
  {seite}        aktuelle Seitenzahl
  {seiten}       Gesamtzahl der Seiten
  {datum}        heutiges Datum (TT.MM.JJJJ)
  {aktenzeichen} fortlaufende Nummer mit Praefix/Polsterung (optional)
"""

import datetime
import pymupdf as fitz  # "fitz" ist der veraltete Alias, siehe PyMuPDF-Deprecation-Hinweis
from logger_setup import log_exception

_MARGIN = 24
_BAR_HEIGHT = 20
_ALIGN_MAP = {"left": fitz.TEXT_ALIGN_LEFT, "center": fitz.TEXT_ALIGN_CENTER, "right": fitz.TEXT_ALIGN_RIGHT}


def _resolve_placeholders(template: str, page_number: int, total_pages: int, bates_number: int | None, bates_prefix: str, bates_digits: int) -> str:
    text = template.replace("{seite}", str(page_number))
    text = text.replace("{seiten}", str(total_pages))
    text = text.replace("{datum}", datetime.date.today().strftime("%d.%m.%Y"))
    if bates_number is not None:
        text = text.replace("{aktenzeichen}", f"{bates_prefix}{bates_number:0{bates_digits}d}")
    return text


def apply_header_footer(
    path: str, output_path: str, header_template: str, header_align: str,
    footer_template: str, footer_align: str, font_size: float = 10.0,
    bates_start: int | None = None, bates_prefix: str = "", bates_digits: int = 4,
) -> bool:
    """Schreibt Kopf-/Fusszeile auf jede Seite und speichert das Ergebnis
    in output_path. Leere Vorlagen werden uebersprungen (kein Eintrag)."""
    try:
        document = fitz.open(path)
        for index, page in enumerate(document):
            page_number = index + 1
            bates_number = bates_start + index if bates_start is not None else None
            width = page.rect.width - 2 * _MARGIN

            if header_template.strip():
                text = _resolve_placeholders(header_template, page_number, document.page_count, bates_number, bates_prefix, bates_digits)
                rect = fitz.Rect(_MARGIN, _MARGIN * 0.5, _MARGIN + width, _MARGIN * 0.5 + _BAR_HEIGHT)
                page.insert_textbox(rect, text, fontsize=font_size, align=_ALIGN_MAP.get(header_align, fitz.TEXT_ALIGN_LEFT))

            if footer_template.strip():
                text = _resolve_placeholders(footer_template, page_number, document.page_count, bates_number, bates_prefix, bates_digits)
                y0 = page.rect.height - _MARGIN * 0.5 - _BAR_HEIGHT
                rect = fitz.Rect(_MARGIN, y0, _MARGIN + width, y0 + _BAR_HEIGHT)
                page.insert_textbox(rect, text, fontsize=font_size, align=_ALIGN_MAP.get(footer_align, fitz.TEXT_ALIGN_CENTER))

        document.save(output_path)
        document.close()
        return True
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Einfügen von Kopf-/Fußzeile", exc)
        return False


def get_page_count(path: str) -> int:
    try:
        document = fitz.open(path)
        count = document.page_count
        document.close()
        return count
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Ermitteln der Seitenzahl", exc)
        return 0

"""
sign_document_ui.py
Unter-Werkzeug "Signieren" des Digitale-Signatur-Moduls: signiert die
aktive Datei kryptographisch mit dem aktuell aktiven Zertifikat
(cert_logic.py). Das Zertifikats-Passwort wird bei jedem Signiervorgang
neu eingegeben und nirgendwo gespeichert.
"""

import os
import tkinter.filedialog as filedialog
from tkinter import messagebox
import customtkinter as ctk
from language import t
import settings as settings_store
import theme
from cert_logic import get_active_certificate_path, get_certificate_info
from pdf_sign_logic import sign_document
from file_list_sync import sync_active_file, load_result_file


class SignDocumentTool(ctk.CTkFrame):
    """Signiert die aktive Datei mit dem aktiven Zertifikat."""

    def __init__(self, master, file_manager) -> None:
        super().__init__(master, fg_color="transparent")
        self._file_manager = file_manager
        self._active_path: str | None = None
        self._build_ui()
        sync_active_file(self, self._file_manager, self._handle_active_changed)

    def _build_ui(self) -> None:
        self._active_file_label = ctk.CTkLabel(self, text="", font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED)
        self._active_file_label.pack(anchor="w", pady=(0, 4))

        self._cert_label = ctk.CTkLabel(
            self, text="", font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED, wraplength=300, justify="left",
        )
        self._cert_label.pack(anchor="w", pady=(0, theme.PADDING_MEDIUM))

        card = ctk.CTkFrame(self, fg_color=theme.COLOR_BG_SECONDARY, corner_radius=theme.CORNER_RADIUS)
        card.pack(fill="x", pady=(0, theme.PADDING_MEDIUM))

        self._reason_entry = ctk.CTkEntry(card, placeholder_text=t("sign_reason_placeholder"))
        self._reason_entry.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=(theme.PADDING_MEDIUM, 2))
        self._location_entry = ctk.CTkEntry(card, placeholder_text=t("sign_location_placeholder"))
        self._location_entry.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=2)
        self._password_entry = ctk.CTkEntry(card, placeholder_text=t("sign_password_placeholder"), show="•")
        self._password_entry.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=(2, theme.PADDING_MEDIUM))

        sign_button = ctk.CTkButton(
            self, text=t("sign_document_button"), fg_color=theme.COLOR_ACCENT, hover_color=theme.COLOR_ACCENT_HOVER,
            corner_radius=theme.CORNER_RADIUS, command=self._handle_sign,
        )
        sign_button.pack(fill="x")

    def _handle_active_changed(self, path: str | None) -> None:
        self._active_path = path
        if path:
            self._active_file_label.configure(text=f"📄 {os.path.basename(path)}")
        else:
            self._active_file_label.configure(text=t("no_active_file_hint"))
        self._refresh_cert_label()

    def _refresh_cert_label(self) -> None:
        info = get_certificate_info()
        if not info:
            self._cert_label.configure(text=t("sign_no_cert_hint"))
        elif info.get("source") == "generated":
            self._cert_label.configure(text=t("sign_cert_active_generated").format(name=info.get("common_name", ""), valid_until=info.get("valid_until", "")))
        else:
            self._cert_label.configure(text=t("sign_cert_active_external").format(filename=os.path.basename(info.get("path", ""))))

    def _handle_sign(self) -> None:
        certificate_path = get_active_certificate_path()
        if not self._active_path:
            messagebox.showinfo(t("app_title"), t("no_active_file_hint"))
            return
        if not certificate_path:
            messagebox.showinfo(t("app_title"), t("sign_no_cert_hint"))
            return
        password = self._password_entry.get()
        if not password:
            messagebox.showinfo(t("app_title"), t("sign_password_required"))
            return

        settings = settings_store.load_settings()
        base_name = os.path.splitext(os.path.basename(self._active_path))[0]
        default_path = os.path.join(settings.get("output_dir", "~"), f"{base_name}_signiert.pdf")
        output_path = filedialog.asksaveasfilename(
            initialfile=os.path.basename(default_path), initialdir=os.path.dirname(default_path),
            defaultextension=".pdf", filetypes=[("PDF-Dateien", "*.pdf")],
        )
        if not output_path:
            return

        success = sign_document(
            self._active_path, output_path, certificate_path, password,
            reason=self._reason_entry.get().strip(), location=self._location_entry.get().strip(),
        )
        self._password_entry.delete(0, "end")
        if success:
            load_result_file(self._file_manager, output_path)
            messagebox.showinfo(t("app_title"), t("save_success"))
        else:
            messagebox.showerror(t("app_title"), t("sign_failed_hint"))

"""
install_check.py
Prueft beim Start, ob benoetigte System-Werkzeuge (Ghostscript,
ocrmypdf, Tesseract) verfuegbar sind, und gibt distributionsspezifische
Installationshinweise.
"""

import shutil
import platform

_INSTALL_HINTS = {
    "ghostscript": {
        "Ubuntu/Mint/MX Linux (apt)": "sudo apt install ghostscript",
        "Fedora (dnf)": "sudo dnf install ghostscript",
        "openSUSE (zypper)": "sudo zypper install ghostscript",
        "Arch Linux (pacman)": "sudo pacman -S ghostscript",
    },
    "ocrmypdf": {
        "Ubuntu/Mint/MX Linux (apt)": "sudo apt install ocrmypdf tesseract-ocr-deu tesseract-ocr-eng",
        "Fedora (dnf)": "sudo dnf install ocrmypdf tesseract-langpack-deu tesseract-langpack-eng",
        "openSUSE (zypper)": "sudo zypper install ocrmypdf tesseract-ocr-traineddata-deu",
        "Arch Linux (pacman)": "sudo pacman -S ocrmypdf tesseract-data-deu tesseract-data-eng",
    },
    "cups": {
        "Ubuntu/Mint/MX Linux (apt)": "sudo apt install cups-client",
        "Fedora (dnf)": "sudo dnf install cups-client",
        "openSUSE (zypper)": "sudo zypper install cups-client",
        "Arch Linux (pacman)": "sudo pacman -S cups",
    },
}


def check_dependencies() -> dict:
    """Gibt eine Liste fehlender Systemabhaengigkeiten mit Installationshinweisen zurueck."""
    missing = {}
    if shutil.which("gs") is None:
        missing["ghostscript"] = _INSTALL_HINTS["ghostscript"]
    if shutil.which("ocrmypdf") is None:
        missing["ocrmypdf"] = _INSTALL_HINTS["ocrmypdf"]
    if shutil.which("lp") is None:
        missing["cups"] = _INSTALL_HINTS["cups"]
    return missing


def get_system_summary() -> str:
    """Kurze Systeminfo fuer die Fehlerprotokollierung/Diagnose."""
    return f"{platform.system()} {platform.release()} ({platform.machine()})"

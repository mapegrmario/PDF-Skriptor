"""
file_manager.py
Verwaltet die Liste der aktuell in PDF Skriptor geladenen Dateien sowie
die "aktive Datei" - jene eine Datei, mit der gerade gearbeitet wird.
Alle Werkzeug-Module und die persistente Vorschau greifen auf dieselbe
aktive Datei zu, damit unabhaengig vom gewaehlten Werkzeug immer klar
ist, welche Datei gerade bearbeitet/angezeigt wird.
"""

import os
from logger_setup import log_exception


class FileManager:
    """Haelt die geladenen PDF-Dateien und die aktive Datei fuer die Sitzung."""

    def __init__(self) -> None:
        self._files: list[str] = []
        self._listeners: list[callable] = []
        self._active_path: str | None = None
        self._active_listeners: list[callable] = []

    def add_files(self, paths: list[str]) -> list[str]:
        """Fuegt neue Dateipfade hinzu, ignoriert Duplikate und Nicht-PDFs."""
        added = []
        for path in paths:
            if not path.lower().endswith(".pdf"):
                continue
            if path in self._files:
                continue
            if not os.path.isfile(path):
                continue
            self._files.append(path)
            added.append(path)
        if added:
            self._notify_listeners()
            if self._active_path is None:
                self.set_active_file(added[0])
        return added

    def remove_file(self, path: str) -> None:
        if path in self._files:
            self._files.remove(path)
            self._notify_listeners()
            if self._active_path == path:
                self.set_active_file(self._files[0] if self._files else None)

    def clear(self) -> None:
        self._files.clear()
        self._notify_listeners()
        self.set_active_file(None)

    def get_files(self) -> list[str]:
        return list(self._files)

    def reorder_files(self, new_order: list[str]) -> None:
        """Setzt eine neue Reihenfolge der geladenen Dateien (z. B. per
        Drag & Drop im Zusammenfuegen-Werkzeug). `new_order` muss exakt
        dieselben Pfade wie die aktuelle Liste enthalten, nur in anderer
        Reihenfolge - andernfalls wird die Aenderung ignoriert. Wirkt
        sich auf ALLE Ansichten aus (auch die Werkbank-Chips), da es
        nur eine gemeinsame Dateiliste gibt."""
        if sorted(new_order) != sorted(self._files):
            return
        self._files = list(new_order)
        self._notify_listeners()

    def has_files(self) -> bool:
        return len(self._files) > 0

    def set_active_file(self, path: str | None) -> None:
        """Legt fest, mit welcher Datei aktuell gearbeitet wird (fuer alle
        Werkzeuge und die persistente Vorschau)."""
        if path != self._active_path:
            self._active_path = path
            self._notify_active_listeners()

    def get_active_file(self) -> str | None:
        return self._active_path

    def register_listener(self, callback: callable) -> None:
        """Registriert eine Funktion, die bei Aenderungen der Dateiliste aufgerufen wird."""
        self._listeners.append(callback)

    def unregister_listener(self, callback: callable) -> None:
        """Entfernt einen zuvor registrierten Listener (z. B. beim Schliessen einer Ansicht)."""
        if callback in self._listeners:
            self._listeners.remove(callback)

    def register_active_listener(self, callback: callable) -> None:
        """Registriert eine Funktion, die bei Wechsel der aktiven Datei aufgerufen wird."""
        self._active_listeners.append(callback)

    def unregister_active_listener(self, callback: callable) -> None:
        """Entfernt einen zuvor registrierten Aktive-Datei-Listener."""
        if callback in self._active_listeners:
            self._active_listeners.remove(callback)

    def _notify_listeners(self) -> None:
        for callback in self._listeners:
            try:
                callback(self.get_files())
            except Exception as exc:  # noqa: BLE001
                log_exception("Fehler in Datei-Listener", exc)

    def _notify_active_listeners(self) -> None:
        for callback in self._active_listeners:
            try:
                callback(self._active_path)
            except Exception as exc:  # noqa: BLE001
                log_exception("Fehler in Aktive-Datei-Listener", exc)


# Gemeinsame Instanz fuer die gesamte Anwendung
file_manager = FileManager()

#!/usr/bin/env bash
#
# install.sh - Richtet PDF Skriptor auf gaengigen Linux-Distributionen ein.
# Autor: Mario Peeß, Großenhain (mapegr@mailbox.org)
#
# Erkennt die Distribution, installiert Systemabhaengigkeiten
# (Ghostscript, ocrmypdf, Tesseract mit Deutsch/Englisch, python3-tk),
# legt eine virtuelle Python-Umgebung an und installiert die
# Python-Pakete aus requirements.txt.

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "=================================================="
echo " PDF Skriptor - Installation"
echo "=================================================="

# --- Distribution erkennen ---------------------------------------------
if [ -f /etc/os-release ]; then
    . /etc/os-release
    DISTRO_ID="${ID:-unknown}"
    DISTRO_LIKE="${ID_LIKE:-}"
else
    DISTRO_ID="unknown"
    DISTRO_LIKE=""
fi

echo "Erkannte Distribution: ${DISTRO_ID} (${PRETTY_NAME:-unbekannt})"

# --- Paketmanager-Befehle je Distribution -------------------------------
install_debian() {
    echo "Verwende apt (Ubuntu/Linux Mint/LMDE/MX Linux) ..."
    sudo apt update || echo "Warnung: 'apt update' meldete einen Fehler (z. B. durch ein Drittanbieter-Repository) - fahre mit vorhandenem Paketcache fort."
    sudo apt install -y python3 python3-venv python3-tk \
        ghostscript ocrmypdf tesseract-ocr tesseract-ocr-deu tesseract-ocr-eng
}

install_fedora() {
    echo "Verwende dnf (Fedora) ..."
    sudo dnf install -y python3 python3-tkinter \
        ghostscript ocrmypdf tesseract tesseract-langpack-deu tesseract-langpack-eng
}

install_suse() {
    echo "Verwende zypper (openSUSE) ..."
    sudo zypper install -y python3 python3-tk \
        ghostscript ocrmypdf tesseract-ocr tesseract-ocr-traineddata-deu tesseract-ocr-traineddata-eng
}

install_arch() {
    echo "Verwende pacman (Arch Linux) ..."
    sudo pacman -Sy --noconfirm python python-pip tk \
        ghostscript ocrmypdf tesseract tesseract-data-deu tesseract-data-eng
}

case "${DISTRO_ID}" in
    ubuntu|linuxmint|debian)
        install_debian
        ;;
    fedora)
        install_fedora
        ;;
    opensuse*|sles)
        install_suse
        ;;
    arch|endeavouros|manjaro)
        install_arch
        ;;
    *)
        case "${DISTRO_LIKE}" in
            *debian*)
                install_debian
                ;;
            *fedora*|*rhel*)
                install_fedora
                ;;
            *suse*)
                install_suse
                ;;
            *arch*)
                install_arch
                ;;
            *)
                echo ""
                echo "Distribution nicht automatisch erkannt."
                echo "Bitte manuell installieren: Python 3, python3-tk/tkinter,"
                echo "Ghostscript, ocrmypdf, Tesseract (Sprachen Deutsch + Englisch)."
                echo ""
                ;;
        esac
        ;;
esac

# --- Virtuelle Umgebung anlegen -----------------------------------------
echo ""
echo "Lege virtuelle Python-Umgebung an ..."
python3 -m venv venv
# shellcheck disable=SC1091
source venv/bin/activate

echo "Installiere Python-Abhängigkeiten ..."
pip install --upgrade pip
pip install -r requirements.txt

deactivate

# --- fehler.log anlegen --------------------------------------------------
touch "$SCRIPT_DIR/fehler.log"

# --- Start-Skript ausführbar machen ---------------------------------------
chmod +x "$SCRIPT_DIR/run.sh" "$SCRIPT_DIR/analyse.sh"

# --- Startmenü-Eintrag einrichten ------------------------------------------
echo ""
echo "Richte Startmenü-Eintrag ein ..."
DESKTOP_DIR="$HOME/.local/share/applications"
mkdir -p "$DESKTOP_DIR"
sed "s|__PDF_SKRIPTOR_DIR__|${SCRIPT_DIR}|g" "$SCRIPT_DIR/pdf-skriptor.desktop" > "$DESKTOP_DIR/pdf-skriptor.desktop"
chmod +x "$DESKTOP_DIR/pdf-skriptor.desktop"

if command -v update-desktop-database &>/dev/null; then
    update-desktop-database "$DESKTOP_DIR" 2>/dev/null || true
fi
echo "Eintrag im Startmenü angelegt: $DESKTOP_DIR/pdf-skriptor.desktop"
echo "(Falls PDF Skriptor nicht sofort im Menü erscheint, einmal ab-/anmelden"
echo " oder das Anwendungsmenü neu laden.)"

echo ""
echo "=================================================="
echo " Installation abgeschlossen."
echo ""
echo " Start über das Startmenü ('PDF Skriptor') oder mit:"
echo "   ./run.sh"
echo ""
echo " Diagnose/Analyse:"
echo "   ./analyse.sh --help"
echo "=================================================="

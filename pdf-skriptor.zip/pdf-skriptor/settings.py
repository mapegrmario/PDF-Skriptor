"""
settings.py
Verwaltet die persistenten Anwendungseinstellungen (Sprache, Theme,
Standard-Ausgabeordner) als JSON-Datei im Benutzerverzeichnis.
"""

import json
import os
from logger_setup import log_exception

SETTINGS_FILENAME = "pdf_skriptor_settings.json"


def _default_output_dir() -> str:
    """Bevorzugt den lokalisierten 'Dokumente'-Ordner, faellt aber auf
    'Documents' bzw. zuletzt das Home-Verzeichnis zurueck, falls keiner
    von beiden existiert (z. B. bei nicht-deutscher Locale oder einem
    frischen Konto, auf dem xdg-user-dirs noch keine Ordner angelegt hat).
    Es wird bewusst kein Ordner neu angelegt - nur ein sicher vorhandener
    Ausgangspunkt fuer den Datei-Dialog gewaehlt."""
    home = os.path.expanduser("~")
    for candidate in ("Dokumente", "Documents"):
        path = os.path.join(home, candidate)
        if os.path.isdir(path):
            return path
    return home


# "appearance_mode" bewusst NICHT mehr Teil der Standardwerte: theme.py legt
# das Erscheinungsbild fest auf "light" fest (siehe dortiger Kommentar), ein
# Umschalter existiert in den Einstellungen nicht - ein gespeicherter, aber
# nirgends wirksamer Wert waere irrefuehrend fuer alle, die spaeter an der
# settings.json oder am Code weiterarbeiten.
_DEFAULT_SETTINGS = {
    "language": "de",
    "output_dir": _default_output_dir(),
    "last_used_module": "organize",
    "workbench_pane_height": 240,
    "preview_pane_height": 140,
    "last_used_printer": "",
}


def _get_settings_path() -> str:
    config_dir = os.path.join(os.path.expanduser("~"), ".config", "pdf-skriptor")
    os.makedirs(config_dir, exist_ok=True)
    return os.path.join(config_dir, SETTINGS_FILENAME)


def load_settings() -> dict:
    """Laedt die Einstellungen von der Festplatte oder erzeugt Standardwerte."""
    path = _get_settings_path()
    if not os.path.exists(path):
        save_settings(_DEFAULT_SETTINGS)
        return dict(_DEFAULT_SETTINGS)

    try:
        with open(path, "r", encoding="utf-8") as file:
            data = json.load(file)
        merged = dict(_DEFAULT_SETTINGS)
        merged.update(data)
        return merged
    except (OSError, json.JSONDecodeError) as exc:
        log_exception("Einstellungen konnten nicht geladen werden", exc)
        return dict(_DEFAULT_SETTINGS)


def save_settings(settings: dict) -> bool:
    """Speichert die Einstellungen als JSON-Datei."""
    path = _get_settings_path()
    try:
        with open(path, "w", encoding="utf-8") as file:
            json.dump(settings, file, indent=2, ensure_ascii=False)
        return True
    except OSError as exc:
        log_exception("Einstellungen konnten nicht gespeichert werden", exc)
        return False


def update_setting(key: str, value) -> dict:
    """Aktualisiert einen einzelnen Einstellungswert und speichert sofort."""
    settings = load_settings()
    settings[key] = value
    save_settings(settings)
    return settings

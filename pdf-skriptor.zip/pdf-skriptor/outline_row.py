"""
outline_row.py
Eine einzelne Zeile im Lesezeichen-Editor: Ebene, Titel, Zielseite,
Sprung-Knopf (springt in der Dokumentenansicht direkt zur Seite) und
Loeschen-Knopf. Als eigene, kleine Komponente ausgelagert, damit
outline_ui.py bei beliebig vielen Zeilen uebersichtlich bleibt.
"""

import customtkinter as ctk
from language import t
import theme

_LEVELS = ["1", "2", "3", "4"]


class OutlineRow(ctk.CTkFrame):
    """Stellt einen Lesezeichen-Eintrag dar und haelt seine aktuellen
    Werte vor. on_jump(page) und on_delete(self) werden vom Elternteil
    (outline_ui.py) bereitgestellt."""

    def __init__(self, master, level: int, title: str, page: int, on_jump, on_delete) -> None:
        super().__init__(master, fg_color=theme.COLOR_BG_SECONDARY, corner_radius=theme.CORNER_RADIUS)
        self._on_jump = on_jump
        self._on_delete = on_delete
        self._build_ui(level, title, page)

    def _build_ui(self, level: int, title: str, page: int) -> None:
        self._level_menu = ctk.CTkOptionMenu(self, values=_LEVELS, width=54)
        self._level_menu.set(str(max(1, min(level, 4))))
        self._level_menu.pack(side="left", padx=(theme.PADDING_SMALL, 4), pady=theme.PADDING_SMALL)

        self._title_entry = ctk.CTkEntry(self, placeholder_text=t("outline_title_placeholder"))
        self._title_entry.insert(0, title)
        self._title_entry.pack(side="left", fill="x", expand=True, padx=4, pady=theme.PADDING_SMALL)

        self._page_entry = ctk.CTkEntry(self, placeholder_text=t("outline_page_placeholder"), width=64)
        self._page_entry.insert(0, str(page))
        self._page_entry.pack(side="left", padx=4, pady=theme.PADDING_SMALL)

        jump_button = ctk.CTkButton(
            self, text="🔎", width=32, fg_color="transparent", border_width=1,
            border_color=theme.COLOR_BORDER, text_color=theme.COLOR_TEXT, hover_color=theme.COLOR_ACCENT_SOFT,
            command=self._handle_jump,
        )
        jump_button.pack(side="left", padx=4, pady=theme.PADDING_SMALL)

        delete_button = ctk.CTkButton(
            self, text="🗑️", width=32, fg_color="transparent", border_width=1,
            border_color=theme.COLOR_BORDER, text_color=theme.COLOR_ERROR, hover_color=theme.COLOR_ACCENT_SOFT,
            command=lambda: self._on_delete(self),
        )
        delete_button.pack(side="left", padx=(4, theme.PADDING_SMALL), pady=theme.PADDING_SMALL)

    def _handle_jump(self) -> None:
        try:
            page = int(self._page_entry.get())
        except ValueError:
            return
        self._on_jump(page)

    def get_values(self) -> dict:
        try:
            page = int(self._page_entry.get())
        except ValueError:
            page = 1
        return {
            "level": int(self._level_menu.get()),
            "title": self._title_entry.get().strip(),
            "page": page,
        }

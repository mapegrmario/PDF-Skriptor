"""
annotate_ui.py
Werkzeug-Panel fuer Anmerkungen: Aufbau der Bedienelemente (Werkzeug-
Auswahl, Stil-Optionen, Stempel-Auswahl, Speichern). Die eigentliche
Maus-Interaktion auf der zentralen Dokumentenansicht steckt in
annotate_interaction.py, damit diese Datei uebersichtlich bleibt.
"""

import os
import tkinter.filedialog as filedialog
from tkinter import messagebox
import customtkinter as ctk
from language import t
import settings as settings_store
import theme
from annotate_style import StylePicker
from annotate_interaction import AnnotationInteraction
from annotate_logic import save_document, STAMP_PRESETS
from signature_logic import render_signature_image, save_signature
from file_list_sync import sync_active_file, load_result_file

# Interne Werkzeug-IDs, unabhaengig von der Anzeigesprache
_TOOL_IDS = ["freehand", "highlight", "text", "stamp", "eraser", "signature"]
_TOOLS_WITH_STYLE = {"freehand", "highlight"}


class AnnotateView(ctk.CTkFrame):
    """Werkzeug-Panel zum Einfuegen/Entfernen von Anmerkungen auf der aktiven Seite."""

    def __init__(self, master, file_manager, document_view) -> None:
        super().__init__(master, fg_color=theme.COLOR_BG)
        self._file_manager = file_manager
        self._document_view = document_view
        self._active_path: str | None = None
        self._active_tool = "freehand"
        self._pending_count = 0
        self._has_moved_annotation = False
        self._label_by_display: dict[str, str] = {}
        self._build_ui()
        self._interaction = AnnotationInteraction(
            document_view, self._style_picker,
            get_active_tool=lambda: self._active_tool,
            get_stamp_text=lambda: self._stamp_selector.get(),
            on_added=self._register_addition,
            on_removed=self._register_removal,
            on_erase_miss=lambda: self._hint_label.configure(text=t("annotate_eraser_none_found")),
            on_signature_missing=self._open_signature_pad,
            on_text_requested=self._open_text_dialog,
            on_moved=self._register_move,
        )
        sync_active_file(self, self._file_manager, self._handle_active_changed)

    def _build_ui(self) -> None:
        title = ctk.CTkLabel(self, text=t("nav_annotate"), font=theme.font_title(), text_color=theme.COLOR_TEXT)
        title.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(theme.PADDING_LARGE, theme.PADDING_SMALL))

        self._active_file_label = ctk.CTkLabel(self, text="", font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED)
        self._active_file_label.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        display_values = []
        for tool_id in _TOOL_IDS:
            label = t(f"tool_{tool_id}")
            display_values.append(label)
            self._label_by_display[label] = tool_id

        # QA-Fix (Runde 6, live entdeckt): sechs Werkzeuge in einer einzigen
        # CTkSegmentedButton-Zeile hatten in der 380px breiten Seitenleiste
        # nur ca. 55px pro Segment - zu wenig fuer Beschriftungen wie
        # "Hervorhebung" oder "Unterschrift", die dadurch abgeschnitten und
        # teils unleserlich dargestellt wurden. Zwei Zeilen zu je drei
        # Werkzeugen geben jedem Segment die doppelte Breite. Da
        # CTkSegmentedButton pro Instanz nur eine eigene Auswahl kennt,
        # muss die jeweils andere Zeile bei Auswahl manuell geleert werden
        # (siehe _handle_tool_selected), damit nur ein Werkzeug gleichzeitig
        # aktiv erscheint.
        selector_frame = ctk.CTkFrame(self, fg_color="transparent")
        selector_frame.pack(fill="x", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))
        self._tool_selector_rows = [
            ctk.CTkSegmentedButton(selector_frame, values=display_values[:3], command=self._handle_tool_selected),
            ctk.CTkSegmentedButton(selector_frame, values=display_values[3:], command=self._handle_tool_selected),
        ]
        self._tool_selector_rows[0].pack(fill="x", pady=(0, 6))
        self._tool_selector_rows[1].pack(fill="x")
        self._tool_selector_rows[0].set(display_values[0])

        self._stamp_selector = ctk.CTkOptionMenu(self, values=STAMP_PRESETS)
        self._style_picker = StylePicker(self)
        self._signature_button = ctk.CTkButton(
            self, text=t("signature_redraw"), fg_color="transparent", border_width=1,
            border_color=theme.COLOR_BORDER, text_color=theme.COLOR_TEXT, hover_color=theme.COLOR_ACCENT_SOFT,
            corner_radius=theme.CORNER_RADIUS, command=self._open_signature_pad,
        )

        self._hint_label = ctk.CTkLabel(
            self, text="", font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED, wraplength=300, justify="left",
        )
        self._hint_label.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        self._pending_label = ctk.CTkLabel(
            self, text=t("annotate_pending_count").format(n=0), font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED,
        )
        self._pending_label.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        save_button = ctk.CTkButton(
            self, text=t("annotate_save_button"), fg_color=theme.COLOR_ACCENT, hover_color=theme.COLOR_ACCENT_HOVER,
            corner_radius=theme.CORNER_RADIUS, command=self._handle_save,
        )
        save_button.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_LARGE))

        self._apply_tool_visuals()

    def _handle_tool_selected(self, display_value: str) -> None:
        self._active_tool = self._label_by_display.get(display_value, "freehand")
        for row in self._tool_selector_rows:
            if display_value not in row.cget("values"):
                row.set("")
        self._apply_tool_visuals()

    def _apply_tool_visuals(self) -> None:
        """Blendet Stempel-Auswahl bzw. Stil-Optionen je nach gewaehltem
        Werkzeug ein/aus und aktualisiert den Hinweistext."""
        self._stamp_selector.pack_forget()
        self._style_picker.pack_forget()
        self._signature_button.pack_forget()
        if self._active_tool == "stamp":
            self._stamp_selector.pack(fill="x", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM), before=self._hint_label)
        elif self._active_tool == "signature":
            self._signature_button.pack(fill="x", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM), before=self._hint_label)
        elif self._active_tool in _TOOLS_WITH_STYLE:
            self._style_picker.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_SMALL), before=self._hint_label)
        self._hint_label.configure(text=t(f"annotate_hint_{self._active_tool}"))

    def _handle_active_changed(self, path: str | None) -> None:
        self._active_path = path
        if path:
            self._active_file_label.configure(text=f"📄 {os.path.basename(path)}")
        else:
            self._active_file_label.configure(text=t("no_active_file_hint"))
        self._pending_count = 0
        self._has_moved_annotation = False
        self._interaction.clear_pending_signatures()
        self._pending_label.configure(text=t("annotate_pending_count").format(n=0))

    def on_shown(self) -> None:
        """Wird von app_window.py aufgerufen, sobald dieses Werkzeug in der
        Seitenleiste sichtbar wird."""
        self._interaction.bind()

    def on_hidden(self) -> None:
        """Wird von app_window.py aufgerufen, sobald ein anderes Werkzeug
        gewaehlt wird."""
        self._interaction.unbind()

    def _register_addition(self) -> None:
        self._pending_count += 1
        self._pending_label.configure(text=t("annotate_pending_count").format(n=self._pending_count))

    def _register_removal(self) -> None:
        self._pending_count = max(0, self._pending_count - 1)
        self._pending_label.configure(
            text=f"{t('annotate_pending_count').format(n=self._pending_count)} · 1 {t('annotate_removed_count')}"
        )

    def _register_move(self) -> None:
        # Separates Flag statt pending_count-Erhoehung: ein Verschieben ist
        # keine neue Anmerkung (die Zaehler-Anzeige "N hinzugefuegt" soll
        # dadurch nicht steigen), zaehlt aber trotzdem als ungesicherte
        # Aenderung fuer den Schliessen-Schutz (has_unsaved_changes).
        self._has_moved_annotation = True

    def _open_signature_pad(self) -> None:
        from signature_pad import SignaturePad  # spaeter Import: Toplevel erst bei Bedarf erzeugen
        SignaturePad(self, on_confirm=self._handle_signature_drawn)

    def _open_text_dialog(self) -> None:
        from text_tool_dialog import TextToolDialog  # spaeter Import: Toplevel erst bei Bedarf erzeugen
        TextToolDialog(self, on_confirm=self._interaction.confirm_text)

    def _handle_signature_drawn(self, strokes: list[list[tuple[float, float]]]) -> None:
        image = render_signature_image(strokes)
        if save_signature(image):
            self._hint_label.configure(text=t("signature_saved_hint"))
        else:
            self._hint_label.configure(text=t("error_generic"))

    def has_unsaved_changes(self) -> bool:
        """Wird von app_window.py beim Schliessen des Fensters abgefragt
        (QA-Fix, Befund 4.4) - Anmerkungen liegen bis zum expliziten
        Speichern-Klick nur im Arbeitsspeicher."""
        return self._pending_count > 0 or self._has_moved_annotation

    def _handle_save(self) -> None:
        document = self._document_view.get_document()
        if not self._active_path or not document or not self.has_unsaved_changes():
            messagebox.showinfo(t("app_title"), t("annotate_need_at_least_one"))
            return

        settings = settings_store.load_settings()
        base_name = os.path.splitext(os.path.basename(self._active_path))[0]
        default_path = os.path.join(settings.get("output_dir", "~"), f"{base_name}_anmerkungen.pdf")
        output_path = filedialog.asksaveasfilename(
            initialfile=os.path.basename(default_path),
            initialdir=os.path.dirname(default_path),
            defaultextension=".pdf",
            filetypes=[("PDF-Dateien", "*.pdf")],
        )
        if not output_path:
            return

        self._interaction.bake_pending_signatures()
        success = save_document(document, output_path)
        if success:
            load_result_file(self._file_manager, output_path)
            messagebox.showinfo(t("app_title"), t("save_success"))
        else:
            messagebox.showerror(t("app_title"), t("error_generic"))

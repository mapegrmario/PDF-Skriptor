"""
compress_ui.py
UI fuer das Komprimierungs-Modul. Zeigt vor dem Speichern einen
Groessenvergleich aller Qualitaetsstufen an - das Alleinstellungsmerkmal
gegenueber einfachen Ghostscript-Kommandozeilen-Loesungen. Arbeitet
immer mit der aktuell aktiven Datei aus der Werkbank.
"""

import os
import tempfile
import tkinter.filedialog as filedialog
from tkinter import messagebox
import customtkinter as ctk
from language import t
import settings as settings_store
import theme
from compress_logic import compress_pdf, estimate_all_qualities, is_ghostscript_available
from file_list_sync import sync_active_file, load_result_file

_QUALITY_LABEL_KEYS = {"hoch": "compress_quality_high", "mittel": "compress_quality_medium", "niedrig": "compress_quality_low"}


class CompressView(ctk.CTkFrame):
    """Ansicht zur Komprimierung der aktiven Datei mit Vorschau-Vergleich."""

    def __init__(self, master, file_manager) -> None:
        super().__init__(master, fg_color=theme.COLOR_BG)
        self._file_manager = file_manager
        self._active_path: str | None = None
        self._result_labels: dict[str, ctk.CTkLabel] = {}
        self._quality_var = ctk.StringVar(value="mittel")
        self._build_ui()

    def _build_ui(self) -> None:
        title = ctk.CTkLabel(self, text=t("nav_compress"), font=theme.font_title(), text_color=theme.COLOR_TEXT)
        title.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(theme.PADDING_LARGE, theme.PADDING_SMALL))

        if not is_ghostscript_available():
            warning = ctk.CTkLabel(
                self, text=t("compress_ghostscript_missing"),
                font=theme.font_body(), text_color=theme.COLOR_WARNING, wraplength=300, justify="left",
            )
            warning.pack(anchor="w", padx=theme.PADDING_LARGE, pady=theme.PADDING_MEDIUM)
            return

        self._active_file_label = ctk.CTkLabel(self, text="", font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED)
        self._active_file_label.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        preview_button = ctk.CTkButton(
            self, text=t("compress_calc_comparison"), fg_color="transparent", border_width=1,
            border_color=theme.COLOR_BORDER, text_color=theme.COLOR_TEXT, hover_color=theme.COLOR_ACCENT_SOFT,
            corner_radius=theme.CORNER_RADIUS, command=self._handle_preview,
        )
        preview_button.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        self._card = ctk.CTkFrame(self, fg_color=theme.COLOR_BG_SECONDARY, corner_radius=theme.CORNER_RADIUS)
        self._card.pack(fill="x", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))
        self._build_result_rows()

        save_button = ctk.CTkButton(
            self, text=t("compress_save_with_quality"), fg_color=theme.COLOR_ACCENT,
            hover_color=theme.COLOR_ACCENT_HOVER, corner_radius=theme.CORNER_RADIUS,
            command=self._handle_save,
        )
        save_button.pack(anchor="w", padx=theme.PADDING_LARGE)

        sync_active_file(self, self._file_manager, self._handle_active_changed)

    def _build_result_rows(self) -> None:
        for quality, label_key in _QUALITY_LABEL_KEYS.items():
            row = ctk.CTkFrame(self._card, fg_color="transparent")
            row.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=theme.PADDING_SMALL)

            radio = ctk.CTkRadioButton(row, text=t(label_key), variable=self._quality_var, value=quality)
            radio.pack(side="left")

            result_label = ctk.CTkLabel(row, text="–", font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED)
            result_label.pack(side="right")
            self._result_labels[quality] = result_label

    def _handle_active_changed(self, path: str | None) -> None:
        self._active_path = path
        if path:
            self._active_file_label.configure(text=f"📄 {os.path.basename(path)}")
        else:
            self._active_file_label.configure(text=t("no_active_file_hint"))
        for label in self._result_labels.values():
            label.configure(text="–")

    def _handle_preview(self) -> None:
        if not self._active_path:
            messagebox.showinfo(t("app_title"), t("no_active_file_hint"))
            return

        with tempfile.TemporaryDirectory() as temp_dir:
            results = estimate_all_qualities(self._active_path, temp_dir)

        original_kb = results.get("original", 0)
        for quality, label in self._result_labels.items():
            size = results.get(quality)
            if size is None:
                label.configure(text=t("compress_error"))
            else:
                percent = (size / original_kb * 100) if original_kb else 0
                label.configure(text=f"{size:.0f} KB ({percent:.0f}%)")

    def _handle_save(self) -> None:
        if not self._active_path:
            messagebox.showinfo(t("app_title"), t("no_active_file_hint"))
            return

        settings = settings_store.load_settings()
        base_name = os.path.splitext(os.path.basename(self._active_path))[0]
        default_path = os.path.join(settings.get("output_dir", "~"), f"{base_name}_komprimiert.pdf")
        output_path = filedialog.asksaveasfilename(
            initialfile=os.path.basename(default_path),
            initialdir=os.path.dirname(default_path),
            defaultextension=".pdf",
            filetypes=[("PDF-Dateien", "*.pdf")],
        )
        if not output_path:
            return

        success = compress_pdf(self._active_path, output_path, self._quality_var.get())
        if success:
            load_result_file(self._file_manager, output_path)
            messagebox.showinfo(t("app_title"), t("save_success"))
        else:
            messagebox.showerror(t("app_title"), t("error_generic"))

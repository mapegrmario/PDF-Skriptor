"""
security_ui.py
UI fuer das Sicherheits-Modul: Passwort setzen und Rechte
(Drucken/Kopieren) fuer die aktive PDF-Datei einschraenken.
"""

import os
import tkinter.filedialog as filedialog
from tkinter import messagebox
import customtkinter as ctk
from language import t
import settings as settings_store
import theme
from security_logic import encrypt_pdf
from file_list_sync import sync_active_file


class SecurityView(ctk.CTkFrame):
    """Ansicht zum Verschluesseln der aktiven PDF-Datei mit Passwort und Rechten."""

    def __init__(self, master, file_manager) -> None:
        super().__init__(master, fg_color=theme.COLOR_BG)
        self._file_manager = file_manager
        self._active_path: str | None = None
        self._allow_print_var = ctk.BooleanVar(value=True)
        self._allow_copy_var = ctk.BooleanVar(value=True)
        self._build_ui()
        sync_active_file(self, self._file_manager, self._handle_active_changed)

    def _build_ui(self) -> None:
        title = ctk.CTkLabel(self, text=t("nav_security"), font=theme.font_title(), text_color=theme.COLOR_TEXT)
        title.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(theme.PADDING_LARGE, theme.PADDING_SMALL))

        self._active_file_label = ctk.CTkLabel(self, text="", font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED)
        self._active_file_label.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        card = ctk.CTkFrame(self, fg_color=theme.COLOR_BG_SECONDARY, corner_radius=theme.CORNER_RADIUS)
        card.pack(fill="x", padx=theme.PADDING_LARGE, pady=theme.PADDING_SMALL)

        self._password_entry = self._build_password_row(card, "Passwort zum Öffnen")

        rights_row = ctk.CTkFrame(card, fg_color="transparent")
        rights_row.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=theme.PADDING_SMALL)
        ctk.CTkCheckBox(rights_row, text=t("security_allow_print"), variable=self._allow_print_var).pack(anchor="w", pady=(0, theme.PADDING_SMALL))
        ctk.CTkCheckBox(rights_row, text=t("security_allow_copy"), variable=self._allow_copy_var).pack(anchor="w")

        save_button = ctk.CTkButton(
            self, text=t("security_encrypt_button"), fg_color=theme.COLOR_ACCENT,
            hover_color=theme.COLOR_ACCENT_HOVER, corner_radius=theme.CORNER_RADIUS,
            command=self._handle_save,
        )
        save_button.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(theme.PADDING_MEDIUM, theme.PADDING_LARGE))

    def _build_password_row(self, card, label_text: str) -> ctk.CTkEntry:
        row = ctk.CTkFrame(card, fg_color="transparent")
        row.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=theme.PADDING_MEDIUM)

        label = ctk.CTkLabel(row, text=label_text, font=theme.font_small(), text_color=theme.COLOR_TEXT, anchor="w")
        label.pack(anchor="w")

        entry = ctk.CTkEntry(row, show="•")
        entry.pack(fill="x", pady=(2, 0))
        return entry

    def _handle_active_changed(self, path: str | None) -> None:
        self._active_path = path
        if path:
            self._active_file_label.configure(text=f"📄 {os.path.basename(path)}")
        else:
            self._active_file_label.configure(text=t("no_active_file_hint"))

    def _handle_save(self) -> None:
        if not self._active_path:
            messagebox.showinfo(t("app_title"), t("no_active_file_hint"))
            return

        password = self._password_entry.get()
        if not password:
            messagebox.showinfo(t("app_title"), "Bitte ein Passwort eingeben.")
            return

        settings = settings_store.load_settings()
        base_name = os.path.splitext(os.path.basename(self._active_path))[0]
        default_path = os.path.join(settings.get("output_dir", "~"), f"{base_name}_geschützt.pdf")
        output_path = filedialog.asksaveasfilename(
            initialfile=os.path.basename(default_path),
            initialdir=os.path.dirname(default_path),
            defaultextension=".pdf",
            filetypes=[("PDF-Dateien", "*.pdf")],
        )
        if not output_path:
            return

        success = encrypt_pdf(
            self._active_path, output_path, password, password,
            allow_printing=self._allow_print_var.get(),
            allow_copying=self._allow_copy_var.get(),
        )
        if success:
            # Bewusst KEIN load_result_file() wie bei den anderen Werkzeugen:
            # Die Ergebnisdatei ist passwortgeschuetzt, ein automatisches
            # Aktivieren wuerde die Dokumentenansicht nur mit einer
            # "Datei kann nicht geoeffnet werden"-Meldung zeigen. Die Datei
            # steht trotzdem direkt in der Werkbank bereit.
            self._file_manager.add_files([output_path])
            messagebox.showinfo(t("app_title"), t("save_success"))
        else:
            messagebox.showerror(t("app_title"), t("error_generic"))

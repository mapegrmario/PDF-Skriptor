"""
pipeline_step_row.py
Stellt eine einzelne Zeile in der Pipeline-Werkzeugkette dar: Auswahl
des Werkzeugtyps plus dessen spezifische Parameter (z. B. Passwort,
Qualitätsstufe, Drehwinkel).
"""

import customtkinter as ctk
from language import t
import theme
from pipeline_logic import get_step_types


class PipelineStepRow(ctk.CTkFrame):
    """Eine Zeile mit Werkzeugtyp-Auswahl und dazugehoerigen Parametern."""

    def __init__(self, master, on_remove) -> None:
        super().__init__(master, fg_color=theme.COLOR_BG_SECONDARY, corner_radius=theme.CORNER_RADIUS)
        self._on_remove = on_remove
        self._param_widgets: dict[str, ctk.CTkBaseClass] = {}
        self._param_area: ctk.CTkFrame | None = None
        self._build_ui()

    def _build_ui(self) -> None:
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.pack(fill="x", padx=theme.PADDING_SMALL, pady=theme.PADDING_SMALL)

        self._step_types = get_step_types()
        self._type_selector = ctk.CTkOptionMenu(header, values=list(self._step_types.values()), command=self._handle_type_changed)
        self._type_selector.pack(side="left", padx=(0, theme.PADDING_MEDIUM))

        remove_button = ctk.CTkButton(
            header, text="✕", width=28, fg_color="transparent", text_color=theme.COLOR_TEXT_MUTED,
            hover_color=theme.COLOR_ACCENT_SOFT, command=lambda: self._on_remove(self),
        )
        remove_button.pack(side="right")

        self._param_area = ctk.CTkFrame(self, fg_color="transparent")
        self._param_area.pack(fill="x", padx=theme.PADDING_SMALL, pady=(0, theme.PADDING_SMALL))
        self._render_params("rotate")

    def _handle_type_changed(self, label: str) -> None:
        step_type = self._label_to_type(label)
        self._render_params(step_type)

    def _label_to_type(self, label: str) -> str:
        for key, value in self._step_types.items():
            if value == label:
                return key
        return "rotate"

    def _render_params(self, step_type: str) -> None:
        for child in self._param_area.winfo_children():
            child.destroy()
        self._param_widgets.clear()

        if step_type == "rotate":
            selector = ctk.CTkSegmentedButton(self._param_area, values=["90°", "180°", "270°"])
            selector.set("90°")
            selector.pack(anchor="w")
            self._param_widgets["degrees"] = selector
        elif step_type == "compress":
            quality_values = {t("quality_high"): "hoch", t("quality_medium"): "mittel", t("quality_low"): "niedrig"}
            self._quality_by_display = quality_values
            selector = ctk.CTkSegmentedButton(self._param_area, values=list(quality_values.keys()))
            selector.set(t("quality_medium"))
            selector.pack(anchor="w")
            self._param_widgets["quality"] = selector
        elif step_type == "encrypt":
            entry = ctk.CTkEntry(self._param_area, placeholder_text=t("pipeline_password_placeholder"), show="•")
            entry.pack(anchor="w", fill="x")
            self._param_widgets["password"] = entry
        elif step_type == "metadata":
            entry = ctk.CTkEntry(self._param_area, placeholder_text=t("pipeline_author_placeholder"))
            entry.pack(anchor="w", fill="x")
            self._param_widgets["author"] = entry

    def get_step_config(self) -> dict:
        """Liest den aktuellen Werkzeugtyp und die Parameter dieser Zeile aus."""
        step_type = self._label_to_type(self._type_selector.get())
        params = {}

        if step_type == "rotate":
            widget = self._param_widgets.get("degrees")
            params["degrees"] = int(widget.get().replace("°", "")) if widget else 90
        elif step_type == "compress":
            widget = self._param_widgets.get("quality")
            params["quality"] = self._quality_by_display.get(widget.get(), "mittel") if widget else "mittel"
        elif step_type == "encrypt":
            widget = self._param_widgets.get("password")
            params["password"] = widget.get() if widget else ""
        elif step_type == "metadata":
            widget = self._param_widgets.get("author")
            params["values"] = {"/Author": widget.get()} if widget else {}

        return {"type": step_type, "params": params}

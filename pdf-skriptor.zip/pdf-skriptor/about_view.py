"""
about_view.py
Zeigt die "Ueber dieses Programm"-Ansicht: Autor, Kontakt,
Haftungsausschluss und verwendete Drittanbieter-Software.
"""

import os
import customtkinter as ctk
from PIL import Image
from language import t
import theme
from scroll_helpers import bind_mousewheel_scroll
from install_check import check_dependencies

APP_VERSION = "1.0.0"
AUTHOR_NAME = "Mario Peeß"
AUTHOR_LOCATION = "Großenhain"
AUTHOR_EMAIL = "mapegr@mailbox.org"

# (Bibliotheksname, Lizenz-Kurzbezeichnung(en) OHNE das Wort "Lizenz"/
# "License" - {or} wird durch das uebersetzte Wort fuer "oder"/"or" ersetzt -,
# optionaler Uebersetzungsschluessel fuer einen Zusatzhinweis). Bewusst nicht
# als fertiger String hinterlegt, da diese Liste sonst bei Sprachumschaltung
# immer Deutsch bliebe (siehe analyse.md, behobener Fehler).
_THIRD_PARTY_LIBS = [
    ("CustomTkinter", "MIT", None),
    ("pypdf", "BSD", None),
    ("pikepdf / qpdf", "MPL 2.0 / Apache", None),
    ("PyMuPDF / MuPDF", "AGPL", None),
    ("Pillow", "HPND", None),
    ("pyHanko / pyhanko-certvalidator", "MIT", None),
    ("cryptography", "Apache-2.0 {or} BSD-3-Clause", None),
    ("Ghostscript", "AGPL", "about_external_program_one"),
    ("ocrmypdf / Tesseract OCR", "MPL 2.0 / Apache", "about_external_program_many"),
]

_AVATAR_FILENAME = "avatar.png"


class AboutView(ctk.CTkFrame):
    """Statische Info-Ansicht ueber die Anwendung."""

    def __init__(self, master) -> None:
        super().__init__(master, fg_color=theme.COLOR_BG)
        self._build_ui()

    def _build_ui(self) -> None:
        scroll_area = ctk.CTkScrollableFrame(self, fg_color="transparent")
        scroll_area.pack(fill="both", expand=True, padx=theme.PADDING_MEDIUM, pady=theme.PADDING_MEDIUM)
        bind_mousewheel_scroll(scroll_area)

        self._build_header(scroll_area)
        self._build_author_card(scroll_area)
        self._build_disclaimer_card(scroll_area)
        self._build_dependencies_card(scroll_area)
        self._build_thirdparty_card(scroll_area)

    def _build_header(self, parent) -> None:
        header = ctk.CTkFrame(parent, fg_color="transparent")
        header.pack(fill="x", pady=(0, theme.PADDING_MEDIUM))

        avatar_image = self._load_avatar()
        if avatar_image is not None:
            avatar_label = ctk.CTkLabel(header, image=avatar_image, text="")
            avatar_label.pack(anchor="w", pady=(0, theme.PADDING_SMALL))

        title = ctk.CTkLabel(
            header, text=t("about_title"), font=theme.font_heading(), text_color=theme.COLOR_TEXT
        )
        title.pack(anchor="w")

        version_label = ctk.CTkLabel(
            header, text=f"{t('app_title')} · Version {APP_VERSION}",
            font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED,
        )
        version_label.pack(anchor="w", pady=(2, 0))

    def _build_author_card(self, parent) -> None:
        card = self._make_card(parent)
        self._add_row(card, t("about_author"), f"{AUTHOR_NAME} · {AUTHOR_LOCATION}")
        self._add_row(card, t("about_email"), AUTHOR_EMAIL)

    def _build_disclaimer_card(self, parent) -> None:
        card = self._make_card(parent)
        heading = ctk.CTkLabel(
            card, text=t("about_disclaimer_title"), font=theme.font_heading(),
            text_color=theme.COLOR_ACCENT,
        )
        heading.pack(anchor="w", padx=theme.PADDING_MEDIUM, pady=(theme.PADDING_MEDIUM, 4))

        body = ctk.CTkLabel(
            card, text=t("about_disclaimer_text"), font=theme.font_body(),
            text_color=theme.COLOR_TEXT, wraplength=300, justify="left",
        )
        body.pack(anchor="w", padx=theme.PADDING_MEDIUM, pady=(0, theme.PADDING_MEDIUM))

    def _build_thirdparty_card(self, parent) -> None:
        card = self._make_card(parent)
        heading = ctk.CTkLabel(
            card, text=t("about_thirdparty_title"), font=theme.font_heading(),
            text_color=theme.COLOR_ACCENT,
        )
        heading.pack(anchor="w", padx=theme.PADDING_MEDIUM, pady=(theme.PADDING_MEDIUM, 4))

        for name, license_ids, extra_key in _THIRD_PARTY_LIBS:
            license_text = license_ids.replace("{or}", t("about_license_or"))
            suffix = f", {t(extra_key)}" if extra_key else ""
            label_text = f"• {name} ({license_text} {t('about_license_word')}{suffix})"
            entry = ctk.CTkLabel(
                card, text=label_text, font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED,
            )
            entry.pack(anchor="w", padx=theme.PADDING_MEDIUM, pady=1)
        spacer = ctk.CTkLabel(card, text="")
        spacer.pack(pady=(0, theme.PADDING_SMALL))

    def _build_dependencies_card(self, parent) -> None:
        """QA-Fix (Usability-Audit, Befund 1.2): Diese Information stand
        vorher in einem blockierenden Warndialog GANZ am Anfang des allerersten
        Programmstarts, noch vor der eigentlichen Oberflaeche - fuer einen
        Zustand, der nur 1 von 18 Werkzeugen betrifft. Jetzt hier dezent
        nachschlagbar; die betroffenen Werkzeuge (OCR, Komprimieren) zeigen
        ihren eigenen Hinweis weiterhin direkt inline, wenn man sie oeffnet."""
        missing = check_dependencies()
        if not missing:
            return

        card = self._make_card(parent)
        heading = ctk.CTkLabel(
            card, text=t("about_dependencies_title"), font=theme.font_heading(),
            text_color=theme.COLOR_WARNING,
        )
        heading.pack(anchor="w", padx=theme.PADDING_MEDIUM, pady=(theme.PADDING_MEDIUM, 4))

        intro = ctk.CTkLabel(
            card, text=t("about_dependencies_intro"), font=theme.font_body(),
            text_color=theme.COLOR_TEXT, wraplength=300, justify="left",
        )
        intro.pack(anchor="w", padx=theme.PADDING_MEDIUM, pady=(0, theme.PADDING_SMALL))

        for tool, hints in missing.items():
            tool_label = ctk.CTkLabel(
                card, text=f"• {tool}", font=theme.font_body(), text_color=theme.COLOR_TEXT,
            )
            tool_label.pack(anchor="w", padx=theme.PADDING_MEDIUM)
            for distro, command in hints.items():
                hint_label = ctk.CTkLabel(
                    card, text=f"   {distro}: {command}", font=theme.font_small(),
                    text_color=theme.COLOR_TEXT_MUTED, wraplength=300, justify="left",
                )
                hint_label.pack(anchor="w", padx=theme.PADDING_MEDIUM)
        spacer = ctk.CTkLabel(card, text="")
        spacer.pack(pady=(0, theme.PADDING_SMALL))

    def _make_card(self, parent) -> ctk.CTkFrame:
        card = ctk.CTkFrame(parent, fg_color=theme.COLOR_BG_SECONDARY, corner_radius=theme.CORNER_RADIUS)
        card.pack(fill="x", pady=theme.PADDING_SMALL)
        return card

    def _add_row(self, card, label: str, value: str) -> None:
        row = ctk.CTkFrame(card, fg_color="transparent")
        row.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=(theme.PADDING_MEDIUM, 2))

        label_widget = ctk.CTkLabel(row, text=f"{label}:", font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED, width=70, anchor="w")
        label_widget.pack(side="left")

        value_widget = ctk.CTkLabel(row, text=value, font=theme.font_body(), text_color=theme.COLOR_TEXT, anchor="w")
        value_widget.pack(side="left")

    def _load_avatar(self):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        avatar_path = os.path.join(base_dir, _AVATAR_FILENAME)
        if not os.path.isfile(avatar_path):
            return None
        try:
            pil_image = Image.open(avatar_path)
            return ctk.CTkImage(light_image=pil_image, dark_image=pil_image, size=(64, 64))
        except Exception:  # noqa: BLE001
            return None


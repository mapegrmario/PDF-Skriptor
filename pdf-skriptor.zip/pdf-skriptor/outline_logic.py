"""
outline_logic.py
Liest und schreibt das Inhaltsverzeichnis (Lesezeichen/Bookmarks) einer
PDF-Datei ueber PyMuPDF. Ein Eintrag besteht aus Ebene (1 = oberste
Ebene), Titel und Zielseite - beides in der 1-basierten Zaehlung, wie
sie auch in der Benutzeroberflaeche angezeigt wird.
"""

import pymupdf as fitz  # "fitz" ist der veraltete Alias, siehe PyMuPDF-Deprecation-Hinweis
from logger_setup import log_exception


def read_outline(path: str) -> list[dict]:
    """Liest das vorhandene Inhaltsverzeichnis. Leere Liste, wenn keins
    vorhanden ist oder die Datei nicht gelesen werden kann."""
    try:
        document = fitz.open(path)
        toc = document.get_toc(simple=True)
        document.close()
        return [{"level": level, "title": title, "page": page} for level, title, page in toc]
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Lesen des Inhaltsverzeichnisses", exc)
        return []


def get_page_count(path: str) -> int:
    try:
        document = fitz.open(path)
        count = document.page_count
        document.close()
        return count
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Ermitteln der Seitenzahl", exc)
        return 0


def write_outline(path: str, output_path: str, entries: list[dict]) -> bool:
    """Schreibt eine neue Liste von Lesezeichen in eine (ggf. neue) Datei.
    Eine leere Liste entfernt ein vorhandenes Inhaltsverzeichnis."""
    try:
        document = fitz.open(path)
        toc = [[entry["level"], entry["title"], entry["page"]] for entry in entries]
        document.set_toc(toc)
        document.save(output_path)
        document.close()
        return True
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Speichern des Inhaltsverzeichnisses", exc)
        return False

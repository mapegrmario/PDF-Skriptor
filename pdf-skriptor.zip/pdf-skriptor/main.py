"""
main.py
Einstiegspunkt fuer PDF Skriptor. Startet Logging, prueft
Systemabhaengigkeiten und oeffnet das Hauptfenster.
"""

import sys
import theme
from logger_setup import setup_logger, log_exception
from install_check import check_dependencies
from app_window import AppWindow


def main() -> int:
    logger = setup_logger()
    logger.info("PDF Skriptor wird gestartet")
    theme.apply_base_theme()

    # QA-Fix (Usability-Audit, Befund 1.2): Frueher hier ein blockierender
    # Warndialog VOR der ersten sichtbaren Oberflaeche, obwohl nur 1 von 18
    # Werkzeugen betroffen ist. Fehlende Abhaengigkeiten werden weiterhin
    # geloggt und stehen jetzt dezent im "Über dieses Programm"-Tab
    # (about_view.py); die betroffenen Werkzeuge selbst (OCR, Komprimieren)
    # zeigen ihren eigenen Hinweis unveraendert direkt inline an.
    missing = check_dependencies()
    for tool in missing:
        logger.warning("Fehlende Abhängigkeit: %s", tool)

    try:
        app = AppWindow()
        app.mainloop()
        logger.info("PDF Skriptor wurde beendet")
        return 0
    except Exception as exc:  # noqa: BLE001
        log_exception("Unerwarteter Fehler beim Programmstart", exc)
        return 1


if __name__ == "__main__":
    sys.exit(main())

"""
watermark_ui.py
UI fuer das Wasserzeichen-Modul: Text, Farbe, Schriftgroesse,
Transparenz und Rotationswinkel fuer ein diagonales Wasserzeichen, das
auf jede Seite der aktiven Datei angewendet wird.
"""

import os
import tkinter.filedialog as filedialog
from tkinter import messagebox
import customtkinter as ctk
from language import t
import settings as settings_store
import theme
from watermark_logic import apply_watermark
from file_list_sync import sync_active_file, load_result_file

_PALETTE = [
    ("#8C8C8C", (0.55, 0.55, 0.55)),
    ("#E01A1A", (0.88, 0.10, 0.10)),
    ("#2F6FED", (0.18, 0.44, 0.93)),
    ("#2FAE60", (0.18, 0.68, 0.38)),
]


class WatermarkView(ctk.CTkFrame):
    """Ansicht zum Anwenden eines Text-Wasserzeichens auf alle Seiten."""

    def __init__(self, master, file_manager) -> None:
        super().__init__(master, fg_color=theme.COLOR_BG)
        self._file_manager = file_manager
        self._active_path: str | None = None
        self._selected_color = _PALETTE[0][1]
        self._swatch_buttons: list[ctk.CTkButton] = []
        self._build_ui()
        sync_active_file(self, self._file_manager, self._handle_active_changed)

    def _build_ui(self) -> None:
        title = ctk.CTkLabel(self, text=t("nav_watermark"), font=theme.font_title(), text_color=theme.COLOR_TEXT)
        title.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(theme.PADDING_LARGE, theme.PADDING_SMALL))

        self._active_file_label = ctk.CTkLabel(self, text="", font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED)
        self._active_file_label.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        card = ctk.CTkFrame(self, fg_color=theme.COLOR_BG_SECONDARY, corner_radius=theme.CORNER_RADIUS)
        card.pack(fill="x", padx=theme.PADDING_LARGE, pady=theme.PADDING_SMALL)

        ctk.CTkLabel(card, text=t("watermark_text_label"), font=theme.font_small(), text_color=theme.COLOR_TEXT, anchor="w").pack(anchor="w", padx=theme.PADDING_MEDIUM, pady=(theme.PADDING_MEDIUM, 2))
        self._text_entry = ctk.CTkEntry(card, placeholder_text=t("watermark_text_placeholder"))
        self._text_entry.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=(0, theme.PADDING_SMALL))

        self._color_row = ctk.CTkFrame(card, fg_color="transparent")
        self._color_row.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=(0, theme.PADDING_SMALL))
        ctk.CTkLabel(self._color_row, text=t("watermark_color_label"), font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED).pack(side="left", padx=(0, 8))
        for hex_color, rgb in _PALETTE:
            button = ctk.CTkButton(
                self._color_row, text="", width=24, height=24, corner_radius=12,
                fg_color=hex_color, hover_color=hex_color, border_width=2,
                border_color=theme.COLOR_ACCENT if rgb == self._selected_color else hex_color,
                command=lambda c=rgb: self._select_color(c),
            )
            button.pack(side="left", padx=3)
            self._swatch_buttons.append(button)

        self._font_size_slider = self._build_slider_row(card, t("watermark_font_size"), 24, 120, 54)
        self._opacity_slider = self._build_slider_row(card, t("watermark_opacity"), 5, 80, 25)
        self._rotation_slider = self._build_slider_row(card, t("watermark_rotation"), 0, 90, 45)

        save_button = ctk.CTkButton(
            self, text=t("watermark_apply"), fg_color=theme.COLOR_ACCENT, hover_color=theme.COLOR_ACCENT_HOVER,
            corner_radius=theme.CORNER_RADIUS, command=self._handle_save,
        )
        save_button.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(theme.PADDING_MEDIUM, theme.PADDING_LARGE))

    def _build_slider_row(self, card, label_text: str, from_: float, to: float, default: float) -> ctk.CTkSlider:
        row = ctk.CTkFrame(card, fg_color="transparent")
        row.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=(0, theme.PADDING_SMALL))
        ctk.CTkLabel(row, text=label_text, font=theme.font_small(), text_color=theme.COLOR_TEXT, anchor="w").pack(anchor="w")
        slider = ctk.CTkSlider(row, from_=from_, to=to, number_of_steps=int(to - from_))
        slider.set(default)
        slider.pack(fill="x", pady=(2, 4))
        return slider

    def _select_color(self, rgb: tuple) -> None:
        self._selected_color = rgb
        for button, (hex_color, palette_rgb) in zip(self._swatch_buttons, _PALETTE):
            button.configure(border_color=theme.COLOR_ACCENT if palette_rgb == rgb else hex_color)

    def _handle_active_changed(self, path: str | None) -> None:
        self._active_path = path
        if path:
            self._active_file_label.configure(text=f"📄 {os.path.basename(path)}")
        else:
            self._active_file_label.configure(text=t("no_active_file_hint"))

    def _handle_save(self) -> None:
        if not self._active_path:
            messagebox.showinfo(t("app_title"), t("no_active_file_hint"))
            return
        text = self._text_entry.get().strip()
        if not text:
            messagebox.showinfo(t("app_title"), t("watermark_nothing_to_apply"))
            return

        settings = settings_store.load_settings()
        base_name = os.path.splitext(os.path.basename(self._active_path))[0]
        default_path = os.path.join(settings.get("output_dir", "~"), f"{base_name}_wasserzeichen.pdf")
        output_path = filedialog.asksaveasfilename(
            initialfile=os.path.basename(default_path),
            initialdir=os.path.dirname(default_path),
            defaultextension=".pdf",
            filetypes=[("PDF-Dateien", "*.pdf")],
        )
        if not output_path:
            return

        success = apply_watermark(
            self._active_path, output_path, text,
            font_size=self._font_size_slider.get(),
            opacity=self._opacity_slider.get() / 100,
            rotation=self._rotation_slider.get(),
            color=self._selected_color,
        )
        if success:
            load_result_file(self._file_manager, output_path)
            messagebox.showinfo(t("app_title"), t("save_success"))
        else:
            messagebox.showerror(t("app_title"), t("error_generic"))

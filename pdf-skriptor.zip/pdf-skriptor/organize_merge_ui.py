"""
organize_merge_ui.py
Unter-Werkzeug: Fasst mehrere geladene PDF-Dateien in der angezeigten
Reihenfolge zu einer neuen Datei zusammen.
"""

import os
import tkinter.filedialog as filedialog
from tkinter import messagebox
import customtkinter as ctk
from language import t
import settings as settings_store
import theme
from organize_logic import merge_pdfs
from merge_file_card import MergeFileCard
from file_list_sync import sync_refresh_callback, load_result_file


class OrganizeMergeTool(ctk.CTkFrame):
    """UI zum Zusammenfuegen der aktuell geladenen PDF-Dateien - die
    Reihenfolge laesst sich per Drag & Drop direkt hier aendern (QA-Fix,
    vorher nur ueber Umweg via Werkbank). Eine Aenderung wirkt auf die
    gemeinsame Dateiliste (file_manager.reorder_files), damit Werkbank
    und dieses Werkzeug immer dieselbe Reihenfolge zeigen."""

    def __init__(self, master, file_manager) -> None:
        super().__init__(master, fg_color="transparent")
        self._file_manager = file_manager
        self._list_frame: ctk.CTkFrame | None = None
        self._rows: list[dict] = []
        self._dragging_card: MergeFileCard | None = None
        self._build_ui()
        sync_refresh_callback(self, self._file_manager, lambda files: self._refresh_file_list())

    def _build_ui(self) -> None:
        hint = ctk.CTkLabel(
            self, text=t("merge_hint"), font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED,
            wraplength=300, justify="left",
        )
        hint.pack(anchor="w", pady=(0, theme.PADDING_MEDIUM))

        self._list_frame = ctk.CTkScrollableFrame(self, fg_color=theme.COLOR_BG_SECONDARY, corner_radius=theme.CORNER_RADIUS)
        self._list_frame.pack(fill="both", expand=True, pady=(0, theme.PADDING_MEDIUM))
        self._refresh_file_list()

        merge_button = ctk.CTkButton(
            self, text=t("merge_button"), fg_color=theme.COLOR_ACCENT,
            hover_color=theme.COLOR_ACCENT_HOVER, corner_radius=theme.CORNER_RADIUS,
            command=self._handle_merge,
        )
        merge_button.pack(anchor="w")

    def _refresh_file_list(self) -> None:
        # Waehrend eines laufenden Drags nicht neu aufbauen - der
        # Listener feuert bei jeder reorder_files()-Aenderung erneut und
        # wuerde sonst die gerade gezogene Karte unter dem Mauszeiger
        # zerstoeren.
        if self._dragging_card is not None:
            return
        for row in self._rows:
            row["card"].destroy()
        self._rows = []
        files = self._file_manager.get_files()
        if not files:
            empty_label = ctk.CTkLabel(self._list_frame, text=t("no_files_loaded"), font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED)
            empty_label.pack(padx=theme.PADDING_MEDIUM, pady=theme.PADDING_MEDIUM)
            self._rows.append({"path": None, "card": empty_label})
            return
        for path in files:
            card = MergeFileCard(
                self._list_frame, path, on_drag_start=self._handle_drag_start,
                on_drag_motion=self._handle_drag_motion, on_drag_end=self._handle_drag_end,
            )
            card.pack(fill="x", padx=theme.PADDING_SMALL, pady=(theme.PADDING_SMALL, 0))
            self._rows.append({"path": path, "card": card})
        self._renumber_rows()

    def _renumber_rows(self) -> None:
        for position, row in enumerate(self._rows, start=1):
            row["card"].set_position(position)

    def _handle_drag_start(self, card: MergeFileCard) -> None:
        self._dragging_card = card
        card.set_dragging(True)

    def _handle_drag_motion(self, card: MergeFileCard, pointer_y: int) -> None:
        if self._dragging_card is not card:
            return
        current_pos = self._index_of(card)
        if current_pos < 0:
            return
        for index, row in enumerate(self._rows):
            if row["card"] is card:
                continue
            other_card = row["card"]
            mid_y = other_card.winfo_rooty() + other_card.winfo_height() // 2
            if current_pos < index and pointer_y > mid_y:
                self._move_row(current_pos, index)
                break
            if current_pos > index and pointer_y < mid_y:
                self._move_row(current_pos, index)
                break

    def _handle_drag_end(self, card: MergeFileCard) -> None:
        card.set_dragging(False)
        self._dragging_card = None
        self._file_manager.reorder_files([row["path"] for row in self._rows])

    def _index_of(self, card: MergeFileCard) -> int:
        for index, row in enumerate(self._rows):
            if row["card"] is card:
                return index
        return -1

    def _move_row(self, from_index: int, to_index: int) -> None:
        row = self._rows.pop(from_index)
        self._rows.insert(to_index, row)
        for r in self._rows:
            r["card"].pack_forget()
        for r in self._rows:
            r["card"].pack(fill="x", padx=theme.PADDING_SMALL, pady=(theme.PADDING_SMALL, 0))
        self._renumber_rows()

    def _handle_merge(self) -> None:
        files = self._file_manager.get_files()
        if len(files) < 2:
            messagebox.showinfo(t("app_title"), t("merge_need_two_files"))
            return

        settings = settings_store.load_settings()
        default_path = os.path.join(settings.get("output_dir", "~"), "Zusammengefuegt.pdf")
        output_path = filedialog.asksaveasfilename(
            initialfile=os.path.basename(default_path),
            initialdir=os.path.dirname(default_path),
            defaultextension=".pdf",
            filetypes=[("PDF-Dateien", "*.pdf")],
        )
        if not output_path:
            return

        success = merge_pdfs(files, output_path)
        if success:
            load_result_file(self._file_manager, output_path)
            messagebox.showinfo(t("app_title"), t("save_success"))
        else:
            messagebox.showerror(t("app_title"), t("error_generic"))

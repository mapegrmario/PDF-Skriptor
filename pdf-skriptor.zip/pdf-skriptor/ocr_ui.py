"""
ocr_ui.py
UI fuer das OCR-Modul: Sprache waehlen, Verarbeitung im Hintergrund
starten (Fortschrittsbalken), Ergebnis speichern. Arbeitet immer mit
der aktuell aktiven Datei aus der Werkbank.
"""

import os
import threading
import tkinter.filedialog as filedialog
from tkinter import messagebox
import customtkinter as ctk
from language import t
import settings as settings_store
import theme
from ocr_logic import run_ocr, is_ocrmypdf_available, LANGUAGE_OPTIONS
from file_list_sync import sync_active_file, load_result_file


class OcrView(ctk.CTkFrame):
    """Ansicht zur OCR-Texterkennung der aktiven Datei mit Fortschrittsanzeige."""

    def __init__(self, master, file_manager) -> None:
        super().__init__(master, fg_color=theme.COLOR_BG)
        self._file_manager = file_manager
        self._active_path: str | None = None
        self._build_ui()

    def _build_ui(self) -> None:
        title = ctk.CTkLabel(self, text=t("ocr_title"), font=theme.font_title(), text_color=theme.COLOR_TEXT)
        title.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(theme.PADDING_LARGE, theme.PADDING_SMALL))

        if not is_ocrmypdf_available():
            warning = ctk.CTkLabel(
                self, text=t("ocr_missing_tool"),
                font=theme.font_body(), text_color=theme.COLOR_WARNING, wraplength=300, justify="left",
            )
            warning.pack(anchor="w", padx=theme.PADDING_LARGE, pady=theme.PADDING_MEDIUM)
            return

        self._active_file_label = ctk.CTkLabel(self, text="", font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED)
        self._active_file_label.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        self._language_selector = ctk.CTkOptionMenu(self, values=list(LANGUAGE_OPTIONS.keys()))
        self._language_selector.set("Deutsch")
        self._language_selector.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        self._progress_bar = ctk.CTkProgressBar(self, mode="indeterminate")
        self._progress_bar.pack(fill="x", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))
        self._progress_bar.pack_forget()

        self._status_label = ctk.CTkLabel(self, text="", font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED)
        self._status_label.pack(anchor="w", padx=theme.PADDING_LARGE)

        self._start_button = ctk.CTkButton(
            self, text=t("ocr_create_searchable"), fg_color=theme.COLOR_ACCENT,
            hover_color=theme.COLOR_ACCENT_HOVER, corner_radius=theme.CORNER_RADIUS,
            command=self._handle_start,
        )
        self._start_button.pack(anchor="w", padx=theme.PADDING_LARGE, pady=theme.PADDING_MEDIUM)

        sync_active_file(self, self._file_manager, self._handle_active_changed)

    def _handle_active_changed(self, path: str | None) -> None:
        self._active_path = path
        if path:
            self._active_file_label.configure(text=f"📄 {os.path.basename(path)}")
        else:
            self._active_file_label.configure(text=t("no_active_file_hint"))

    def _handle_start(self) -> None:
        if not self._active_path:
            messagebox.showinfo(t("app_title"), t("no_active_file_hint"))
            return

        settings = settings_store.load_settings()
        base_name = os.path.splitext(os.path.basename(self._active_path))[0]
        default_path = os.path.join(settings.get("output_dir", "~"), f"{base_name}_durchsuchbar.pdf")
        output_path = filedialog.asksaveasfilename(
            initialfile=os.path.basename(default_path),
            initialdir=os.path.dirname(default_path),
            defaultextension=".pdf",
            filetypes=[("PDF-Dateien", "*.pdf")],
        )
        if not output_path:
            return

        language_code = LANGUAGE_OPTIONS[self._language_selector.get()]
        self._set_running(True)
        thread = threading.Thread(
            target=self._run_in_background, args=(self._active_path, output_path, language_code), daemon=True,
        )
        thread.start()

    def _run_in_background(self, input_path: str, output_path: str, language: str) -> None:
        success, message = run_ocr(input_path, output_path, language)
        self.after(0, lambda: self._on_finished(success, message, output_path))

    def _set_running(self, running: bool) -> None:
        if running:
            self._progress_bar.pack(fill="x", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))
            self._progress_bar.start()
            self._status_label.configure(text=t("ocr_running"))
            self._start_button.configure(state="disabled")
        else:
            self._progress_bar.stop()
            self._progress_bar.pack_forget()
            self._start_button.configure(state="normal")

    def _on_finished(self, success: bool, message: str, output_path: str) -> None:
        self._set_running(False)
        if success:
            load_result_file(self._file_manager, output_path)
            self._status_label.configure(text=t("save_success"))
            messagebox.showinfo(t("app_title"), t("save_success"))
        else:
            self._status_label.configure(text=t("ocr_failed"))
            messagebox.showerror(t("app_title"), message or t("error_generic"))

"""
annotate_interaction.py
Kapselt saemtliche Maus-Interaktion auf der zentralen Dokumentenansicht
fuer das Anmerkungen-Werkzeug (Zeichnen, Hervorheben, Stempeln,
Radieren). Ausgelagert aus annotate_ui.py, damit dort nur noch der
Aufbau des Werkzeug-Panels steht - diese Klasse kennt die konkrete
Panel-Gestaltung nicht, sondern erhaelt alle benoetigten Informationen
ueber kleine Callback-Funktionen.
"""

from PIL import Image, ImageTk
from annotate_logic import (
    add_ink_stroke, add_highlight, add_stamp, add_text, delete_annot_at_point,
    find_text_annot_at_point, move_text_annot,
)
from signature_logic import load_signature_path, insert_signature, CANVAS_SIZE


class AnnotationInteraction:
    """Bindet/loest Maus-Ereignisse an die Dokumentenansicht und setzt sie
    je nach aktivem Werkzeug in PyMuPDF-Anmerkungen um."""

    def __init__(self, document_view, style_picker, get_active_tool, get_stamp_text, on_added, on_removed, on_erase_miss, on_signature_missing, on_text_requested, on_moved) -> None:
        self._document_view = document_view
        self._style_picker = style_picker
        self._get_active_tool = get_active_tool
        self._get_stamp_text = get_stamp_text
        self._on_added = on_added
        self._on_removed = on_removed
        self._on_erase_miss = on_erase_miss
        self._on_signature_missing = on_signature_missing
        self._on_text_requested = on_text_requested
        self._on_moved = on_moved
        self._drag_points: list[tuple[float, float]] = []
        self._drag_start_canvas: tuple[int, int] | None = None
        self._pending_text_position: tuple[float, float] | None = None
        self._pending_text_page: int | None = None
        self._dragging_text_annot = None
        self._dragging_text_page = None
        self._dragging_text_offset: tuple[float, float] = (0, 0)
        # QA-Fix: PyMuPDF bietet fuer per insert_image() eingefuegte Bilder
        # keine verschiebbare/loeschbare Anmerkung an (anders als Text/
        # Stempel, die echte FreeText-Annotationen sind). Unterschriften
        # bleiben deshalb bis zum Speichern als Liste hier bestehen und
        # werden nur als Overlay gezeichnet (_draw_pending_signatures) -
        # verschieb- und loeschbar wie jede andere Anmerkung. Erst
        # bake_pending_signatures() schreibt sie beim Speichern dauerhaft
        # in die PDF-Seite.
        self._pending_signatures: list[dict] = []
        self._dragging_signature: dict | None = None
        self._dragging_signature_offset: tuple[float, float] = (0, 0)
        self._signature_overlay_images: list = []

    def bind(self) -> None:
        self._document_view.bind_canvas(self.on_mouse_down, self.on_mouse_drag, self.on_mouse_up)
        self._document_view.set_overlay_callback(self._draw_pending_signatures)

    def unbind(self) -> None:
        self._document_view.unbind_canvas()
        self._document_view.clear_overlay_callback()

    def current_color_hex(self) -> str:
        r, g, b = self._style_picker.get_color()
        return f"#{int(r * 255):02x}{int(g * 255):02x}{int(b * 255):02x}"

    def on_mouse_down(self, event) -> None:
        x = self._document_view.canvas_x(event.x)
        y = self._document_view.canvas_y(event.y)
        tool = self._get_active_tool()
        if tool == "stamp":
            self._place_stamp(x, y)
            return
        if tool == "eraser":
            self._erase_at(x, y)
            return
        if tool == "signature":
            self._place_signature(x, y)
            return
        if tool == "text":
            self._start_text_interaction(x, y)
            return
        self._drag_start_canvas = (x, y)
        zoom = self._document_view.get_zoom()
        self._drag_points = [(x / zoom, y / zoom)]

    def on_mouse_drag(self, event) -> None:
        tool = self._get_active_tool()
        if tool == "text":
            if self._dragging_text_annot is not None:
                self._drag_move_text(event)
            return
        if tool == "signature":
            if self._dragging_signature is not None:
                self._drag_move_signature(event)
            return
        if tool in ("stamp", "eraser") or self._drag_start_canvas is None:
            return
        canvas = self._document_view.get_canvas()
        x = self._document_view.canvas_x(event.x)
        y = self._document_view.canvas_y(event.y)
        # QA-Fix (Runde 6): canvas_x()/canvas_y() liefern seit dem Fix fuer
        # den "springt nach rechts"-Bug seitenrelative Koordinaten (siehe
        # Docstring dort) - fuers direkte Zeichnen der Vorschau auf die
        # Canvas wird aber die echte Bildschirmposition gebraucht, also den
        # Versatz hier gezielt wieder addieren.
        offset_x, offset_y = self._document_view.page_offset()
        if tool == "freehand":
            zoom = self._document_view.get_zoom()
            self._drag_points.append((x / zoom, y / zoom))
            canvas.create_line(
                self._drag_points[-2][0] * zoom + offset_x, self._drag_points[-2][1] * zoom + offset_y,
                x + offset_x, y + offset_y, fill=self.current_color_hex(), width=self._style_picker.get_width(), tags="draft",
            )
        else:
            canvas.delete("draft_rect")
            x0, y0 = self._drag_start_canvas
            canvas.create_rectangle(
                x0 + offset_x, y0 + offset_y, x + offset_x, y + offset_y,
                outline=self.current_color_hex(), width=2, tags="draft_rect",
            )

    def on_mouse_up(self, event) -> None:
        tool = self._get_active_tool()
        if tool == "text":
            self._dragging_text_annot = None
            self._dragging_text_page = None
            return
        if tool == "signature":
            self._dragging_signature = None
            return
        document = self._document_view.get_document()
        if tool in ("stamp", "eraser") or self._drag_start_canvas is None or not document:
            return

        zoom = self._document_view.get_zoom()
        page_index = self._document_view.get_page_index()
        x1 = self._document_view.canvas_x(event.x)
        y1 = self._document_view.canvas_y(event.y)
        color = self._style_picker.get_color()

        if tool == "freehand":
            if len(self._drag_points) >= 2:
                add_ink_stroke(document, page_index, self._drag_points, color=color, width=self._style_picker.get_width())
                self._on_added()
        else:
            x0, y0 = self._drag_start_canvas
            if abs(x1 - x0) > 4 and abs(y1 - y0) > 4:
                rect = [min(x0, x1) / zoom, min(y0, y1) / zoom, max(x0, x1) / zoom, max(y0, y1) / zoom]
                add_highlight(document, page_index, rect, color=color)
                self._on_added()

        self._drag_start_canvas = None
        self._drag_points = []
        self._document_view.refresh()

    def _start_text_interaction(self, canvas_x: int, canvas_y: int) -> None:
        """Bei Klick mit aktivem Text-Werkzeug: trifft der Klick ein
        bereits platziertes Textfeld, wird es zum Verschieben-per-Ziehen
        aufgenommen (Korrektur der Platzierung); andernfalls oeffnet sich
        wie bisher der Dialog fuer ein neues Textfeld."""
        document = self._document_view.get_document()
        if not document:
            return
        zoom = self._document_view.get_zoom()
        page_index = self._document_view.get_page_index()
        page_x, page_y = canvas_x / zoom, canvas_y / zoom
        page, hit = find_text_annot_at_point(document, page_index, page_x, page_y)
        if hit is not None:
            self._dragging_text_page = page  # haelt die Annot-Referenz am Leben, siehe Docstring
            self._dragging_text_annot = hit
            self._dragging_text_offset = (page_x - hit.rect.x0, page_y - hit.rect.y0)
            return
        self._request_text(canvas_x, canvas_y)

    def _drag_move_text(self, event) -> None:
        zoom = self._document_view.get_zoom()
        page_x = self._document_view.canvas_x(event.x) / zoom
        page_y = self._document_view.canvas_y(event.y) / zoom
        new_top_left = (page_x - self._dragging_text_offset[0], page_y - self._dragging_text_offset[1])
        if move_text_annot(self._dragging_text_annot, new_top_left):
            self._on_moved()
            self._document_view.refresh()

    def _erase_at(self, canvas_x: int, canvas_y: int) -> None:
        document = self._document_view.get_document()
        if not document:
            return
        zoom = self._document_view.get_zoom()
        page_index = self._document_view.get_page_index()
        page_x, page_y = canvas_x / zoom, canvas_y / zoom

        pending_hit = self._find_pending_signature_at(page_index, page_x, page_y)
        if pending_hit is not None:
            self._pending_signatures.remove(pending_hit)
            self._on_removed()
            self._document_view.refresh()
            return

        removed = delete_annot_at_point(document, page_index, page_x, page_y)
        if removed:
            self._on_removed()
            self._document_view.refresh()
        else:
            self._on_erase_miss()

    def _place_stamp(self, canvas_x: int, canvas_y: int) -> None:
        document = self._document_view.get_document()
        if not document:
            return
        zoom = self._document_view.get_zoom()
        page_index = self._document_view.get_page_index()
        position = (canvas_x / zoom, canvas_y / zoom)
        add_stamp(document, page_index, position, self._get_stamp_text())
        self._on_added()
        self._document_view.refresh()

    def _place_signature(self, canvas_x: int, canvas_y: int) -> None:
        document = self._document_view.get_document()
        if not document:
            return
        zoom = self._document_view.get_zoom()
        page_index = self._document_view.get_page_index()
        page_x, page_y = canvas_x / zoom, canvas_y / zoom

        hit = self._find_pending_signature_at(page_index, page_x, page_y)
        if hit is not None:
            self._dragging_signature = hit
            self._dragging_signature_offset = (page_x - hit["rect"][0], page_y - hit["rect"][1])
            return

        if not load_signature_path():
            self._on_signature_missing()
            return
        width_pt = 130.0
        height_pt = width_pt * (CANVAS_SIZE[1] / CANVAS_SIZE[0])
        self._pending_signatures.append({
            "page": page_index,
            "rect": (page_x, page_y, page_x + width_pt, page_y + height_pt),
        })
        self._on_added()
        self._document_view.refresh()

    def _find_pending_signature_at(self, page_index: int, x: float, y: float) -> dict | None:
        hit = None
        for sig in self._pending_signatures:
            if sig["page"] != page_index:
                continue
            x0, y0, x1, y1 = sig["rect"]
            if x0 <= x <= x1 and y0 <= y <= y1:
                hit = sig
        return hit

    def _drag_move_signature(self, event) -> None:
        zoom = self._document_view.get_zoom()
        page_x = self._document_view.canvas_x(event.x) / zoom
        page_y = self._document_view.canvas_y(event.y) / zoom
        x0, y0, x1, y1 = self._dragging_signature["rect"]
        width, height = x1 - x0, y1 - y0
        new_x0 = page_x - self._dragging_signature_offset[0]
        new_y0 = page_y - self._dragging_signature_offset[1]
        self._dragging_signature["rect"] = (new_x0, new_y0, new_x0 + width, new_y0 + height)
        self._on_moved()
        self._document_view.refresh()

    def _draw_pending_signatures(self) -> None:
        """Als Overlay-Callback bei document_view registriert (siehe bind()) -
        zeichnet alle noch nicht gespeicherten Unterschriften auf der
        aktuell sichtbaren Seite. Bildreferenzen werden in
        self._signature_overlay_images gehalten, da Tkinter ein
        PhotoImage sonst verwirft, sobald keine Python-Referenz mehr
        darauf zeigt (das Bild wuerde einfach wieder verschwinden)."""
        if not self._pending_signatures:
            return
        path = load_signature_path()
        if not path:
            return
        canvas = self._document_view.get_canvas()
        zoom = self._document_view.get_zoom()
        page_index = self._document_view.get_page_index()
        offset_x, offset_y = self._document_view.page_offset()  # QA-Fix Runde 6, siehe canvas_x()
        try:
            base_image = Image.open(path).convert("RGBA")
        except OSError:
            return

        self._signature_overlay_images = []
        for sig in self._pending_signatures:
            if sig["page"] != page_index:
                continue
            x0, y0, x1, y1 = sig["rect"]
            width_px = max(1, round((x1 - x0) * zoom))
            height_px = max(1, round((y1 - y0) * zoom))
            resized = base_image.resize((width_px, height_px))
            photo = ImageTk.PhotoImage(resized)
            self._signature_overlay_images.append(photo)
            canvas.create_image(x0 * zoom + offset_x, y0 * zoom + offset_y, anchor="nw", image=photo)

    def bake_pending_signatures(self) -> None:
        """Schreibt alle noch ausstehenden (bis dahin frei verschieb- und
        loeschbaren) Unterschriften dauerhaft in das Dokument - von
        annotate_ui.py unmittelbar vor dem eigentlichen Speichern
        aufgerufen. Siehe Docstring bei self._pending_signatures oben,
        warum das ueberhaupt noetig ist."""
        document = self._document_view.get_document()
        if not document:
            return
        for sig in self._pending_signatures:
            x0, y0, x1, _y1 = sig["rect"]
            insert_signature(document, sig["page"], (x0, y0), width_pt=x1 - x0)
        self._pending_signatures.clear()
        self._signature_overlay_images = []

    def clear_pending_signatures(self) -> None:
        """Verwirft alle noch nicht gespeicherten Unterschriften - beim
        Wechsel der aktiven Datei aufgerufen (annotate_ui.py), da sich
        die Positionen sonst faelschlich auf ein neues Dokument beziehen
        wuerden."""
        self._pending_signatures.clear()
        self._dragging_signature = None
        self._signature_overlay_images = []

    def _request_text(self, canvas_x: int, canvas_y: int) -> None:
        """Merkt sich Seite/Position des Klicks und bittet die Ansicht
        (annotate_ui.py), den Text-Eingabedialog zu oeffnen - die
        eigentliche Platzierung erfolgt erst in confirm_text(), sobald
        der Nutzer dort Text bestaetigt hat."""
        document = self._document_view.get_document()
        if not document:
            return
        zoom = self._document_view.get_zoom()
        self._pending_text_page = self._document_view.get_page_index()
        self._pending_text_position = (canvas_x / zoom, canvas_y / zoom)
        self._on_text_requested()

    def confirm_text(self, text: str, font_size: float, font_code: str = "helv") -> None:
        document = self._document_view.get_document()
        if not document or self._pending_text_position is None or self._pending_text_page is None:
            return
        if add_text(document, self._pending_text_page, self._pending_text_position, text, font_size, font_code):
            self._on_added()
            self._document_view.refresh()
        self._pending_text_position = None
        self._pending_text_page = None

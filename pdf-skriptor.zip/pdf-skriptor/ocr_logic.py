"""
ocr_logic.py
Erstellt durchsuchbare PDFs aus Scans mittels ocrmypdf (nutzt intern
Tesseract). Unterstuetzt Deutsch und Englisch, einzeln oder kombiniert.

Prueft nach dem Lauf zusaetzlich, ob das Ergebnis tatsaechlich brauchbar
ist (Datei vorhanden, nicht leer, gleiche oder plausible Seitenzahl wie
das Original) - ein Rueckgabecode 0 von ocrmypdf allein ist keine
Garantie dafuer, insbesondere wenn der Vorgang durch einen zu knappen
Timeout mitten im Schreiben abgebrochen wurde.
"""

import os
import shutil
import subprocess
import sys
import pymupdf as fitz  # "fitz" ist der veraltete Alias, siehe PyMuPDF-Deprecation-Hinweis
from logger_setup import log_exception

LANGUAGE_OPTIONS = {
    "Deutsch": "deu",
    "Englisch": "eng",
    "Deutsch + Englisch": "deu+eng",
}

# Ghostscript/Pillow lehnen sehr grosse gescannte Seiten (z. B. hochaufgeloeste
# A3/A2-Scans) standardmaessig als moegliche "Decompression Bomb" ab (Standard-
# Grenze liegt bei 500 Megapixeln). Echte Buero-Scans koennen diese Grenze bei
# hoher DPI leicht ueberschreiten, daher wird sie hier grosszuegiger gesetzt,
# aber nicht vollstaendig deaktiviert (Sicherheitsnetz gegen echte Bomben).
MAX_IMAGE_MPIXELS = 2000

# Grundzeit plus Zeit pro Seite - ein einzelner Timeout von wenigen Minuten
# reicht bei mehrseitigen oder hochaufgeloesten Scans oft nicht aus; ein zu
# knapper Timeout fuehrt zu einer vom Betriebssystem abgebrochenen, aber auf
# der Festplatte bereits angelegten (leeren/unvollstaendigen) Ausgabedatei.
_BASE_TIMEOUT_SECONDS = 300
_TIMEOUT_SECONDS_PER_PAGE = 60


def _ocrmypdf_command() -> list[str] | None:
    """Liefert den Befehl zum Aufruf von ocrmypdf. Bevorzugt wird das
    ocrmypdf, das in derselben (isolierten) Python-Umgebung wie diese
    Anwendung installiert ist (per requirements.txt) - dann stammen
    ocrmypdf und pikepdf garantiert aus derselben, zueinander passenden
    Installation. Das vermeidet den Fall, dass ein systemweit per
    Paketmanager installiertes ocrmypdf auf ein davon unabhaengig (z. B.
    global per pip) installiertes, nicht mehr kompatibles pikepdf trifft
    (siehe "Bekannte Einschraenkungen" in analyse.md). Nur falls ocrmypdf
    nicht in der eigenen Umgebung installiert ist, wird auf ein
    systemweit installiertes ocrmypdf zurueckgegriffen."""
    try:
        import ocrmypdf  # noqa: F401
        return [sys.executable, "-m", "ocrmypdf"]
    except ImportError:
        system_path = shutil.which("ocrmypdf")
        return [system_path] if system_path else None


def is_ocrmypdf_available() -> bool:
    return _ocrmypdf_command() is not None


def _get_page_count(path: str) -> int:
    try:
        document = fitz.open(path)
        count = document.page_count
        document.close()
        return count
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Ermitteln der Seitenzahl vor OCR", exc)
        return 0


def _validate_output(output_path: str, expected_min_pages: int) -> tuple[bool, str]:
    """Prueft, ob die erzeugte Datei tatsaechlich ein brauchbares,
    mehrseitiges PDF mit Inhalt ist - nicht nur, dass ocrmypdf mit
    Rueckgabecode 0 beendet wurde."""
    if not os.path.isfile(output_path):
        return False, "Es wurde keine Ausgabedatei erzeugt."
    if os.path.getsize(output_path) < 200:
        return False, "Die erzeugte Datei ist praktisch leer (nur wenige Bytes)."

    try:
        document = fitz.open(output_path)
        page_count = document.page_count
        document.close()
    except Exception as exc:  # noqa: BLE001
        return False, f"Die erzeugte Datei lässt sich nicht als PDF öffnen: {exc}"

    if page_count == 0:
        return False, "Die erzeugte Datei enthält keine Seiten."
    if expected_min_pages and page_count < expected_min_pages:
        return False, (
            f"Die erzeugte Datei hat nur {page_count} von erwarteten "
            f"{expected_min_pages} Seiten - der Vorgang wurde vermutlich "
            "vorzeitig abgebrochen (z. B. durch einen zu knappen Timeout)."
        )
    return True, ""


def run_ocr(input_path: str, output_path: str, language: str = "deu", force: bool = True) -> tuple[bool, str]:
    """Fuehrt OCR auf einer PDF-Datei aus und gibt (Erfolg, Meldung) zurueck."""
    command = _ocrmypdf_command()
    if command is None:
        return False, "ocrmypdf wurde nicht gefunden."

    input_page_count = _get_page_count(input_path)
    timeout_seconds = _BASE_TIMEOUT_SECONDS + input_page_count * _TIMEOUT_SECONDS_PER_PAGE

    command = command + [
        "--language", language, "--output-type", "pdf",
        "--max-image-mpixels", str(MAX_IMAGE_MPIXELS),
    ]
    if force:
        command.append("--force-ocr")
    command.extend([input_path, output_path])

    try:
        result = subprocess.run(command, capture_output=True, timeout=timeout_seconds, check=False)
        if result.returncode != 0:
            message = result.stderr.decode(errors="ignore")[-500:].strip()
            if not message:
                message = (
                    "OCR wurde vom Betriebssystem abgebrochen (Rückgabecode "
                    f"{result.returncode}). Bei sehr großen oder hochauflösenden "
                    "Scans kann dies an zu wenig verfügbarem Arbeitsspeicher liegen."
                )
            log_exception("ocrmypdf Fehlercode", Exception(message))
            _remove_bad_output(output_path)
            return False, message

        is_valid, validation_message = _validate_output(output_path, input_page_count)
        if not is_valid:
            log_exception("ocrmypdf lieferte Rückgabecode 0, aber ungültiges Ergebnis", Exception(validation_message))
            _remove_bad_output(output_path)
            return False, validation_message

        return True, "OCR erfolgreich abgeschlossen."
    except subprocess.TimeoutExpired:
        message = (
            f"OCR hat das Zeitlimit von {timeout_seconds // 60} Minuten überschritten "
            "und wurde abgebrochen. Bei sehr großen oder mehrseitigen Scans kann die "
            "Verarbeitung länger dauern als vorgesehen."
        )
        log_exception("ocrmypdf Timeout", Exception(message))
        _remove_bad_output(output_path)
        return False, message
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler bei der OCR-Verarbeitung", exc)
        _remove_bad_output(output_path)
        return False, str(exc)


def _remove_bad_output(output_path: str) -> None:
    """Entfernt eine unvollstaendige/ungueltige Ausgabedatei, damit der
    Nutzer nicht faelschlich eine leere Datei als Ergebnis vorfindet."""
    try:
        if os.path.isfile(output_path):
            os.remove(output_path)
    except OSError as exc:
        log_exception("Fehler beim Entfernen einer fehlgeschlagenen OCR-Ausgabedatei", exc)

"""
header_footer_ui.py
UI fuer das Kopf-/Fusszeilen-Modul: Text mit Platzhaltern
({seite}, {seiten}, {datum}, {aktenzeichen}) fuer Kopf- und Fusszeile,
je mit Ausrichtung, optionaler Aktenzeichen-Nummerierung und
Schriftgroesse. Wird auf jede Seite der aktiven Datei angewendet.
"""

import os
import tkinter.filedialog as filedialog
from tkinter import messagebox
import customtkinter as ctk
from language import t
import settings as settings_store
import theme
from header_footer_logic import apply_header_footer
from file_list_sync import sync_active_file, load_result_file

# Stabile, sprachunabhaengige interne Schluessel (siehe _ALIGN_MAP in
# header_footer_logic.py) - die angezeigten Werte des CTkSegmentedButton
# sind uebersetzt, muessen aber vor der Weitergabe an die Backend-Logik
# wieder auf diese Schluessel zurueckgefuehrt werden (_get_align_key).
_ALIGN_KEYS = ["left", "center", "right"]


class HeaderFooterView(ctk.CTkFrame):
    """Ansicht zum Einfuegen von Kopf-/Fusszeile mit Seitennummerierung."""

    def __init__(self, master, file_manager) -> None:
        super().__init__(master, fg_color=theme.COLOR_BG)
        self._file_manager = file_manager
        self._active_path: str | None = None
        self._bates_enabled_var = ctk.BooleanVar(value=False)
        self._build_ui()
        sync_active_file(self, self._file_manager, self._handle_active_changed)

    def _build_ui(self) -> None:
        title = ctk.CTkLabel(self, text=t("nav_header_footer"), font=theme.font_title(), text_color=theme.COLOR_TEXT)
        title.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(theme.PADDING_LARGE, theme.PADDING_SMALL))

        self._active_file_label = ctk.CTkLabel(self, text="", font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED)
        self._active_file_label.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        hint = ctk.CTkLabel(
            self, text=t("header_footer_placeholder_hint"), font=theme.font_small(),
            text_color=theme.COLOR_TEXT_MUTED, wraplength=300, justify="left",
        )
        hint.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))

        card = ctk.CTkFrame(self, fg_color=theme.COLOR_BG_SECONDARY, corner_radius=theme.CORNER_RADIUS)
        card.pack(fill="x", padx=theme.PADDING_LARGE, pady=theme.PADDING_SMALL)

        self._align_key_by_display = {t(f"align_{key}"): key for key in _ALIGN_KEYS}
        self._header_entry, self._header_align = self._build_line_row(card, t("header_footer_header_label"))
        self._footer_entry, self._footer_align = self._build_line_row(card, t("header_footer_footer_label"))
        self._font_size_slider = self._build_font_size_row(card)
        self._build_bates_section(card)

        save_button = ctk.CTkButton(
            self, text=t("header_footer_apply"), fg_color=theme.COLOR_ACCENT, hover_color=theme.COLOR_ACCENT_HOVER,
            corner_radius=theme.CORNER_RADIUS, command=self._handle_save,
        )
        save_button.pack(anchor="w", padx=theme.PADDING_LARGE, pady=(theme.PADDING_MEDIUM, theme.PADDING_LARGE))

    def _build_line_row(self, card, label_text: str) -> tuple[ctk.CTkEntry, ctk.CTkSegmentedButton]:
        row = ctk.CTkFrame(card, fg_color="transparent")
        row.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=theme.PADDING_SMALL)
        ctk.CTkLabel(row, text=label_text, font=theme.font_small(), text_color=theme.COLOR_TEXT, anchor="w").pack(anchor="w")
        entry = ctk.CTkEntry(row)
        entry.pack(fill="x", pady=(2, 4))
        align = ctk.CTkSegmentedButton(row, values=list(self._align_key_by_display.keys()))
        align.set(t("align_center"))
        align.pack(anchor="w")
        return entry, align

    def _get_align_key(self, align_widget: ctk.CTkSegmentedButton) -> str:
        return self._align_key_by_display.get(align_widget.get(), "left")

    def _build_font_size_row(self, card) -> ctk.CTkSlider:
        row = ctk.CTkFrame(card, fg_color="transparent")
        row.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=theme.PADDING_SMALL)
        ctk.CTkLabel(row, text=t("header_footer_font_size"), font=theme.font_small(), text_color=theme.COLOR_TEXT, anchor="w").pack(anchor="w")
        slider = ctk.CTkSlider(row, from_=8, to=18, number_of_steps=10)
        slider.set(10)
        slider.pack(fill="x", pady=(2, 0))
        return slider

    def _build_bates_section(self, card) -> None:
        checkbox = ctk.CTkCheckBox(
            card, text=t("header_footer_bates_enable"), variable=self._bates_enabled_var, command=self._toggle_bates_fields,
        )
        checkbox.pack(anchor="w", padx=theme.PADDING_MEDIUM, pady=(theme.PADDING_SMALL, 4))

        self._bates_row = ctk.CTkFrame(card, fg_color="transparent")
        self._bates_prefix_entry = ctk.CTkEntry(self._bates_row, placeholder_text=t("header_footer_bates_prefix"), width=90)
        self._bates_prefix_entry.pack(side="left", padx=(0, 4))
        self._bates_start_entry = ctk.CTkEntry(self._bates_row, placeholder_text=t("header_footer_bates_start"), width=70)
        self._bates_start_entry.insert(0, "1")
        self._bates_start_entry.pack(side="left", padx=4)
        self._bates_digits_entry = ctk.CTkEntry(self._bates_row, placeholder_text=t("header_footer_bates_digits"), width=60)
        self._bates_digits_entry.insert(0, "4")
        self._bates_digits_entry.pack(side="left", padx=4)

    def _toggle_bates_fields(self) -> None:
        if self._bates_enabled_var.get():
            self._bates_row.pack(fill="x", padx=theme.PADDING_MEDIUM, pady=(0, theme.PADDING_SMALL))
        else:
            self._bates_row.pack_forget()

    def _handle_active_changed(self, path: str | None) -> None:
        self._active_path = path
        if path:
            self._active_file_label.configure(text=f"📄 {os.path.basename(path)}")
        else:
            self._active_file_label.configure(text=t("no_active_file_hint"))

    def _handle_save(self) -> None:
        if not self._active_path:
            messagebox.showinfo(t("app_title"), t("no_active_file_hint"))
            return
        if not self._header_entry.get().strip() and not self._footer_entry.get().strip():
            messagebox.showinfo(t("app_title"), t("header_footer_nothing_to_apply"))
            return

        bates_start = None
        bates_prefix = ""
        bates_digits = 4
        if self._bates_enabled_var.get():
            try:
                bates_start = int(self._bates_start_entry.get())
                bates_digits = int(self._bates_digits_entry.get())
            except ValueError:
                messagebox.showerror(t("app_title"), t("header_footer_bates_invalid"))
                return
            bates_prefix = self._bates_prefix_entry.get()

        settings = settings_store.load_settings()
        base_name = os.path.splitext(os.path.basename(self._active_path))[0]
        default_path = os.path.join(settings.get("output_dir", "~"), f"{base_name}_kopf_fuss.pdf")
        output_path = filedialog.asksaveasfilename(
            initialfile=os.path.basename(default_path),
            initialdir=os.path.dirname(default_path),
            defaultextension=".pdf",
            filetypes=[("PDF-Dateien", "*.pdf")],
        )
        if not output_path:
            return

        success = apply_header_footer(
            self._active_path, output_path,
            self._header_entry.get(), self._get_align_key(self._header_align),
            self._footer_entry.get(), self._get_align_key(self._footer_align),
            font_size=self._font_size_slider.get(),
            bates_start=bates_start, bates_prefix=bates_prefix, bates_digits=bates_digits,
        )
        if success:
            load_result_file(self._file_manager, output_path)
            messagebox.showinfo(t("app_title"), t("save_success"))
        else:
            messagebox.showerror(t("app_title"), t("error_generic"))

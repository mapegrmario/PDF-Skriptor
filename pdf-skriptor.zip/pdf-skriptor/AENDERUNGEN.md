# PDF Skriptor – Änderungsübersicht

Alle Dateien sind **Ersatzdateien**: einfach in deinen bestehenden Projektordner
kopieren und die alten Versionen überschreiben. Keine der 5 neuen Dateien
braucht eine Sonderbehandlung – sie liegen wie alle anderen flach im
Hauptordner.

Syntaktisch geprüft (`py_compile` über alle Dateien) und die wichtigsten
Abläufe live in einer Testinstanz durchgeklickt (Sprachwechsel + Scrollen,
Zusammenfügen mit Umsortieren, Löschen mit visueller Auswahl, neues
Text-Werkzeug, Über-Tab, Drehen mit automatischer Echtzeit-Anzeige).

## Nachtrag: Runde 9 – Seitenbereich beim Drucken + A4-Anpassung

**„Das Gedruckte ist sehr klein":** `lp` druckte die PDF-Seite bisher in
ihrer Originalgröße, ohne sie an das eingelegte Papier anzupassen - bei
einer Abweichung zwischen PDF-Seitengröße und Papierformat kann das
winzig oder falsch platziert wirken. `print_logic.py` übergibt jetzt
zusätzlich `-o fit-to-page -o media=a4` an `lp` - Inhalt wird automatisch
auf A4 skaliert.

**Seitenbereich drucken:** Neuer Umschalter „Alle Seiten" / „Seitenbereich"
im Drucken-Werkzeug (`print_ui.py`); bei „Seitenbereich" erscheint ein
Eingabefeld („z. B. 1,3,5-7") mit Hinweis auf die tatsächliche Seitenzahl
der aktiven Datei. Wird an `lp -P <Seitenliste>` durchgereicht (offizielle
CUPS-Option für Seitenauswahl). Eingabe wird vor dem Drucken geprüft -
leer oder ungültig formatiert löst eine klare Fehlermeldung statt eines
fehlerhaften Druckauftrags aus.

Beides mit Fake-`lp`/`lpstat`-Skripten verifiziert: tatsächlicher Aufruf
bei Seitenbereich „1,3-4" war exakt `-n 1 -o fit-to-page -o media=a4 -d
<Drucker> -P 1,3-4 <Datei>`; ungültige Eingabe („abc") erzeugt die
Fehlermeldung und führt zu keinem Druckaufruf; Umschalten zwischen den
beiden Modi blendet das Eingabefeld korrekt ein/aus.

Alle 77 Dateien kompilieren weiterhin fehlerfrei.

## Nachtrag: Runde 8 – "Kein Drucker angezeigt, obwohl einer installiert ist"

**Ursache:** `lpstat` übersetzt seine Ausgabe abhängig von der System-
Locale (bekanntes, dokumentiertes CUPS-Verhalten). Auf einem deutsch-
sprachigen System beginnt die Zeile z. B. mit „Drucker" statt „printer" -
`list_printers()` suchte aber exakt nach dem englischen Wort und fand
dadurch nichts, obwohl ein Drucker eingerichtet war.

**Fix:** `print_logic.py` erzwingt jetzt `LC_ALL=C`/`LANGUAGE=C` für die
`lpstat`/`lp`-Unterprozesse - stabile, unlokalisierte Ausgabe zum
Auswerten, ohne die Sprache der App oder des Systems selbst zu ändern.
Zusätzlich: Wenn `lpstat -p` doch einmal leer bleibt, wird das jetzt mit
Rückgabewert und Ausgabe in `fehler.log` mitprotokolliert, um zukünftige
Fälle schneller eingrenzen zu können.

**Verifikation:** Mit Fake-`lpstat`/`lp`-Skripten, die - genau wie auf
einem echten deutschsprachigen Ubuntu - unterschiedlich antworten je
nachdem, ob die C-Locale erzwungen wird oder nicht, das exakt gemeldete
Szenario nachgestellt (Systemsprache Deutsch, `lpstat`-Ausgabe deutsch
lokalisiert). Drucker wird jetzt korrekt erkannt und angezeigt.

## Nachtrag: Runde 7 – Schriftauswahl bei Text platzieren + neues Drucken-Werkzeug

**Schriftauswahl (Anmerkungen → Text platzieren):** Dropdown mit Helvetica/
Times/Courier neben dem bestehenden Schriftgrößen-Regler (`text_tool_dialog.py`).
Durchgereicht über `confirm_text()` in `annotate_interaction.py` zu
`add_text()` in `annotate_logic.py`, die den PyMuPDF-Fontcode jetzt an
`add_freetext_annot(..., fontname=...)` weitergibt - alle drei sind
PDF-Basis-14-Schriften, kein Embedding noetig. Live getestet: Courier
rendert sichtbar als Festbreitenschrift; bis auf Byte-Ebene bestaetigt
(`/DA: 0 0 0 rg /Cour 14.0 Tf` in der gespeicherten Datei).

**Neues Werkzeug „Drucken":** Sendet die aktive Datei ueber CUPS (`lp`) an
einen eingerichteten Drucker - funktioniert identisch fuer klassische wie
treiberlose (IPP-Everywhere-)Warteschlangen, da CUPS beide intern gleich
verwaltet. Neue Dateien `print_logic.py` (Drucker auflisten via `lpstat -p`,
Standarddrucker via `lpstat -d`, drucken via `lp`) und `print_ui.py`
(Druckerauswahl, Kopien-Stepper, Drucken-Button). Kein neues pip-Paket -
`lp`/`lpstat` sind auf allen sechs Zieldistributionen im
Desktop-Standardumfang enthalten; `install_check.py` prueft `lp` zusaetzlich
ab und zeigt einen Hinweis im Über-Tab, falls es fehlt (analog zu
Ghostscript/OCRmyPDF). Kachel alphabetisch einsortiert zwischen „PDF/A-
Archivierung" und „Seiten neu ordnen" (`home_view.py`), eigenes Icon
(`generate_icons.py`), Navigation (`app_window.py`), Hilfe-Eintrag
(`help_view.py`), zuletzt verwendeter Drucker wird gemerkt (`settings.py`).

Da in der Testumgebung kein echter Drucker verfuegbar ist, wurden `lp`/
`lpstat` testweise durch Skripte mit realistischer CUPS-Ausgabe ersetzt
(zwei simulierte Drucker). Damit vollstaendig end-to-end verifiziert:
Drucker werden korrekt aufgelistet, Standarddrucker richtig vorausgewaehlt,
Umschalten auf den zweiten Drucker im Dropdown wirkt sich korrekt auf den
tatsaechlichen Aufruf aus (`lp -n 1 -d Kueche_Canon_IPP <Datei>`),
Kopien-Stepper funktioniert, Erfolgsmeldung erscheint, gewaehlter Drucker
wird fuer naechstes Mal gemerkt. Ohne eingerichteten Drucker (Normalfall in
der Sandbox) erscheint sauber "Kein Drucker eingerichtet" und der
Drucken-Button ist korrekt deaktiviert - kein Absturz. Auf Deutsch und
Englisch geprueft.

## Nachtrag: Runde 6 – "springt nach rechts" bei Anmerkungen + Reiter-Fix

**Gemeldet:** Beim Markieren oder Einfügen unter Anmerkungen springt die
Anmerkung nach dem Loslassen der Maustaste an eine andere (weiter rechts
liegende) Stelle.

**Ursache gefunden:** Regression aus Runde 4. Die dort eingeführte
Dokumentzentrierung (`_update_page_centering()`) verschiebt das Seitenbild
um einen Versatz `(offset_x, offset_y)`, sobald die Seite kleiner als der
sichtbare Bereich ist (z. B. Standardfall bei 100% Zoom). `canvas_x()`/
`canvas_y()` in `document_view.py` - von allen Anmerkungs- und
Redaction-Werkzeugen zur Umrechnung von Bildschirm- in PDF-Koordinaten
genutzt - zogen diesen Versatz nicht ab. Während des Ziehens fiel es nicht
auf (Vorschau wird direkt mit der - falschen, aber in sich konsistenten -
Canvas-Koordinate gezeichnet); der sichtbare Sprung passierte erst beim
Neu-Rendern nach dem Loslassen, wenn die tatsächlich gespeicherte
PDF-Position (mit Versatz) zum ersten Mal sichtbar wurde.

**Fix:** `document_view.py` zieht den Versatz jetzt in `canvas_x()`/
`canvas_y()` ab und stellt ihn über die neue Methode `page_offset()` für
Werkzeuge bereit, die während einer Aktion direkt auf die Canvas zeichnen
(dort muss der Versatz für die reine Bildschirmdarstellung wieder addiert
werden). Betraf zwei Dateien: `annotate_interaction.py` (Freihand-Vorschau,
Rechteck-Vorschau, Unterschrift-Overlay) und `redact_manual_ui.py`
(dasselbe Muster bei der manuellen Schwärzung - eigenständig gefunden, war
in Runde 5 nur zufällig nicht aufgefallen, weil die dortige Testdatei keine
Zentrierung ausgelöst hat). Mit eigens erzeugter Raster-Testdatei an vier
Stellen verifiziert (Freihand, Hervorhebung, Text platzieren, manuelle
Schwärzung) - Screenshot während des Ziehens vs. danach jeweils
deckungsgleich, kein Sprung mehr.

**Dabei zusätzlich entdeckt:** Die sechs Unterwerkzeug-Reiter bei
Anmerkungen (Freihand/Hervorhebung/Text/Stempel/Radierer/Unterschrift)
waren als eine einzelne 6er-Zeile in der 380px-Seitenleiste zu schmal -
Beschriftungen abgeschnitten/unleserlich (in jedem Screenshot dieser
Sitzung reproduzierbar, unabhängig von Zoom/Zentrierung). `annotate_ui.py`:
zwei Zeilen zu je drei Werkzeugen statt einer Zeile mit sechs; da
CTkSegmentedButton pro Instanz nur eine eigene Auswahl kennt, leert
`_handle_tool_selected()` jetzt gezielt die jeweils andere Zeile. Live auf
Deutsch und Englisch geprüft: alle Beschriftungen vollständig lesbar,
Werkzeugwechsel zwischen den Zeilen funktioniert in beide Richtungen
korrekt (inkl. korrekt aktualisierter werkzeugspezifischer Optionen).

## Nachtrag: Runde 5 – Formulare, Seiten neu ordnen, Redaction live getestet

Auf Wunsch gezielt die drei Kern-Workflows nachgetestet, die in den
vorherigen Runden nicht mit echter simulierter Maussteuerung durchgeklickt
wurden - inklusive selbst erzeugter Testdateien (Formular mit/ohne `/TU`,
5-seitiges Dokument, Text mit eindeutigem Suchbegriff).

**Formulare ausfüllen - Fehler gefunden und behoben:** Speichern eines
ausgefüllten Formulars stürzte mit `AttributeError: 'dict' object has no
attribute 'get_object'` ab, sobald das AcroForm der PDF kein eigenes `/DR`
(Default Resources) besitzt - ein bekannter Grenzfall von pypdf's
`update_page_form_field_values()`. `forms_logic.py`:
`_ensure_default_resources()` ergänzt vor dem Speichern automatisch ein
minimales `/Helv`-Font-`/DR`, falls keines vorhanden ist; bestehende
Formulare mit eigenem `/DR` (z. B. aus Acrobat, LibreOffice) bleiben
unangetastet. Mit isoliertem Python-Repro **und** erneut live über die App
verifiziert.

**Seiten neu ordnen - Fehler gefunden und behoben:** Der Button „Neue
Reihenfolge speichern" zeigte seinen Text links und rechts abgeschnitten
(„eue Reihenfolge speiche"), weil zwei nebeneinander mit `fill="x",
expand=True` gepackte Buttons in der nur 380px breiten Seitenleiste für die
deutsche Beschriftung schlicht zu wenig Platz hatten. `reorder_ui.py`:
Buttons werden jetzt untereinander statt nebeneinander angeordnet - robust
unabhängig von Sprache/Textlänge. (Ein erster Fix-Versuch über eine feste
`width=` schlug fehl und wurde verworfen, siehe Code-Kommentar.) Der
eigentliche Drag-&-Drop-Umsortiervorgang selbst funktionierte bereits davor
einwandfrei (im UI **und** in der gespeicherten Datei verifiziert).

**Redaction - keine Fehler, aber eine Kleinigkeit korrigiert:** Beide Modi
(Suche & Schwärzen sowie Manuell markieren) live getestet und über
Textextraktion verifiziert, dass die geschwärzten Inhalte wirklich entfernt
werden und nicht nur von einem schwarzen Balken überdeckt sind (wie in der
Kachel-Beschreibung versprochen) - in beiden Fällen bestätigt, während
unbeteiligter Text unverändert blieb. Einzig „1 Bereiche vorgemerkt" war
grammatisch falsch (richtig: „1 Bereich"). `redact_manual_ui.py` +
`language.py`: neuer Schlüssel `redact_manual_pending_one` für den
Singular-Fall.

## Nachtrag: Echtzeit-Anzeige nach Bearbeitung (2. Runde)
Zusätzlich behoben: Nach jeder Bearbeitung (Drehen, Löschen, Zusammenfügen,
Trennen, Seiten neu ordnen, Kopf-/Fußzeile, Wasserzeichen, PDF/A,
Lesezeichen, beide Schwärzen-Werkzeuge, Formulare, Anmerkungen, Signatur,
OCR, Komprimieren) musste bisher erst gespeichert und die entstandene Datei
danach manuell über "Dateien auswählen" erneut geladen werden, um das
Ergebnis zu sehen. Neue Funktion `load_result_file()` in `file_list_sync.py`
laedt die frisch gespeicherte Datei jetzt automatisch in die Werkbank und
macht sie sofort aktiv - die Dokumentenansicht zeigt das Ergebnis direkt.
Bewusste Ausnahme: Verschlüsseln fügt die Datei zur Werkbank hinzu, aktiviert
sie aber nicht automatisch (das Ergebnis ist passwortgeschützt, ein
automatisches Öffnen würde nur einen Fehler zeigen). Nicht betroffen:
Konvertierung (Ergebnis ist kein PDF), Batch-Pipeline (verarbeitet ganze
Ordner), Metadaten (schreibt in dieselbe Datei zurück, keine visuelle
Änderung).

## Nachtrag: Text-Werkzeug verfeinert (3. Runde)
Zwei Verbesserungen am "Text platzieren"-Werkzeug:
1. Der Dialog zeigt die eingestellte Schriftgröße jetzt live als Zahl neben
   dem Regler an (vorher nur der Regler selbst, ohne erkennbaren Wert).
2. Bereits platzierte Textfelder lassen sich per Klick+Ziehen an eine neue
   Position verschieben (Korrektur der Platzierung), statt nur beim
   Anlegen fixiert zu sein. Erkennung über ein internes Kennzeichen
   (PDF-Subject-Tag), damit nur eigene Textfelder betroffen sind, keine
   Stempel oder andere Anmerkungen.

Dabei einen echten, subtilen Fehler gefunden und behoben: PyMuPDF-Anmerkungsobjekte
halten nur eine schwache Referenz auf ihre Seite. Die ursprüngliche Suchfunktion
gab die gefundene Anmerkung zurück, ohne dass der Aufrufer die zugehörige Seite
am Leben hielt - jeder weitere Zugriff (z. B. beim Ziehen) führte zu einem
Absturz des Vorgangs. `find_text_annot_at_point()` gibt jetzt zusätzlich die
Seite zurück, die als Instanzattribut während des gesamten Ziehvorgangs
gehalten wird. Mit einem eigenständigen Testskript (ohne Oberfläche) verifiziert,
danach zusätzlich live in der GUI bestätigt.

## Nachtrag: Zentrierung, Sortierung, Unterschrift (4. Runde)
Drei weitere Anpassungen:
1. **Dokument wird immer zentriert angezeigt** - vorher haftete die Seite
   immer oben links, mit toter Fläche rechts/unten, sobald sie kleiner als
   der sichtbare Bereich war (z. B. bei niedrigem Zoom oder Querformat).
   Neue Funktion `_update_page_centering()` in `document_view.py`, die
   nach jedem Rendern UND bei jeder Größenänderung des Fensters läuft -
   bleibt dadurch auch beim Zoomen und beim Verschieben der Trenner
   erhalten. Ist die Seite in einer Richtung größer als der sichtbare
   Bereich, bleibt es dort beim gewohnten Scroll-Verhalten.
2. **Kacheln innerhalb jeder Kategorie alphabetisch sortiert** - sortiert
   dynamisch nach dem gerade angezeigten (übersetzten) Titel, damit die
   Reihenfolge sowohl auf Deutsch als auch auf Englisch wirklich
   alphabetisch ist (die beiden Sprachen hätten mit einer fest einprogrammierten Reihenfolge unterschiedliche Ergebnisse verlangt).
3. **Unterschrift ist jetzt verschieb- und löschbar.** Ursache des
   ursprünglichen Verhaltens: Anders als Text/Stempel (echte
   FreeText-Anmerkungen) fügte `insert_signature()` das Bild direkt und
   dauerhaft in den Seiteninhalt ein (`page.insert_image()`) - PyMuPDF
   bietet dafür keine verschieb- oder löschbare Anmerkung an. Lösung:
   Unterschriften bleiben jetzt bis zum Speichern als eigene Liste
   bestehen und werden nur als Overlay angezeigt (frei verschiebbar per
   Ziehen, löschbar per Radierer, wie jede andere Anmerkung); erst ein
   Klick auf "Anmerkungen speichern" schreibt sie endgültig ins Dokument.

Alle vier Punkte live in der GUI bestätigt: Zentrierung sichtbar beim
Herauszoomen (gleichmäßiger Abstand links/rechts), Sortierung am
Startbildschirm ("Annotations, Bookmarks, Compress, Digital Signature,
Forms..."), Unterschrift verschoben und anschließend mit dem Radierer
entfernt.

## Neue Dateien (5)
- `delete_page_card.py` – anklickbare Seiten-Miniatur für die neue visuelle Auswahl beim Löschen
- `merge_file_card.py` – ziehbare Datei-Karte für die neue Umsortierung beim Zusammenfügen
- `text_tool_dialog.py` – kleiner Dialog (Text + Schriftgröße) für das neue "Text platzieren"-Werkzeug

*(delete_page_card.py und merge_file_card.py folgen demselben Muster wie das
bereits vorhandene reorder_card.py.)*

## Die zwei Hauptbefunde
- **`language.py`** – rund 90 neue Übersetzungsschlüssel (DE+EN). Das ist die zentrale Datei für den größten Befund: unvollständige Übersetzung.
- **`scroll_helpers.py`** – behebt die Scroll-Sperre, die nach einem Sprachwechsel auftrat (Ursache: `<Enter>`/`<Leave>` feuern nicht zuverlässig, wenn Ansichten per Sprachwechsel zerstört/neu aufgebaut werden, statt durch Mausbewegung. Jetzt zusätzlich über `<Map>`/`<Unmap>`/`<Destroy>` abgesichert).

## Übersetzung angeschlossen (nur i18n-Fix, keine Funktionsänderung)
`home_view.py` (alle 21 Kachel-Beschreibungen), `organize_ui.py` (Unterreiter),
`redact_ui.py` (Titel, Untertitel, Modus-Auswahl), `header_footer_ui.py` +
`header_footer_logic.py` (Ausrichtung – stabile interne Schlüssel von der
Anzeige getrennt), `convert_ui.py`, `pipeline_step_row.py` + `pipeline_logic.py`
+ `pipeline_ui.py`, `compress_ui.py`, `forms_ui.py`, `metadata_ui.py`,
`compare_ui.py`, `ocr_ui.py`, `organize_rotate_ui.py`, `organize_split_ui.py`,
`redact_manual_ui.py`, `redact_search_ui.py`, `security_ui.py`, `annotate_ui.py`
(Zähler-Anzeige, Speichern-Button).

## Funktionale Änderungen
- **`organize_merge_ui.py`** + **`file_manager.py`** – Dateien lassen sich per Drag & Drop umsortieren (`reorder_files()`), wirkt sich konsistent auch auf die Werkbank-Chips aus.
- **`organize_delete_ui.py`** – visuelle Seitenauswahl per Miniaturen (synchron zur Textzeile) + Bestätigungsdialog vor dem Löschen.
- **`annotate_ui.py`, `annotate_interaction.py`, `annotate_logic.py`** – neues "Text platzieren"-Werkzeug (Klick ins Dokument → Dialog → Platzierung).
- **`forms_logic.py`, `forms_ui.py`** – zeigt das `/TU`-Tooltip-Attribut als Feldbeschriftung, falls im PDF vorhanden, statt immer den internen Feldnamen.
- **`app_window.py`** – Einstellungen/Hilfe/Über als Icons neben "☰ Menü" (aus der Scroll-Liste entfernt); Schließen-Schutz bei ungesicherten Anmerkungen.
- **`workbench_view.py`** – Leerzustand zeigt jetzt eine echte Drop-Zone (Icon + Text), Sprachwechsel aktualisiert sie mit.
- **`main.py`, `about_view.py`** – kein blockierender Start-Dialog mehr; fehlende Systemprogramme stehen jetzt dezent im Über-Tab.
- **`help_view.py`** – Reihenfolge der englischen Hilfe-Liste an die deutsche angeglichen ("Forms" stand vorher an anderer Position als "Formulare").
- **`redact_ui.py`, `redact_manual_ui.py`** – zusätzlich `has_unsaved_changes()` für den Schließen-Schutz.

## Nicht enthalten
Alles, was der Bericht nicht bemängelt hat, ist unverändert – u. a. die
grundsätzliche Werkbank-/Aktive-Datei-Architektur, Digitale Signatur, PDF/A,
Suche, Lesezeichen, Wasserzeichen.

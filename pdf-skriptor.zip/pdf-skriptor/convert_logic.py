"""
convert_logic.py
Wandelt PDF-Inhalte in Markdown oder reinen Text um. Erkennt Tabellen
ueber PyMuPDF und gibt sie als Markdown-Tabellen aus - das deckt eine
in der Linux-Welt kaum geloeste Luecke ab (Tabellen bleiben strukturiert
statt als loser Text).
"""

import pymupdf as fitz  # "fitz" ist der veraltete Alias, siehe PyMuPDF-Deprecation-Hinweis
from logger_setup import log_exception


def convert_to_text(path: str) -> str:
    """Extrahiert reinen Text aus allen Seiten."""
    try:
        document = fitz.open(path)
        parts = [page.get_text() for page in document]
        document.close()
        return "\n\n".join(parts)
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler bei der Textkonvertierung", exc)
        return ""


def _table_to_markdown(table) -> str:
    rows = table.extract()
    if not rows:
        return ""
    lines = []
    header = rows[0]
    lines.append("| " + " | ".join(str(cell or "") for cell in header) + " |")
    lines.append("| " + " | ".join("---" for _ in header) + " |")
    for row in rows[1:]:
        lines.append("| " + " | ".join(str(cell or "") for cell in row) + " |")
    return "\n".join(lines)


def convert_to_markdown(path: str) -> str:
    """Extrahiert Text und erkannte Tabellen als strukturiertes Markdown."""
    try:
        document = fitz.open(path)
        page_blocks = []
        for page_index, page in enumerate(document):
            page_blocks.append(f"## Seite {page_index + 1}\n")
            try:
                tables = page.find_tables()
                table_list = list(tables.tables) if tables else []
            except Exception:  # noqa: BLE001
                table_list = []

            table_rects = [table.bbox for table in table_list]
            text = page.get_text()
            page_blocks.append(text.strip())

            for table in table_list:
                markdown_table = _table_to_markdown(table)
                if markdown_table:
                    page_blocks.append("\n" + markdown_table)

        document.close()
        return "\n\n".join(page_blocks)
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler bei der Markdown-Konvertierung", exc)
        return ""


def count_detected_tables(path: str) -> int:
    """Zaehlt die insgesamt erkannten Tabellen im Dokument."""
    try:
        document = fitz.open(path)
        total = 0
        for page in document:
            tables = page.find_tables()
            total += len(tables.tables) if tables else 0
        document.close()
        return total
    except Exception as exc:  # noqa: BLE001
        log_exception("Fehler beim Zählen der Tabellen", exc)
        return 0

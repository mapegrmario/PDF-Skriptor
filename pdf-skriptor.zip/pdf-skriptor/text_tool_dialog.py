"""
text_tool_dialog.py
Kleiner modaler Dialog zur Texteingabe fuer das "Text"-Werkzeug im
Anmerkungen-Modul (QA-Fix/neue Funktion aus dem Usability-Audit: es
gab bisher keine Moeglichkeit, frei platzierten Text auf eine PDF-Seite
zu setzen). Analog zu signature_pad.py aufgebaut.
"""

import customtkinter as ctk
from language import t
import theme

_MIN_FONT_SIZE = 8
_MAX_FONT_SIZE = 36
_DEFAULT_FONT_SIZE = 14

# Neue Funktion (Schriftauswahl): PyMuPDF unterstuetzt diese drei
# Basis-14-Schriftarten nativ ueber den fontname-Parameter von
# add_freetext_annot() - kein Embedding, keine Schriftdatei noetig, daher
# bewusst keine weiteren Optionen (z. B. Systemschriften) angeboten.
_FONT_CHOICES = {
    "Helvetica": "helv",
    "Times": "tiro",
    "Courier": "cour",
}
_DEFAULT_FONT_LABEL = "Helvetica"


class TextToolDialog(ctk.CTkToplevel):
    """Modaler Dialog zur Eingabe von Text, Schriftgroesse und Schriftart;
    ruft on_confirm(text, font_size, font_code) auf, wenn nicht-leerer
    Text bestaetigt wurde."""

    def __init__(self, master, on_confirm) -> None:
        super().__init__(master)
        self.title(t("text_tool_dialog_title"))
        self.resizable(False, False)
        self._on_confirm = on_confirm
        self._build_ui()
        self.transient(master)
        self.grab_set()
        self._text_box.focus_set()

    def _build_ui(self) -> None:
        self._text_box = ctk.CTkTextbox(self, width=280, height=90, fg_color=theme.COLOR_BG_SECONDARY)
        self._text_box.pack(padx=theme.PADDING_LARGE, pady=(theme.PADDING_LARGE, theme.PADDING_SMALL))

        font_row = ctk.CTkFrame(self, fg_color="transparent")
        font_row.pack(fill="x", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_SMALL))
        ctk.CTkLabel(
            font_row, text=t("text_tool_font_label"), font=theme.font_small(), text_color=theme.COLOR_TEXT,
        ).pack(side="left")
        self._font_menu = ctk.CTkOptionMenu(
            font_row, values=list(_FONT_CHOICES.keys()), width=140,
            fg_color=theme.COLOR_BG_SECONDARY, button_color=theme.COLOR_ACCENT,
            button_hover_color=theme.COLOR_ACCENT_HOVER,
        )
        self._font_menu.set(_DEFAULT_FONT_LABEL)
        self._font_menu.pack(side="right")

        size_row = ctk.CTkFrame(self, fg_color="transparent")
        size_row.pack(fill="x", padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_MEDIUM))
        ctk.CTkLabel(
            size_row, text=t("text_tool_font_size"), font=theme.font_small(), text_color=theme.COLOR_TEXT,
        ).pack(side="left")
        self._size_slider = ctk.CTkSlider(
            size_row, from_=_MIN_FONT_SIZE, to=_MAX_FONT_SIZE,
            number_of_steps=_MAX_FONT_SIZE - _MIN_FONT_SIZE, command=self._handle_size_changed,
        )
        self._size_slider.set(_DEFAULT_FONT_SIZE)
        self._size_slider.pack(side="left", fill="x", expand=True, padx=(theme.PADDING_SMALL, theme.PADDING_SMALL))
        # QA-Fix: zeigt die aktuell eingestellte Schriftgroesse als Zahl an
        # (vorher nur der Regler selbst, ohne erkennbaren Wert).
        self._size_value_label = ctk.CTkLabel(
            size_row, text=f"{_DEFAULT_FONT_SIZE} pt", font=theme.font_small(),
            text_color=theme.COLOR_TEXT_MUTED, width=32,
        )
        self._size_value_label.pack(side="left")

        button_row = ctk.CTkFrame(self, fg_color="transparent")
        button_row.pack(padx=theme.PADDING_LARGE, pady=(0, theme.PADDING_LARGE), fill="x")

        cancel_button = ctk.CTkButton(
            button_row, text=t("text_tool_cancel"), fg_color="transparent", border_width=1,
            border_color=theme.COLOR_BORDER, text_color=theme.COLOR_TEXT, hover_color=theme.COLOR_ACCENT_SOFT,
            corner_radius=theme.CORNER_RADIUS, command=self.destroy,
        )
        cancel_button.pack(side="right", padx=(theme.PADDING_SMALL, 0))

        confirm_button = ctk.CTkButton(
            button_row, text=t("text_tool_confirm"), fg_color=theme.COLOR_ACCENT,
            hover_color=theme.COLOR_ACCENT_HOVER, corner_radius=theme.CORNER_RADIUS, command=self._confirm,
        )
        confirm_button.pack(side="right")

    def _handle_size_changed(self, value: float) -> None:
        self._size_value_label.configure(text=f"{int(round(value))} pt")

    def _confirm(self) -> None:
        text = self._text_box.get("1.0", "end").strip()
        if text:
            font_code = _FONT_CHOICES.get(self._font_menu.get(), "helv")
            self._on_confirm(text, self._size_slider.get(), font_code)
        self.destroy()

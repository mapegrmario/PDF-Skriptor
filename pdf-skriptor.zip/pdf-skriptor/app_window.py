"""
app_window.py
Hauptfenster von PDF Skriptor. Nach dem Vorbild eines Schreibprogramms:
Die Dokumentenansicht steht permanent im Zentrum (links/Mitte) und
bleibt bei jedem Werkzeug-Wechsel sichtbar. Rechts daneben erstreckt
sich eine Spalte ueber die gesamte Fensterhoehe (vom oberen bis zum
unteren Rand) mit den Werkzeug-Optionen bzw. den Startseiten-Kacheln,
die als einzige Navigation dienen (die fruehere linke Icon-Leiste
wurde entfernt). Direkt ueber dieser Spalte sitzt der "☰ Menü"-Knopf,
der von ueberall zur Kachel-Uebersicht zurueckfuehrt. Es oeffnen sich
keine zusaetzlichen Fenster.
"""

import tkinter as tk
import customtkinter as ctk
from tkinter import messagebox
from language import t, set_language
import settings as settings_store
import theme
from file_manager import file_manager
from workbench_view import WorkbenchView
from document_view import DocumentView
from help_view import HelpView
from about_view import AboutView
from settings_view import SettingsView
from organize_ui import OrganizeView
from metadata_ui import MetadataView
from compress_ui import CompressView
from security_ui import SecurityView
from forms_ui import FormsView
from annotate_ui import AnnotateView
from outline_ui import OutlineView
from header_footer_ui import HeaderFooterView
from watermark_ui import WatermarkView
from print_ui import PrintView
from pdfa_ui import PdfaView
from search_ui import SearchView
from reorder_ui import ReorderView
from sign_module_ui import SignModuleView
from ocr_ui import OcrView
from compare_ui import CompareView
from redact_ui import RedactView
from convert_ui import ConvertView
from pipeline_ui import PipelineView
from home_view import HomeView

try:
    from tkinterdnd2 import TkinterDnD, DND_FILES
    _DND_AVAILABLE = True
except Exception:  # noqa: BLE001
    _DND_AVAILABLE = False

if _DND_AVAILABLE:
    class _BaseWindow(ctk.CTk, TkinterDnD.DnDWrapper):
        """Kombiniert CustomTkinter mit systemweitem Drag & Drop (tkinterdnd2)."""
        pass
else:
    _BaseWindow = ctk.CTk

APP_MIN_WIDTH = 1280
APP_MIN_HEIGHT = 720
TOOL_PANEL_WIDTH = 380


class AppWindow(_BaseWindow):
    """Hauptfenster der Anwendung. Startseiten-Kacheln sind die einzige Navigation."""

    def __init__(self) -> None:
        super().__init__()
        if _DND_AVAILABLE:
            self.TkdndVersion = TkinterDnD._require(self)
        self._settings = settings_store.load_settings()
        set_language(self._settings.get("language", "de"))

        self._configure_window()
        self._current_view: ctk.CTkFrame | None = None
        self._views_cache: dict[str, ctk.CTkFrame] = {}

        self._build_layout()
        self._setup_drag_and_drop()
        # QA-Fix (Usability-Audit, Befund 4.4): Schliessen des Fensters war
        # bisher an keiner Stelle abgesichert - ungesicherte Anmerkungen
        # (die anders als alle anderen Werkzeuge erst per Extra-Klick
        # gespeichert werden) gingen beim Schliessen kommentarlos verloren.
        self.protocol("WM_DELETE_WINDOW", self._handle_close_request)
        self.show_module("home")

    def _handle_close_request(self) -> None:
        has_unsaved = getattr(self._current_view, "has_unsaved_changes", None)
        if callable(has_unsaved) and has_unsaved():
            if not messagebox.askyesno(t("close_unsaved_title"), t("close_unsaved_message")):
                return
        self.destroy()

    def _configure_window(self) -> None:
        self.title(t("app_title"))
        self.geometry(f"{APP_MIN_WIDTH}x{APP_MIN_HEIGHT}")
        self.minsize(APP_MIN_WIDTH, APP_MIN_HEIGHT)
        self.configure(fg_color=theme.COLOR_BG)

    def _setup_drag_and_drop(self) -> None:
        """Registriert das gesamte Fenster als Ablageziel, damit PDF-Dateien
        von einem Dateimanager aus per Drag & Drop hinzugefuegt werden koennen."""
        if not _DND_AVAILABLE:
            return
        self.drop_target_register(DND_FILES)
        self.dnd_bind("<<Drop>>", self._handle_file_drop)

    def _handle_file_drop(self, event) -> None:
        paths = list(self.tk.splitlist(event.data))
        added = file_manager.add_files(paths)
        skipped = len(paths) - len(added)
        if skipped > 0:
            messagebox.showinfo(
                t("app_title"),
                f"{skipped} Datei(en) wurden ignoriert (keine gültige PDF-Datei).",
            )

    def _build_layout(self) -> None:
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=0)
        self.grid_rowconfigure(0, weight=1)

        # Linke/mittlere Spalte: Werkbank oben, darunter die permanente
        # Dokumentenansicht - per Maus verschiebbarer Trenner dazwischen
        # (tk.PanedWindow, siehe _on_outer_sash_release fuer die
        # Groessen-Speicherung). sashwidth/sashrelief moeglichst dezent
        # gehalten, damit sich der (technisch bedingt nicht CTk-basierte)
        # Trenner ins helle Farbschema einfuegt.
        left_frame = ctk.CTkFrame(self, fg_color=theme.COLOR_BG, corner_radius=0)
        left_frame.grid(row=0, column=0, sticky="nsew")
        left_frame.grid_columnconfigure(0, weight=1)
        left_frame.grid_rowconfigure(0, weight=1)

        self._outer_paned = tk.PanedWindow(
            left_frame, orient="vertical", bg=theme.COLOR_BG, bd=0,
            sashwidth=6, sashpad=0, sashrelief="flat", opaqueresize=True,
        )
        self._outer_paned.grid(row=0, column=0, sticky="nsew")

        self._workbench = WorkbenchView(self._outer_paned, file_manager)
        self._outer_paned.add(
            self._workbench, minsize=120,
            height=self._settings.get("workbench_pane_height", 240), stretch="never",
        )

        # Bleibt bei JEDEM Werkzeug-Wechsel sichtbar, da sie ausserhalb des
        # module_container liegt und nie zerstoert wird.
        self._document_view = DocumentView(self._outer_paned, file_manager)
        self._outer_paned.add(self._document_view, minsize=280, stretch="always")

        # Nur ein Loslassen der Maustaste INNERHALB des PanedWindow selbst
        # (also auf dem Trenner - Klicks in Werkbank/Dokumentenansicht
        # gehen an die jeweiligen Kind-Widgets und loesen dies nicht aus)
        # speichert die neue Werkbank-Hoehe.
        self._outer_paned.bind("<ButtonRelease-1>", self._on_outer_sash_release)

        # Rechte Spalte: erstreckt sich ueber die GESAMTE Fensterhoehe (vom
        # oberen bis zum unteren Rand), unabhaengig von der Werkbank links.
        # Direkt darin, ganz oben, sitzt der Menü-Knopf - unmittelbar ueber
        # dem Bereich, den er steuert.
        right_frame = ctk.CTkFrame(self, fg_color="transparent", width=TOOL_PANEL_WIDTH)
        right_frame.grid(row=0, column=1, sticky="nsew")
        right_frame.grid_propagate(False)
        right_frame.grid_columnconfigure(0, weight=1)
        right_frame.grid_rowconfigure(1, weight=1)

        menu_header = ctk.CTkFrame(right_frame, fg_color=theme.COLOR_BG_SECONDARY, corner_radius=0)
        menu_header.grid(row=0, column=0, sticky="ew")
        menu_header.grid_columnconfigure(0, weight=1)
        self._menu_button = ctk.CTkButton(
            menu_header, text=f"☰ {t('workbench_menu_button')}", fg_color="transparent",
            border_width=1, border_color=theme.COLOR_BORDER, text_color=theme.COLOR_TEXT,
            hover_color=theme.COLOR_ACCENT_SOFT, corner_radius=theme.CORNER_RADIUS,
            command=lambda: self.show_module("home"),
        )
        self._menu_button.grid(row=0, column=0, sticky="w", padx=theme.PADDING_MEDIUM, pady=theme.PADDING_SMALL)

        # QA-Fix (Usability-Audit, Befund 1.3): Einstellungen/Hilfe/Ueber
        # standen vorher ganz unten im 21 Kacheln langen Scroll-Menue (im
        # Test rund 25 Mausrad-Bewegungen entfernt). Jetzt zusaetzlich
        # direkt hier erreichbar - die Kacheln in home_view.py bleiben
        # als zweiter, gleichwertiger Weg bestehen.
        shortcuts = ctk.CTkFrame(menu_header, fg_color="transparent")
        shortcuts.grid(row=0, column=1, sticky="e", padx=theme.PADDING_MEDIUM, pady=theme.PADDING_SMALL)
        for key, icon in (("settings", "⚙️"), ("help", "❓"), ("about", "ℹ️")):
            button = ctk.CTkButton(
                shortcuts, text=icon, width=32, fg_color="transparent", border_width=1,
                border_color=theme.COLOR_BORDER, hover_color=theme.COLOR_ACCENT_SOFT,
                corner_radius=theme.CORNER_RADIUS, command=lambda k=key: self.show_module(k),
            )
            button.pack(side="left", padx=(theme.PADDING_SMALL, 0))

        self._module_container = ctk.CTkFrame(right_frame, fg_color="transparent")
        self._module_container.grid(row=1, column=0, sticky="nsew")
        self._module_container.grid_columnconfigure(0, weight=1)
        self._module_container.grid_rowconfigure(0, weight=1)

    def _on_outer_sash_release(self, _event) -> None:
        """Merkt sich die per Maus eingestellte Werkbank-Hoehe dauerhaft."""
        height = self._workbench.winfo_height()
        if height > 10:
            settings_store.update_setting("workbench_pane_height", height)

    def show_module(self, key: str) -> None:
        """Blendet die Werkzeug- bzw. Menü-Ansicht in der rechten Spalte ein -
        die zentrale Dokumentenansicht bleibt davon vollkommen unberuehrt."""
        view = self._get_or_create_view(key)
        if view is None:
            return

        if self._current_view is not None:
            if hasattr(self._current_view, "on_hidden"):
                self._current_view.on_hidden()
            self._current_view.grid_forget()
        view.grid(row=0, column=0, sticky="nsew")
        if hasattr(view, "on_shown"):
            view.on_shown()
        self._current_view = view

    def _get_or_create_view(self, key: str) -> ctk.CTkFrame | None:
        if key in self._views_cache:
            return self._views_cache[key]

        view = self._build_view(key)
        if view is not None:
            self._views_cache[key] = view
        return view

    def _build_view(self, key: str) -> ctk.CTkFrame | None:
        builders = {
            "home": lambda: HomeView(self._module_container, on_navigate=self.show_module),
            "organize": lambda: OrganizeView(self._module_container, file_manager),
            "metadata": lambda: MetadataView(self._module_container, file_manager),
            "compress": lambda: CompressView(self._module_container, file_manager),
            "security": lambda: SecurityView(self._module_container, file_manager),
            "forms": lambda: FormsView(self._module_container, file_manager),
            "annotate": lambda: AnnotateView(self._module_container, file_manager, self._document_view),
            "outline": lambda: OutlineView(self._module_container, file_manager, self._document_view),
            "header_footer": lambda: HeaderFooterView(self._module_container, file_manager),
            "watermark": lambda: WatermarkView(self._module_container, file_manager),
            "print": lambda: PrintView(self._module_container, file_manager),
            "pdfa": lambda: PdfaView(self._module_container, file_manager),
            "search": lambda: SearchView(self._module_container, file_manager, self._document_view),
            "reorder": lambda: ReorderView(self._module_container, file_manager),
            "sign": lambda: SignModuleView(self._module_container, file_manager),
            "ocr": lambda: OcrView(self._module_container, file_manager),
            "compare": lambda: CompareView(self._module_container, file_manager),
            "redact": lambda: RedactView(self._module_container, file_manager, self._document_view),
            "convert": lambda: ConvertView(self._module_container, file_manager),
            "pipeline": lambda: PipelineView(self._module_container, file_manager),
            "settings": lambda: SettingsView(self._module_container, on_language_change=self._reload_after_language_change),
            "help": lambda: HelpView(self._module_container),
            "about": lambda: AboutView(self._module_container),
        }
        builder = builders.get(key)
        return builder() if builder else None

    def _reload_after_language_change(self) -> None:
        """Sprache wurde geaendert: Fenster neu aufbauen, damit alle Texte aktuell sind."""
        active_key = None
        for key, view in self._views_cache.items():
            if view is self._current_view:
                active_key = key

        # Referenz auf die aktuelle (gleich zerstoerte) Ansicht sofort loesen,
        # damit show_module() nicht versucht, ein bereits zerstoertes Widget
        # per grid_forget() zu entfernen.
        self._current_view = None

        for view in self._views_cache.values():
            view.destroy()
        self._views_cache.clear()
        self.title(t("app_title"))
        self._workbench.retranslate()
        self._document_view.retranslate()
        self._menu_button.configure(text=f"☰ {t('workbench_menu_button')}")
        self.show_module(active_key or "home")

"""
redact_manual_ui.py
Unter-Werkzeug fuer Redaction: markiert Bereiche direkt auf der
permanenten Dokumentenansicht per Maus, die anschliessend dauerhaft
geschwaerzt werden. Bindet seine Maus-Handler nur, waehrend dieses
Werkzeug sichtbar ist (<Map>/<Unmap>).
"""

import os
import tkinter.filedialog as filedialog
from tkinter import messagebox
import customtkinter as ctk
from language import t
import settings as settings_store
import theme
from redact_logic import apply_redactions
from file_list_sync import sync_active_file, load_result_file


class RedactManualTool(ctk.CTkFrame):

    @staticmethod
    def _pending_text(n: int) -> str:
        """QA-Fix (Runde 5, Live-Test Redaction): 'n Bereiche vorgemerkt' war
        fuer n=1 falsch dekliniert ('1 Bereiche' statt '1 Bereich')."""
        if n == 1:
            return t("redact_manual_pending_one")
        return t("redact_manual_pending").format(n=n)
    """UI zum manuellen Markieren und Schwaerzen von Bereichen."""

    def __init__(self, master, file_manager, document_view) -> None:
        super().__init__(master, fg_color="transparent")
        self._file_manager = file_manager
        self._document_view = document_view
        self._active_path: str | None = None
        self._pending_areas: list[dict] = []
        self._drag_start: tuple[int, int] | None = None
        self._drag_rect_id: int | None = None
        self._build_ui()
        sync_active_file(self, self._file_manager, self._handle_active_changed)

    def _build_ui(self) -> None:
        self._active_file_label = ctk.CTkLabel(self, text="", font=theme.font_body(), text_color=theme.COLOR_TEXT_MUTED)
        self._active_file_label.pack(anchor="w", pady=(0, theme.PADDING_MEDIUM))

        hint = ctk.CTkLabel(
            self, text=t("redact_manual_hint"),
            font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED, wraplength=300, justify="left",
        )
        hint.pack(anchor="w", pady=(0, theme.PADDING_MEDIUM))

        self._pending_label = ctk.CTkLabel(
            self, text=self._pending_text(0), font=theme.font_small(), text_color=theme.COLOR_TEXT_MUTED,
        )
        self._pending_label.pack(anchor="w", pady=(0, theme.PADDING_SMALL))

        clear_button = ctk.CTkButton(
            self, text=t("redact_manual_clear"), fg_color="transparent", border_width=1,
            border_color=theme.COLOR_BORDER, text_color=theme.COLOR_TEXT, hover_color=theme.COLOR_ACCENT_SOFT,
            corner_radius=theme.CORNER_RADIUS, command=self._clear_pending,
        )
        clear_button.pack(fill="x", pady=(0, theme.PADDING_SMALL))

        apply_button = ctk.CTkButton(
            self, text=t("redact_manual_button"), fg_color=theme.COLOR_ERROR,
            hover_color="#B8352F", corner_radius=theme.CORNER_RADIUS, command=self._handle_apply,
        )
        apply_button.pack(fill="x")

    def _handle_active_changed(self, path: str | None) -> None:
        self._active_path = path
        if path:
            self._active_file_label.configure(text=f"📄 {os.path.basename(path)}")
        else:
            self._active_file_label.configure(text=t("no_active_file_hint"))
        self._pending_areas.clear()
        self._pending_label.configure(text=self._pending_text(0))

    def on_shown(self) -> None:
        """Wird von redact_ui.py aufgerufen, sobald dieses Werkzeug sichtbar
        wird - bindet Maus-Handler und Overlay an die Dokumentenansicht."""
        self._document_view.bind_canvas(self._on_mouse_down, self._on_mouse_drag, self._on_mouse_up)
        self._document_view.set_overlay_callback(self._draw_pending_overlays)
        self._document_view.refresh()

    def on_hidden(self) -> None:
        """Wird von redact_ui.py aufgerufen, bevor dieses Werkzeug
        verschwindet - loest Maus-Handler und Overlay wieder."""
        self._document_view.unbind_canvas()
        self._document_view.clear_overlay_callback()

    def _draw_pending_overlays(self) -> None:
        canvas = self._document_view.get_canvas()
        zoom = self._document_view.get_zoom()
        page_index = self._document_view.get_page_index()
        offset_x, offset_y = self._document_view.page_offset()  # QA-Fix Runde 6, siehe document_view.canvas_x()
        for area in self._pending_areas:
            if area["page"] == page_index:
                x0, y0, x1, y1 = [value * zoom for value in area["rect"]]
                canvas.create_rectangle(
                    x0 + offset_x, y0 + offset_y, x1 + offset_x, y1 + offset_y,
                    fill="black", stipple="gray50", outline="red",
                )

    def _on_mouse_down(self, event) -> None:
        canvas = self._document_view.get_canvas()
        x = self._document_view.canvas_x(event.x)
        y = self._document_view.canvas_y(event.y)
        self._drag_start = (x, y)
        offset_x, offset_y = self._document_view.page_offset()
        self._drag_rect_id = canvas.create_rectangle(
            x + offset_x, y + offset_y, x + offset_x, y + offset_y, outline="red", width=2,
        )

    def _on_mouse_drag(self, event) -> None:
        if self._drag_start is not None and self._drag_rect_id is not None:
            canvas = self._document_view.get_canvas()
            x0, y0 = self._drag_start
            x = self._document_view.canvas_x(event.x)
            y = self._document_view.canvas_y(event.y)
            offset_x, offset_y = self._document_view.page_offset()
            canvas.coords(self._drag_rect_id, x0 + offset_x, y0 + offset_y, x + offset_x, y + offset_y)

    def _on_mouse_up(self, event) -> None:
        if self._drag_start is None or not self._document_view.get_document():
            return
        zoom = self._document_view.get_zoom()
        page_index = self._document_view.get_page_index()
        x0, y0 = self._drag_start
        x1 = self._document_view.canvas_x(event.x)
        y1 = self._document_view.canvas_y(event.y)
        self._drag_start = None
        if abs(x1 - x0) < 4 or abs(y1 - y0) < 4:
            self._document_view.refresh()
            return
        rect_pdf = [
            min(x0, x1) / zoom, min(y0, y1) / zoom,
            max(x0, x1) / zoom, max(y0, y1) / zoom,
        ]
        self._pending_areas.append({"page": page_index, "rect": rect_pdf})
        self._pending_label.configure(text=self._pending_text(len(self._pending_areas)))
        self._document_view.refresh()

    def has_unsaved_changes(self) -> bool:
        """Wird von redact_ui.py beim Schliessen des Fensters abgefragt
        (QA-Fix, Befund 4.4, Konsistenz zu annotate_ui.py)."""
        return len(self._pending_areas) > 0

    def _clear_pending(self) -> None:
        self._pending_areas.clear()
        self._pending_label.configure(text=self._pending_text(0))
        self._document_view.refresh()

    def _handle_apply(self) -> None:
        if not self._active_path or not self._pending_areas:
            messagebox.showinfo(t("app_title"), t("redact_manual_need_area"))
            return

        settings = settings_store.load_settings()
        base_name = os.path.splitext(os.path.basename(self._active_path))[0]
        default_path = os.path.join(settings.get("output_dir", "~"), f"{base_name}_geschwaerzt.pdf")
        output_path = filedialog.asksaveasfilename(
            initialfile=os.path.basename(default_path),
            initialdir=os.path.dirname(default_path),
            defaultextension=".pdf",
            filetypes=[("PDF-Dateien", "*.pdf")],
        )
        if not output_path:
            return

        success = apply_redactions(self._active_path, output_path, self._pending_areas)
        if success:
            load_result_file(self._file_manager, output_path)
            messagebox.showinfo(t("app_title"), t("save_success"))
            self._clear_pending()
        else:
            messagebox.showerror(t("app_title"), t("error_generic"))

"""
icon_style.py
Gemeinsame Zeichen-Grundlagen fuer die 3D-Badge-Icons: Farbverlauf,
abgerundete Maske, weicher Schlagschatten, Glanzlicht und Rahmen.
Wird von generate_icons.py fuer jedes Icon aufgerufen; die einzelnen
Glyphen (Schloss, Stift, ...) stehen dort, nicht hier.
"""

from PIL import Image, ImageDraw, ImageFilter

SCALE = 4
SIZE = 96
S = SIZE * SCALE
WHITE = (255, 255, 255, 235)
SHADE = (0, 0, 0, 65)


def hex_to_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))


def lighten(rgb, amount):
    return tuple(min(255, int(c + (255 - c) * amount)) for c in rgb)


def darken(rgb, amount):
    return tuple(max(0, int(c * (1 - amount))) for c in rgb)


def rounded_mask(size, radius):
    mask = Image.new("L", (size, size), 0)
    d = ImageDraw.Draw(mask)
    d.rounded_rectangle([0, 0, size - 1, size - 1], radius=radius, fill=255)
    return mask


def vertical_gradient(size, top_rgb, bottom_rgb):
    grad = Image.new("RGB", (1, size))
    for y in range(size):
        t = y / (size - 1)
        rgb = tuple(int(top_rgb[i] + (bottom_rgb[i] - top_rgb[i]) * t) for i in range(3))
        grad.putpixel((0, y), rgb)
    return grad.resize((size, size))


def make_badge(color_hex, glyph_fn):
    pad = int(S * 0.08)
    canvas = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    base = hex_to_rgb(color_hex)
    top_c = lighten(base, 0.30)
    bottom_c = darken(base, 0.18)
    badge_size = S - 2 * pad
    radius = int(badge_size * 0.26)

    shadow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    sd = ImageDraw.Draw(shadow)
    off = int(S * 0.035)
    sd.rounded_rectangle([pad, pad + off, pad + badge_size, pad + badge_size + off], radius=radius, fill=(20, 20, 30, 130))
    shadow = shadow.filter(ImageFilter.GaussianBlur(S * 0.02))
    canvas = Image.alpha_composite(canvas, shadow)

    grad = vertical_gradient(badge_size, top_c, bottom_c)
    mask = rounded_mask(badge_size, radius)
    badge_layer = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    badge_layer.paste(grad, (pad, pad), mask)
    canvas = Image.alpha_composite(canvas, badge_layer)

    gloss = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    gd = ImageDraw.Draw(gloss)
    gd.ellipse([pad + badge_size * 0.08, pad + badge_size * 0.06, pad + badge_size * 0.92, pad + badge_size * 0.55], fill=(255, 255, 255, 60))
    full_mask = Image.new("L", (S, S), 0)
    full_mask.paste(mask, (pad, pad))
    gloss = Image.composite(gloss, Image.new("RGBA", (S, S), (0, 0, 0, 0)), full_mask)
    canvas = Image.alpha_composite(canvas, gloss)

    border = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    bd = ImageDraw.Draw(border)
    bd.rounded_rectangle([pad, pad, pad + badge_size, pad + badge_size], radius=radius, outline=darken(base, 0.40) + (200,), width=int(S * 0.010))
    canvas = Image.alpha_composite(canvas, border)

    draw = ImageDraw.Draw(canvas)
    b = badge_size
    glyph_box = [pad + b * 0.18, pad + b * 0.18, pad + b * 0.82, pad + b * 0.82]
    glyph_fn(draw, glyph_box, S)

    return canvas.resize((SIZE, SIZE), Image.LANCZOS)


